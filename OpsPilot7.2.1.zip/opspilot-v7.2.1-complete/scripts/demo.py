import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json

from agents.incident import investigate
from data_platform.pipeline import run
from data_platform.storage import write_frame
from ml.training.train import train
from platform_core.registry import registry


def main(domain):
    plugin = registry().get(domain)
    p = Path("data/bronze") / domain
    p.mkdir(parents=True, exist_ok=True)
    write_frame(plugin.generate(1500, 42), p / "events.parquet")
    print("quality", run(domain))
    print("model", train(domain))
    print(
        json.dumps(
            investigate(
                domain,
                "model_degradation",
                [
                    {"kind": "quality", "metric": "missing_rate", "value": 0.15},
                    {"kind": "drift", "metric": "drift_share", "value": 0.55},
                ],
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else registry().names()[0])
