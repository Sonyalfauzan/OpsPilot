import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import html
from pathlib import Path

src = Path("analytics/reports/executive-summary.md").read_text(encoding="utf-8")
out = Path("analytics/reports/executive-summary.html")
out.write_text("<html><body><pre>" + html.escape(src) + "</pre></body></html>", encoding="utf-8")
print(out)
