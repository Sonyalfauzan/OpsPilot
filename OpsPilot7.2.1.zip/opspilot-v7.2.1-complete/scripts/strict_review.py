"""Twelve independent release gates. Any failure blocks packaging."""

import ast
import json
import subprocess
import sys
from pathlib import Path

import yaml

root = Path(__file__).resolve().parents[1]
failures = []


def gate(name, fn):
    try:
        fn()
        print(f"PASS {name}")
    except Exception as exc:
        failures.append((name, str(exc)))
        print(f"FAIL {name}: {exc}")


def check(condition, message):
    if not condition:
        raise AssertionError(message)


gate(
    "01_python_syntax",
    lambda: [
        ast.parse(p.read_text(encoding="utf-8"))
        for p in root.rglob("*.py")
        if "__pycache__" not in p.parts
    ],
)
gate(
    "02_json_parse",
    lambda: [json.loads(p.read_text(encoding="utf-8")) for p in root.rglob("*.json")],
)
gate(
    "03_yaml_parse",
    lambda: [yaml.safe_load(p.read_text(encoding="utf-8")) for p in root.rglob("*.yaml")],
)
gate(
    "04_version_consistency",
    lambda: check(
        'version = "6.0.0"' in (root / "pyproject.toml").read_text(encoding="utf-8"),
        "package version",
    ),
)
gate(
    "05_no_mcp_v1",
    lambda: check(
        "mcp<2" not in (root / "pyproject.toml").read_text(encoding="utf-8")
        and "fastmcp"
        not in "".join(
            p.read_text(encoding="utf-8").lower() for p in (root / "mcp_servers").glob("*.py")
        ),
        "v1 MCP remains",
    ),
)
gate(
    "06_distributed_dedup",
    lambda: check(
        all(
            x in (root / "streaming/deduplication.py").read_text(encoding="utf-8")
            for x in [
                "RedisDeduplicationStore",
                "PostgresDeduplicationStore",
                "ON CONFLICT DO NOTHING RETURNING",
            ]
        ),
        "dedup backends",
    ),
)
gate(
    "07_atomic_concurrency",
    lambda: subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "tests/test_v5_modernization.py"],
        cwd=root,
        check=True,
        capture_output=True,
    ),
)
gate(
    "08_full_tests",
    lambda: subprocess.run(
        [sys.executable, "-m", "pytest", "-q"], cwd=root, check=True, capture_output=True
    ),
)
gate(
    "09_ruff_format",
    lambda: subprocess.run(
        [sys.executable, "-m", "ruff", "format", "--check", "."],
        cwd=root,
        check=True,
        capture_output=True,
    ),
)
gate(
    "10_ruff_lint",
    lambda: subprocess.run(
        [sys.executable, "-m", "ruff", "check", "."], cwd=root, check=True, capture_output=True
    ),
)
gate(
    "11_definition_of_done",
    lambda: subprocess.run(
        [sys.executable, "scripts/verify_definition_of_done.py"],
        cwd=root,
        check=True,
        capture_output=True,
    ),
)
gate(
    "12_security_boundaries",
    lambda: check(
        "prohibited_actions"
        in "".join(
            p.read_text(encoding="utf-8") for p in root.glob("domain_packs/*/policies.yaml")
        ),
        "policies missing",
    ),
)
if failures:
    raise SystemExit(f"release blocked: {failures}")
print("STRICT_REVIEW=12/12")
