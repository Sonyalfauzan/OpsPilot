"""Auditable release gate with machine-readable output."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = {
    "ruff_format": [sys.executable, "-m", "ruff", "format", "--check", "."],
    "ruff_lint": [sys.executable, "-m", "ruff", "check", "."],
    "tests": [sys.executable, "-m", "pytest", "-q"],
    "definition_of_done": [sys.executable, "scripts/verify_definition_of_done.py"],
    "privacy": [sys.executable, "validation/privacy/scan_repository.py"],
    "incomplete_scan": [sys.executable, "validation/scan_incomplete.py"],
    "calibration": [sys.executable, "validation/calibration/generate_report.py"],
    "mcp_smoke": [sys.executable, "validation/interop/mcp_smoke.py"],
}


def main() -> None:
    results = {}
    for name, command in COMMANDS.items():
        completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=900)
        results[name] = {
            "passed": completed.returncode == 0,
            "stdout": completed.stdout.strip()[-2000:],
            "stderr": completed.stderr.strip()[-2000:],
        }
    for path in ROOT.glob("*compose*.yml"):
        list(yaml.safe_load_all(path.read_text(encoding="utf-8")))
    results["compose_yaml"] = {
        "passed": True,
        "files": sorted(p.name for p in ROOT.glob("*compose*.yml")),
    }
    output = ROOT / "artifacts/release-audit.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(results, indent=2), encoding="utf-8")
    failed = [name for name, result in results.items() if not result["passed"]]
    if failed:
        raise SystemExit(f"release audit failed: {failed}")
    print(f"release_audit=passed gates={len(results)} evidence={output}")


if __name__ == "__main__":
    main()
