"""Behavioral verifier for the portfolio Definition of Done."""

import ast
import json
import sys
import tempfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.workflow import IncidentWorkflow, State
from data_platform.scenarios import inject
from ml.deployment import DeploymentState, evaluate_guardrails, start_canary
from ml.evidently_monitor import run_monitor
from platform_core.registry import registry
from rag.service import LocalRAG


def check(condition: bool, name: str, failures: list[str]) -> None:
    if not condition:
        failures.append(name)


def main() -> int:
    failures: list[str] = []
    specification = yaml.safe_load(
        (ROOT / "portfolio/definition-of-done.yaml").read_text(encoding="utf-8")
    )
    promised = sum(len(items) for items in specification.values())

    # Structural and syntax evidence.
    for path in ROOT.rglob("*.py"):
        if "__pycache__" not in path.parts:
            try:
                ast.parse(path.read_text(encoding="utf-8"))
            except SyntaxError:
                failures.append(f"syntax:{path.relative_to(ROOT)}")
    check(len(registry().names()) == 29, "domain_registry", failures)

    # Behavioral evidence across every plugin.
    for domain in registry().names():
        plugin = registry().get(domain)
        frame = plugin.generate(200, 42)
        check(plugin.validate(frame)["passed"], f"{domain}.validation", failures)
        silver = plugin.transform_silver(frame)
        marts = plugin.build_marts(silver)
        check(bool(marts), f"{domain}.marts", failures)
        dataset = plugin.training_set(silver)
        check(dataset.target.name not in dataset.features.columns, f"{domain}.leakage", failures)

    # RAG, monitoring, agent and rollback produce real runtime artifacts.
    rag = LocalRAG()
    check(rag.index(ROOT / "knowledge") >= 4, "rag.index", failures)
    check(bool(rag.answer("logistics traffic delay")["citations"]), "rag.citations", failures)
    with tempfile.TemporaryDirectory() as temporary:
        plugin = registry().get("retail")
        reference = plugin.generate(100, 42)
        current = inject(reference, "data-drift")
        run_monitor(reference, current, temporary)
        check(Path(temporary, "report.json").exists(), "monitoring.artifact", failures)
    deployment = DeploymentState("1")
    start_canary(deployment, "2", 10)
    check(
        evaluate_guardrails(deployment, 250, 0.03, -0.1)["state"] == "ROLLED_BACK",
        "rollback",
        failures,
    )
    flow = IncidentWorkflow("logistics", [{"kind": "drift", "metric": "drift_share", "value": 0.8}])
    flow.step()
    flow.step()
    check(flow.state == State.APPROVAL_PENDING, "agent.approval_gate", failures)

    # Automation files must be valid and connected.
    workflows = list((ROOT / "automation/n8n").glob("*.json"))
    check(len(workflows) >= 13, "n8n.count", failures)
    for workflow in workflows:
        payload = json.loads(workflow.read_text(encoding="utf-8"))
        check(
            bool(payload.get("nodes")) and bool(payload.get("connections")),
            f"n8n:{workflow.name}",
            failures,
        )

    print(f"definition_of_done={promised} behavioral_failures={len(failures)}")
    if failures:
        print("\n".join(failures))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
