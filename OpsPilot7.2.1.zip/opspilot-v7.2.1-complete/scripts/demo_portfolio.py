import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json

from agents.workflow import IncidentWorkflow, State
from data_platform.pipeline import run
from data_platform.storage import write_frame
from ml.deployment import DeploymentState, evaluate_guardrails, start_canary
from ml.training.train import train
from platform_core.registry import registry


def main():
    summary = {}
    for tenant in ["tenant-alpha", "tenant-beta"]:
        for domain in registry().names():
            base = Path("data") / tenant / "bronze" / domain
            base.mkdir(parents=True, exist_ok=True)
            frame = registry().get(domain).generate(800, 42)
            frame["tenant_id"] = tenant
            write_frame(frame, base / "events.parquet")
            quality = run(domain, tenant)
            model = train(domain, tenant)
            summary[f"{tenant}:{domain}"] = {"quality": quality, "model": model}
    deploy = DeploymentState("1")
    start_canary(deploy, "2", 10)
    rollback = evaluate_guardrails(deploy, 240, 0.03, -0.05)
    flow = IncidentWorkflow(
        "logistics", [{"kind": "drift", "metric": "drift_share", "value": 0.65}]
    )
    flow.step()
    flow.step()
    flow.state = State.EXECUTED
    flow.step()
    flow.step()
    post = {
        "title": "Synthetic challenger regression",
        "timeline": flow.timeline,
        "deployment": rollback,
        "limitations": ["synthetic data"],
    }
    Path("artifacts").mkdir(exist_ok=True)
    Path("artifacts/postmortem.json").write_text(
        json.dumps(post, indent=2, default=str), encoding="utf-8"
    )
    Path("artifacts/demo-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("portfolio demo complete")


if __name__ == "__main__":
    main()
