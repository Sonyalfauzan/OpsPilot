"""Idempotently seed synthetic tenants, users and feature flags."""

import asyncio
from uuid import uuid4

from sqlalchemy import select

from platform_core.database import FeatureFlag, Tenant, UserProfile, get_session_factory


async def main():
    async with get_session_factory()() as session:
        for tenant_id, name in [
            ("tenant-alpha", "Synthetic Alpha Operations"),
            ("tenant-beta", "Synthetic Beta Operations"),
        ]:
            if not await session.get(Tenant, tenant_id):
                session.add(Tenant(id=tenant_id, name=name))
        await session.flush()
        if not await session.scalar(
            select(UserProfile).where(UserProfile.username == "portfolio-admin")
        ):
            session.add(
                UserProfile(
                    id=str(uuid4()),
                    username="portfolio-admin",
                    display_name="Portfolio Administrator",
                    email="portfolio-admin@example.invalid",
                    tenant_id="tenant-alpha",
                    roles=["platform_admin", "approver", "viewer"],
                    identity_provider_id="portfolio-admin",
                )
            )
        if not await session.get(FeatureFlag, "synthetic.incident-trigger"):
            session.add(
                FeatureFlag(
                    key="synthetic.incident-trigger",
                    enabled=True,
                    tenant_id="tenant-alpha",
                    description="Allows labelled synthetic incidents in local portfolio mode.",
                )
            )
        await session.commit()
    print("administration_seed=complete tenants=2 users=1 flags=1")


if __name__ == "__main__":
    asyncio.run(main())
