"""Authenticated operational read models and synthetic-demo controls."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from platform_core.config import settings
from platform_core.database import Incident, OutboxEvent, get_session
from platform_core.identity import Principal, authenticate, require_tenant
from platform_core.registry import registry
from platform_core.schemas import IncidentCreate
from platform_core.services import IncidentService

router = APIRouter(prefix="/v1/operations", tags=["operations"])


class SyntheticIncidentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    tenant_id: str = Field(pattern=r"^[a-z0-9-]{3,64}$")
    domain: str
    severity: str = Field(default="SEV-3", pattern=r"^SEV-[1-4]$")


@router.get("/summary")
async def summary(
    tenant_id: str = Query(...),
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
) -> dict:
    require_tenant(principal, tenant_id)
    incidents = (
        await session.scalar(
            select(func.count()).select_from(Incident).where(Incident.tenant_id == tenant_id)
        )
        or 0
    )
    active = (
        await session.scalar(
            select(func.count())
            .select_from(Incident)
            .where(Incident.tenant_id == tenant_id, Incident.status.not_in(["CLOSED", "RESOLVED"]))
        )
        or 0
    )
    dead = (
        await session.scalar(
            select(func.count())
            .select_from(OutboxEvent)
            .where(OutboxEvent.tenant_id == tenant_id, OutboxEvent.status == "DEAD_LETTER")
        )
        or 0
    )
    pending = (
        await session.scalar(
            select(func.count())
            .select_from(OutboxEvent)
            .where(OutboxEvent.tenant_id == tenant_id, OutboxEvent.status == "PENDING")
        )
        or 0
    )
    return {
        "tenant_id": tenant_id,
        "incidents_total": incidents,
        "incidents_active": active,
        "outbox_dead_letter": dead,
        "outbox_pending": pending,
        "generated_at": datetime.now(UTC).isoformat(),
    }


@router.get("/incidents")
async def incidents(
    tenant_id: str = Query(...),
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
) -> list[dict]:
    require_tenant(principal, tenant_id)
    rows = (
        await session.scalars(
            select(Incident)
            .where(Incident.tenant_id == tenant_id)
            .order_by(Incident.created_at.desc())
            .limit(limit).offset(offset)
        )
    ).all()
    return [
        {
            "id": row.id,
            "domain": row.domain,
            "title": row.title,
            "severity": row.severity,
            "status": row.status,
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]


@router.get("/dlq")
async def dlq(
    tenant_id: str = Query(...),
    limit: int = Query(25, ge=1, le=100),
    offset: int = Query(0, ge=0),
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
) -> list[dict]:
    require_tenant(principal, tenant_id)
    rows = (
        await session.scalars(
            select(OutboxEvent)
            .where(OutboxEvent.tenant_id == tenant_id, OutboxEvent.status == "DEAD_LETTER")
            .order_by(OutboxEvent.created_at.desc())
            .limit(limit).offset(offset)
        )
    ).all()
    return [
        {
            "id": row.id,
            "topic": row.topic,
            "attempts": row.attempts,
            "last_error": row.last_error,
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]


@router.post("/synthetic-incidents", status_code=201)
async def trigger_synthetic(
    request: SyntheticIncidentRequest,
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
) -> dict:
    require_tenant(principal, request.tenant_id)
    if not settings().synthetic_controls_enabled:
        raise HTTPException(403, "synthetic controls are disabled")
    if request.domain not in registry().names():
        raise HTTPException(422, "unknown domain")
    payload = IncidentCreate(
        tenant_id=request.tenant_id,
        domain=request.domain,
        incident_type="synthetic_validation",
        title=f"Synthetic validation incident: {request.domain}",
        severity=request.severity,
        evidence=[{"kind": "synthetic", "source": "operations-dashboard", "generated": True}],
    )
    record = await IncidentService(session).create(payload, principal, f"dashboard-{uuid4()}")
    return {
        "id": record["id"],
        "tenant_id": request.tenant_id,
        "domain": request.domain,
        "status": record["status"],
        "synthetic": True,
    }
