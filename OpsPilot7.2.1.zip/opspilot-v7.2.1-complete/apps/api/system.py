"""Read-only system catalog, safe configuration and health surfaces."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from platform_core.config import settings
from platform_core.database import get_session
from platform_core.identity import Principal, authenticate

router = APIRouter(prefix="/v1/system", tags=["system"])
from platform_core.service_catalog import serialized_services



def admin(principal: Principal) -> None:
    if "platform_admin" not in principal.roles:
        from fastapi import HTTPException

        raise HTTPException(403, "platform_admin role required")


@router.get("/services")
async def services(principal: Principal = Depends(authenticate)) -> dict:
    admin(principal)
    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "services": serialized_services(),
        "note": (
            "Runtime state is reported by the owning platform; "
            "this catalog does not issue restart or scaling commands."
        ),
    }


@router.get("/configuration")
async def configuration(principal: Principal = Depends(authenticate)) -> dict:
    admin(principal)
    cfg = settings()
    return {
        "env": cfg.env,
        "auth_mode": cfg.auth_mode,
        "oidc_configured": bool(cfg.oidc_issuer and cfg.oidc_audience and cfg.oidc_jwks_url),
        "database_driver": cfg.database_url.split(":", 1)[0],
        "mlflow_tracking_uri": cfg.mlflow_tracking_uri,
        "allowed_hosts": cfg.allowed_hosts,
        "cors_origins": cfg.cors_origins,
        "secrets_redacted": True,
    }


@router.get("/readiness")
async def readiness(session: AsyncSession = Depends(get_session)) -> dict:
    await session.execute(text("SELECT 1"))
    return {"status": "ready", "database": "reachable"}


@router.get("/liveness")
async def liveness() -> dict:
    return {"status": "alive"}
