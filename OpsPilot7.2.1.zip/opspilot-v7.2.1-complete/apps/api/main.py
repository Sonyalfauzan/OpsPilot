"""OpsPilot control-plane API."""

from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4

from fastapi import WebSocket, WebSocketDisconnect, Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, generate_latest
from sqlalchemy.ext.asyncio import AsyncSession

from agents.incident import investigate
from apps.api.admin import router as admin_router
from apps.api.operations import router as operations_router
from apps.api.system import router as system_router
from platform_core.config import settings
from platform_core.rate_limit import RateLimitMiddleware
from platform_core.live import hub
from platform_core.incidents import validate_transition
from platform_core.database import Incident
from platform_core.database import get_session
from platform_core.identity import Principal, authenticate, authenticate_websocket, require_tenant
from platform_core.logging import configure_logging, correlation_id
from platform_core.schemas import ActionExecute, ApprovalRequest, IncidentCreate, IncidentResponse
from platform_core.security import create_approval_token
from platform_core.services import ApprovalService, IncidentService

INCIDENTS_CREATED = Counter(
    "opspilot_incidents_created_total", "Incidents created", ["domain", "severity"]
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    configure_logging()
    settings().warn_for_local_defaults()
    yield


app = FastAPI(
    title="OpsPilot Control Plane",
    version="7.2.1",
    description=(
        "Portfolio control plane with tenant isolation, idempotency, and replay-safe approvals."
    ),
    lifespan=lifespan,
    openapi_tags=[{"name": "health"}, {"name": "incidents"}, {"name": "approvals"}],
)


app.add_middleware(RateLimitMiddleware)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings().allowed_hosts)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings().cors_origins,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "X-API-Key",
        "X-Correlation-ID",
        "Idempotency-Key",
    ],
)
app.include_router(operations_router)
app.include_router(admin_router)
app.include_router(system_router)
app.mount("/static", StaticFiles(directory=Path(__file__).with_name("ui")), name="static")


@app.get("/dashboard", response_class=HTMLResponse, include_in_schema=False)
async def dashboard() -> HTMLResponse:
    path = Path(__file__).with_name("ui") / "dashboard.html"
    return HTMLResponse(path.read_text(encoding="utf-8"))


@app.get("/queue", include_in_schema=False)
async def queue_alias() -> RedirectResponse:
    return RedirectResponse("/dashboard", status_code=307)


@app.get("/admin", response_class=HTMLResponse, include_in_schema=False)
async def admin_console() -> HTMLResponse:
    path = Path(__file__).with_name("ui") / "admin.html"
    return HTMLResponse(path.read_text(encoding="utf-8"))


@app.middleware("http")
async def correlation_middleware(request: Request, call_next):
    value = request.headers.get("X-Correlation-ID", str(uuid4()))
    token = correlation_id.set(value)
    try:
        response = await call_next(request)
        response.headers["X-Correlation-ID"] = value
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; "
            "script-src 'self'; connect-src 'self'"
        )
        response.headers["Cache-Control"] = "no-store"
        return response
    finally:
        correlation_id.reset(token)


@app.get("/health", tags=["health"])
async def health() -> dict:
    return {"status": "ok"}


@app.get("/metrics", tags=["health"])
async def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/v1/incidents", response_model=IncidentResponse, tags=["incidents"], status_code=201)
async def create_incident(
    body: IncidentCreate,
    idempotency_key: str = Header(alias="Idempotency-Key", min_length=8),
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
):
    result = await IncidentService(session).create(body, principal, idempotency_key)
    INCIDENTS_CREATED.labels(body.domain, body.severity).inc()
    return result


@app.get("/v1/incidents/{incident_id}", tags=["incidents"])
async def get_incident(
    incident_id: str,
    tenant_id: str,
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
):
    incident = await IncidentService(session).get(incident_id, tenant_id, principal)
    if not incident:
        raise HTTPException(404, "incident not found")
    return {column.name: getattr(incident, column.name) for column in incident.__table__.columns}


@app.post("/v1/incidents/{incident_id}/investigate", tags=["incidents"])
async def investigate_incident(
    incident_id: str,
    tenant_id: str,
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
):
    incident = await IncidentService(session).get(incident_id, tenant_id, principal)
    if not incident:
        raise HTTPException(404, "incident not found")
    return investigate(incident.domain, incident.incident_type, incident.evidence)


@app.post("/v1/approvals", tags=["approvals"])
async def issue_approval(body: ApprovalRequest, principal: Principal = Depends(authenticate)):
    require_tenant(principal, body.tenant_id)
    if "approver" not in principal.roles and "platform_admin" not in principal.roles:
        raise HTTPException(403, "approver role required")
    token = create_approval_token(**body.model_dump())
    return {"token": token, "expires_in": body.ttl_seconds}


@app.post("/v1/actions/execute", tags=["approvals"])
async def execute_action(
    body: ActionExecute,
    principal: Principal = Depends(authenticate),
    session: AsyncSession = Depends(get_session),
):
    require_tenant(principal, body.tenant_id)
    try:
        claims = await ApprovalService(session).consume_once(
            body.approval_token, **body.model_dump(exclude={"approval_token"})
        )
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    return {"status": "EXECUTED", "action": body.action, "approved_by": claims["sub"]}


@app.websocket("/v1/live/{tenant_id}")
async def live_updates(websocket: WebSocket, tenant_id: str):
    try:
        await authenticate_websocket(websocket, tenant_id)
    except HTTPException:
        await websocket.close(code=4401)
        return
    await hub.connect(tenant_id, websocket)
    bridge = asyncio.create_task(hub.bridge(tenant_id))
    try:
        while True: await websocket.receive_text()
    except WebSocketDisconnect:
        hub.disconnect(tenant_id, websocket)
    finally:
        bridge.cancel()

@app.patch("/v1/incidents/{incident_id}/status", tags=["incidents"])
async def transition_incident(incident_id: str, tenant_id: str, target: str, principal: Principal = Depends(authenticate), session: AsyncSession = Depends(get_session)):
    require_tenant(principal, tenant_id)
    row=await session.get(Incident,incident_id)
    if not row or row.tenant_id != tenant_id: raise HTTPException(404,"incident not found")
    try: row.status=validate_transition(row.status,target).value
    except ValueError as exc: raise HTTPException(409,str(exc)) from exc
    await session.commit(); await hub.publish(tenant_id,{"type":"incident.status.changed","id":row.id,"status":row.status})
    return {"id":row.id,"status":row.status}
