"""Audited, paginated tenant administration API."""
import hashlib,secrets
from datetime import UTC,datetime,timedelta
from uuid import uuid4
from fastapi import APIRouter,Depends,HTTPException,Query
from pydantic import BaseModel,ConfigDict,Field
from sqlalchemy import func,select
from sqlalchemy.ext.asyncio import AsyncSession
from platform_core.audit import add_audit
from platform_core.database import ApiCredential,FeatureFlag,Tenant,UserProfile,get_session
from platform_core.identity import Principal,authenticate
router=APIRouter(prefix='/v1/admin',tags=['administration'])
ROLES={'platform_admin','data_engineer','data_analyst','data_scientist','mlops_engineer','incident_manager','approver','viewer'}
def require_admin(p):
    if 'platform_admin' not in p.roles: raise HTTPException(403,'platform_admin role required')
def validate_roles(values):
    unknown=set(values)-ROLES
    if unknown: raise HTTPException(422,f'unknown roles: {sorted(unknown)}')
def paged(items,total,limit,offset): return {'items':items,'total':total,'limit':limit,'offset':offset}
class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class TenantInput(Strict): id:str=Field(pattern=r'^[a-z0-9-]{3,64}$');name:str=Field(min_length=3,max_length=160)
class UserInput(Strict): username:str=Field(pattern=r'^[a-z0-9._-]{3,128}$');display_name:str=Field(min_length=1,max_length=160);email:str;tenant_id:str;roles:list[str]=Field(min_length=1)
class UserPatch(Strict): display_name:str|None=None;roles:list[str]|None=None;active:bool|None=None
class CredentialInput(Strict): name:str=Field(min_length=3,max_length=128);tenant_id:str;scopes:list[str]=Field(default_factory=lambda:['read']);ttl_days:int=Field(default=30,ge=1,le=365)
class FlagInput(Strict): key:str=Field(pattern=r'^[a-z0-9._-]{3,128}$');enabled:bool=False;tenant_id:str|None=None;description:str=Field(default='',max_length=300)
@router.get('/tenants')
async def tenants(limit:int=Query(25,ge=1,le=100),offset:int=Query(0,ge=0),principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);total=await session.scalar(select(func.count()).select_from(Tenant));rows=(await session.scalars(select(Tenant).order_by(Tenant.id).limit(limit).offset(offset))).all();return paged([{'id':r.id,'name':r.name,'active':r.active} for r in rows],total,limit,offset)
@router.post('/tenants',status_code=201)
async def create_tenant(body:TenantInput,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal)
    if await session.get(Tenant,body.id): raise HTTPException(409,'tenant already exists')
    row=Tenant(**body.model_dump());session.add(row);await session.flush();add_audit(session,tenant_id=row.id,actor=principal.subject,event_type='admin.tenant.created',payload={'tenant_id':row.id,'name':row.name});await session.commit();return {'id':row.id,'name':row.name,'active':row.active}
@router.get('/users')
async def users(tenant_id:str|None=Query(None),limit:int=Query(25,ge=1,le=100),offset:int=Query(0,ge=0),principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);q=select(UserProfile)
    if tenant_id:q=q.where(UserProfile.tenant_id==tenant_id)
    total=await session.scalar(select(func.count()).select_from(q.subquery()));rows=(await session.scalars(q.order_by(UserProfile.username).limit(limit).offset(offset))).all();return paged([{'id':r.id,'username':r.username,'display_name':r.display_name,'email':r.email,'tenant_id':r.tenant_id,'roles':r.roles,'active':r.active} for r in rows],total,limit,offset)
@router.post('/users',status_code=201)
async def create_user(body:UserInput,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);validate_roles(body.roles)
    if not await session.get(Tenant,body.tenant_id):raise HTTPException(422,'unknown tenant')
    if await session.scalar(select(UserProfile).where(UserProfile.username==body.username)):raise HTTPException(409,'username already exists')
    row=UserProfile(id=str(uuid4()),**body.model_dump());session.add(row);add_audit(session,tenant_id=body.tenant_id,actor=principal.subject,event_type='admin.user.created',payload={'user_id':row.id,'username':row.username,'roles':row.roles});await session.commit();return {'id':row.id,'username':row.username,'active':row.active}
@router.patch('/users/{user_id}')
async def update_user(user_id:str,body:UserPatch,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);row=await session.get(UserProfile,user_id)
    if not row:raise HTTPException(404,'user not found')
    changes=body.model_dump(exclude_none=True)
    if 'roles' in changes:validate_roles(changes['roles'])
    before={'roles':row.roles,'active':row.active}
    for k,v in changes.items():setattr(row,k,v)
    add_audit(session,tenant_id=row.tenant_id,actor=principal.subject,event_type='admin.user.updated',payload={'user_id':row.id,'before':before,'changes':changes});await session.commit();return {'id':row.id,'username':row.username,'active':row.active,'roles':row.roles}
@router.post('/credentials',status_code=201)
async def create_credential(body:CredentialInput,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal)
    if not await session.get(Tenant,body.tenant_id):raise HTTPException(422,'unknown tenant')
    raw='op_'+secrets.token_urlsafe(32);row=ApiCredential(id=str(uuid4()),name=body.name,tenant_id=body.tenant_id,key_hash=hashlib.sha256(raw.encode()).hexdigest(),scopes=body.scopes,expires_at=datetime.now(UTC)+timedelta(days=body.ttl_days));session.add(row);add_audit(session,tenant_id=row.tenant_id,actor=principal.subject,event_type='admin.credential.issued',payload={'credential_id':row.id,'name':row.name,'scopes':row.scopes,'expires_at':row.expires_at.isoformat()});await session.commit();return {'id':row.id,'api_key':raw,'expires_at':row.expires_at.isoformat(),'warning':'This value is shown once.'}
@router.delete('/credentials/{credential_id}',status_code=204)
async def revoke_credential(credential_id:str,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);row=await session.get(ApiCredential,credential_id)
    if not row:raise HTTPException(404,'credential not found')
    row.active=False;add_audit(session,tenant_id=row.tenant_id,actor=principal.subject,event_type='admin.credential.revoked',payload={'credential_id':row.id,'name':row.name});await session.commit()
@router.get('/credentials/expiring')
async def expiring_credentials(days:int=Query(7,ge=1,le=90),limit:int=Query(25,ge=1,le=100),offset:int=Query(0,ge=0),principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);cutoff=datetime.now(UTC)+timedelta(days=days);q=select(ApiCredential).where(ApiCredential.active.is_(True),ApiCredential.expires_at<=cutoff);total=await session.scalar(select(func.count()).select_from(q.subquery()));rows=(await session.scalars(q.order_by(ApiCredential.expires_at).limit(limit).offset(offset))).all();return paged([{'id':r.id,'name':r.name,'tenant_id':r.tenant_id,'expires_at':r.expires_at.isoformat(),'scopes':r.scopes} for r in rows],total,limit,offset)
@router.get('/feature-flags')
async def flags(limit:int=Query(25,ge=1,le=100),offset:int=Query(0,ge=0),principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal);total=await session.scalar(select(func.count()).select_from(FeatureFlag));rows=(await session.scalars(select(FeatureFlag).order_by(FeatureFlag.key).limit(limit).offset(offset))).all();return paged([{'key':r.key,'enabled':r.enabled,'tenant_id':r.tenant_id,'description':r.description} for r in rows],total,limit,offset)
@router.put('/feature-flags/{key}')
async def put_flag(key:str,body:FlagInput,principal:Principal=Depends(authenticate),session:AsyncSession=Depends(get_session)):
    require_admin(principal)
    if key!=body.key:raise HTTPException(422,'path and body keys differ')
    if body.tenant_id and not await session.get(Tenant,body.tenant_id):raise HTTPException(422,'unknown tenant')
    row=await session.get(FeatureFlag,key)
    if row is None:row=FeatureFlag(**body.model_dump());session.add(row)
    else:
        for field,value in body.model_dump().items():setattr(row,field,value)
    add_audit(session,tenant_id=body.tenant_id or principal.tenant_id,actor=principal.subject,event_type='admin.feature_flag.updated',payload=body.model_dump());await session.commit();return body.model_dump()
