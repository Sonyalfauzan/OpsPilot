const r = document.querySelector('main');
const q = id => r.querySelector('#' + id);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
} [c]));
const h = () => ({
  'X-API-Key': q('key').value,
  'Content-Type': 'application/json'
});
async function api(path, opt = {}) {
  const x = await fetch(path, {
    ...opt,
    headers: {
      ...h(),
      ...(opt.headers || {})
    }
  });
  if (!x.ok) throw new Error(`${x.status} ${await x.text()}`);
  return x.status === 204 ? null : x.json()
}

function list(items, render) {
  return items.length ? items.map(render).join('') : '<div class="muted">No records.</div>'
}
async function load() {
  try {
    q('status').textContent = 'Loading…';
    const [t, u, f, s, c] = await Promise.all([api('/v1/admin/tenants'), api('/v1/admin/users'), api('/v1/admin/feature-flags'), api('/v1/system/services'), api('/v1/system/configuration')]);
    q('tenants').innerHTML = list(t.items || t, x => `<div class="row"><b>${esc(x.name)}</b><span>${esc(x.id)} · ${x.active?'active':'disabled'}</span></div>`);
    q('users').innerHTML = list(u.items || u, x => `<div class="row"><span><b>${esc(x.display_name)}</b><br><span class="muted">${esc(x.username)} · ${esc(x.email)}</span></span><span>${esc(x.roles.join(', '))}</span></div>`);
    q('flags').innerHTML = list(f.items || f, x => `<div class="row"><b>${esc(x.key)}</b><span>${x.enabled?'enabled':'disabled'}</span></div>`);
    q('services').innerHTML = list(s.services, x => `<div class="row"><span><b>${esc(x.name)}</b><br><span class="muted">${esc(x.category)}</span></span><span>${esc(x.profile)}</span></div>`);
    q('config').innerHTML = Object.entries(c).map(([k, v]) => `<div class="row"><b>${esc(k)}</b><span>${esc(Array.isArray(v)?v.join(', '):v)}</span></div>`).join('');
    q('status').textContent = 'Administration data loaded.'
  } catch (e) {
    q('status').textContent = 'Unable to load: ' + e.message
  }
}
async function createTenant() {
  try {
    await api('/v1/admin/tenants', {
      method: 'POST',
      body: JSON.stringify({
        id: q('newTenantId').value.trim(),
        name: q('newTenantName').value.trim()
      })
    });
    await load()
  } catch (e) {
    q('status').textContent = e.message
  }
}
async function createUser() {
  try {
    await api('/v1/admin/users', {
      method: 'POST',
      body: JSON.stringify({
        username: q('username').value.trim(),
        display_name: q('displayName').value.trim(),
        email: q('email').value.trim(),
        tenant_id: q('tenant').value.trim(),
        roles: q('roles').value.split(',').map(x => x.trim()).filter(Boolean)
      })
    });
    await load()
  } catch (e) {
    q('status').textContent = e.message
  }
}
async function saveFlag() {
  try {
    const key = q('flagKey').value.trim();
    await api('/v1/admin/feature-flags/' + encodeURIComponent(key), {
      method: 'PUT',
      body: JSON.stringify({
        key,
        enabled: q('flagEnabled').value === 'true',
        tenant_id: q('tenant').value.trim(),
        description: q('flagDescription').value.trim()
      })
    });
    await load()
  } catch (e) {
    q('status').textContent = e.message
  }
}
q('refresh').addEventListener('click', load);
q('createTenant').addEventListener('click', createTenant);
q('createUser').addEventListener('click', createUser);
q('saveFlag').addEventListener('click', saveFlag);
load();
