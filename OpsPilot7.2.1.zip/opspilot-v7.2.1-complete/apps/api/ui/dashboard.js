const $ = id => document.getElementById(id);

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  } [c]));
}

function headers() {
  return {
    'X-API-Key': $('key').value,
    'Content-Type': 'application/json'
  };
}
async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      ...headers(),
      ...(options.headers || {})
    }
  });
  if (!response.ok) throw new Error(`${response.status} ${await response.text()}`);
  return response.json();
}

function rows(items, type) {
  if (!items.length) return '<div class="meta">No records.</div>';
  return items.map(x => `<div class="row"><div><strong>${esc(type==='i'?x.title:x.topic)}</strong><div class="meta">${esc(type==='i'?`${x.domain} · ${x.status}`:`attempts ${x.attempts} · ${x.last_error||'no error text'}`)}</div></div><div class="${type==='i'?'sev':'dead'}">${esc(type==='i'?x.severity:'DLQ')}</div></div>`).join('');
}
async function load() {
  try {
    $('status').textContent = 'Loading…';
    const t = encodeURIComponent($('tenant').value.trim());
    const [s, i, d] = await Promise.all([request(`/v1/operations/summary?tenant_id=${t}`), request(`/v1/operations/incidents?tenant_id=${t}`), request(`/v1/operations/dlq?tenant_id=${t}`)]);
    $('total').textContent = s.incidents_total;
    $('active').textContent = s.incidents_active;
    $('pending').textContent = s.outbox_pending;
    $('dead').textContent = s.outbox_dead_letter;
    $('incidents').innerHTML = rows(i, 'i');
    $('dlq').innerHTML = rows(d, 'd');
    $('status').textContent = `Updated ${new Date(s.generated_at).toLocaleString()}`;
  } catch (e) {
    $('status').textContent = `Unable to load: ${e.message}`;
  }
}
async function trigger() {
  try {
    $('status').textContent = 'Creating synthetic incident…';
    await request('/v1/operations/synthetic-incidents', {
      method: 'POST',
      body: JSON.stringify({
        tenant_id: $('tenant').value.trim(),
        domain: $('domain').value,
        severity: 'SEV-3'
      })
    });
    await load();
  } catch (e) {
    $('status').textContent = `Unable to create incident: ${e.message}`;
  }
}
$('refresh').addEventListener('click', load);
$('trigger').addEventListener('click', trigger);
load();

function connectLiveUpdates(){const tenant=document.querySelector('#tenant')?.value;if(!tenant)return;const p=location.protocol==='https:'?'wss:':'ws:';const ws=new WebSocket(`${p}//${location.host}/v1/live/${encodeURIComponent(tenant)}?api_key=${encodeURIComponent($('key').value)}`);ws.addEventListener('message',()=>load());ws.addEventListener('close',()=>setTimeout(connectLiveUpdates,5000));}
connectLiveUpdates();
