"""Authenticated, tenant-scoped generic model serving API."""

import json
from pathlib import Path

import joblib
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field

from ml.explainability import anomaly_explanation, linear_contributions
from platform_core.identity import Principal, authenticate, require_tenant
from platform_core.registry import registry

app = FastAPI(title="OpsPilot Model Serving", version="7.2.1")


class PredictRequest(BaseModel):
    tenant_id: str = Field(examples=["tenant-alpha"])
    domain: str = Field(examples=["logistics"])
    features: dict[str, float]


@app.get("/health", tags=["health"])
async def health() -> dict:
    return {"status": "ok", "domains": registry().names()}


@app.post("/v1/predict", tags=["inference"])
async def predict(request: PredictRequest, principal: Principal = Depends(authenticate)) -> dict:
    require_tenant(principal, request.tenant_id)
    plugin = registry().get(request.domain)
    base = Path("data") / request.tenant_id / "models" / request.domain
    if not (base / "model.joblib").exists():
        raise HTTPException(404, "model not trained")
    metadata = json.loads((base / "metadata.json").read_text(encoding="utf-8"))
    missing = sorted(set(metadata["features"]) - request.features.keys())
    if missing:
        raise HTTPException(422, {"missing_features": missing})
    try:
        result = plugin.predict(joblib.load(base / "model.joblib"), request.features, metadata)
    except (ValueError, KeyError, TypeError) as exc:
        raise HTTPException(422, str(exc)) from exc
    feature_names = metadata["features"]
    values = [request.features[name] for name in feature_names]
    model = joblib.load(base / "model.joblib")
    if hasattr(model, "coef_"):
        coefficients = model.coef_[0] if getattr(model.coef_, "ndim", 1) > 1 else model.coef_
        intercept = model.intercept_[0] if hasattr(model.intercept_, "__len__") else model.intercept_
        explanation = {"method": "linear-contribution", **linear_contributions(feature_names, values, coefficients, intercept)}
    else:
        explanation = anomaly_explanation(feature_names, values, metadata.get("feature_mean", [0]*len(values)), metadata.get("feature_scale", [1]*len(values)))
    return {
        "tenant_id": request.tenant_id,
        "domain": request.domain,
        "model_version": metadata["model_version"],
        "explanation": explanation,
        **result,
    }
