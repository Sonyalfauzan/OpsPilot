# Final Scope

OpsPilot v7.1 closes the remaining application-level portfolio gaps identified by the repository-wide audit. It includes operations and administration dashboards, tenant and user-profile management, approved role assignment, API credential lifecycle metadata, feature flags, a service catalog, redacted configuration, security response headers, trusted-host and CORS policy, separate liveness and readiness checks, database migrations, synthetic administration seed data, and service health dependencies.

The project does not store passwords, expose secret values, restart containers from a browser, scale production workloads, or grant unrestricted identity-provider administration. Those controls belong to the identity provider, orchestrator, CI/CD system and secret manager. This is deliberate separation of responsibility, not an unfinished module.

External environmental claims continue to require authorized target infrastructure. See `validation/external-status.yaml`.
