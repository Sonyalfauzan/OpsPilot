"""Local lexical RAG with deterministic chunking and duplicate suppression."""

import math
import re
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path


@dataclass(frozen=True)
class Chunk:
    source: str
    chunk_id: str
    start: int
    end: int
    text: str
    content_hash: str


def tokenize(value: str) -> list[str]:
    return re.findall(r"[a-zA-Z0-9_]+", value.lower())


def jaccard(left: str, right: str) -> float:
    a, b = set(tokenize(left)), set(tokenize(right))
    return len(a & b) / max(len(a | b), 1)


class LocalRAG:
    def __init__(self, chunk_size: int = 1200, overlap: int = 200) -> None:
        if overlap >= chunk_size:
            raise ValueError("overlap must be smaller than chunk size")
        self.chunk_size, self.overlap, self.chunks = chunk_size, overlap, []

    def index(self, root: str | Path) -> int:
        self.chunks = []
        seen = set()
        stride = self.chunk_size - self.overlap
        for path in sorted(Path(root).rglob("*.md")):
            text = path.read_text(encoding="utf-8", errors="ignore")
            for start in range(0, len(text), stride):
                content = text[start : start + self.chunk_size].strip()
                if not content:
                    continue
                digest = sha256(" ".join(tokenize(content)).encode()).hexdigest()
                if digest in seen:
                    continue
                seen.add(digest)
                self.chunks.append(
                    Chunk(
                        str(path), f"{path}:{start}", start, start + len(content), content, digest
                    )
                )
        return len(self.chunks)

    def search(self, query: str, k: int = 4, candidate_count: int = 16) -> list[dict]:
        query_tokens = set(tokenize(query))
        scored = []
        for chunk in self.chunks:
            tokens = set(tokenize(chunk.text))
            score = len(query_tokens & tokens) / math.sqrt(max(len(tokens), 1))
            if score > 0:
                scored.append((score, chunk))
        selected, sources = [], {}
        for score, chunk in sorted(scored, key=lambda item: item[0], reverse=True)[
            :candidate_count
        ]:
            if sources.get(chunk.source, 0) >= 2:
                continue
            if any(jaccard(chunk.text, item["text"]) > 0.92 for item in selected):
                continue
            selected.append(
                {
                    "source": chunk.source,
                    "chunk_id": chunk.chunk_id,
                    "text": chunk.text,
                    "score": score,
                }
            )
            sources[chunk.source] = sources.get(chunk.source, 0) + 1
            if len(selected) == k:
                break
        return selected

    def answer(self, query: str) -> dict:
        hits = self.search(query)
        return {
            "answer": "Evidence retrieved from portfolio runbooks.",
            "citations": [hit["source"] for hit in hits],
            "contexts": hits,
        }
