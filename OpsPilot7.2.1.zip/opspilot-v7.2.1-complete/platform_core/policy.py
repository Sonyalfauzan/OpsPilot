READ_TOOLS = {
    "get_pipeline_status",
    "get_data_quality_report",
    "query_metric",
    "get_model_versions",
    "get_drift_report",
}
WRITE_TOOLS = {"create_incident", "start_canary", "rollback_model"}
ROLE_GRANTS = {
    "analyst": READ_TOOLS,
    "mlops": READ_TOOLS | {"start_canary", "rollback_model"},
    "incident_manager": READ_TOOLS | {"create_incident"},
}


def authorize(tool: str, roles: list[str], has_approval: bool = False) -> None:
    allowed = set().union(*(ROLE_GRANTS.get(r, set()) for r in roles))
    if tool not in allowed:
        raise PermissionError(f"tool not allowed: {tool}")
    if tool in WRITE_TOOLS and (not has_approval):
        raise PermissionError("valid approval required")
