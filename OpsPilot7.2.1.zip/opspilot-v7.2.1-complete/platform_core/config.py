"""Application configuration with secure production guards."""

import logging
import os
from functools import lru_cache

from pydantic import BaseModel, model_validator

LOGGER = logging.getLogger(__name__)


class Settings(BaseModel):
    env: str = os.getenv("ENV", "local")
    database_url: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./opspilot.db")
    sync_database_url: str = os.getenv("SYNC_DATABASE_URL", "sqlite:///./opspilot.db")
    api_key: str = os.getenv("API_KEY", "local-development-key-change-me")
    approval_signing_key: str = os.getenv(
        "APPROVAL_SIGNING_KEY", "local-approval-signing-key-change-me-32-plus"
    )
    mlflow_tracking_uri: str = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")
    auth_mode: str = os.getenv("AUTH_MODE", "api_key")
    oidc_issuer: str = os.getenv("OIDC_ISSUER", "")
    oidc_audience: str = os.getenv("OIDC_AUDIENCE", "")
    oidc_jwks_url: str = os.getenv("OIDC_JWKS_URL", "")
    allowed_hosts: list[str] = [
        item.strip()
        for item in os.getenv("ALLOWED_HOSTS", "localhost,127.0.0.1,test").split(",")
        if item.strip()
    ]
    cors_origins: list[str] = [
        item.strip()
        for item in os.getenv("CORS_ORIGINS", "http://localhost:8000").split(",")
        if item.strip()
    ]
    synthetic_controls_enabled: bool = (
        os.getenv("SYNTHETIC_CONTROLS_ENABLED", "true").lower() == "true"
    )
    rate_limit_per_minute: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "120"))

    @model_validator(mode="after")
    def validate_security(self) -> "Settings":
        if self.env == "production":
            if self.auth_mode != "oidc":
                raise ValueError("production requires AUTH_MODE=oidc")
            if not self.oidc_issuer or not self.oidc_audience or (not self.oidc_jwks_url):
                raise ValueError("production OIDC settings are incomplete")
            if "change-me" in self.approval_signing_key or len(self.approval_signing_key) < 32:
                raise ValueError("production approval signing key is weak")
            if self.database_url.startswith("sqlite"):
                raise ValueError("production requires a durable database")
        return self

    def warn_for_local_defaults(self) -> None:
        if self.env != "production" and "change-me" in self.approval_signing_key:
            LOGGER.warning(
                "Using a development approval key; never use it outside the portfolio demo"
            )


@lru_cache
def settings() -> Settings:
    return Settings()
