from enum import StrEnum
class IncidentStatus(StrEnum): OPEN='OPEN'; INVESTIGATING='INVESTIGATING'; RESOLVED='RESOLVED'; CLOSED='CLOSED'
TRANSITIONS={IncidentStatus.OPEN:{IncidentStatus.INVESTIGATING},IncidentStatus.INVESTIGATING:{IncidentStatus.RESOLVED},IncidentStatus.RESOLVED:{IncidentStatus.CLOSED},IncidentStatus.CLOSED:set()}
def validate_transition(current,target):
    source=IncidentStatus(current);destination=IncidentStatus(target)
    if destination not in TRANSITIONS[source]: raise ValueError(f'invalid incident transition: {source} -> {destination}')
    return destination
