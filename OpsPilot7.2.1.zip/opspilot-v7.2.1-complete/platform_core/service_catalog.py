"""Validated, cached service catalog loaded from repository configuration."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field, HttpUrl, model_validator

CATALOG_PATH = Path(__file__).with_name("resources") / "services.yaml"
ALLOWED_PROFILES = {"lite", "full", "validation"}


class ServiceDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(pattern=r"^[a-z0-9-]{2,64}$")
    category: str = Field(pattern=r"^[a-z0-9-]{2,64}$")
    url: HttpUrl | None = None
    profile: str

    @model_validator(mode="after")
    def validate_profile(self) -> "ServiceDefinition":
        if self.profile not in ALLOWED_PROFILES:
            raise ValueError(f"unsupported service profile: {self.profile}")
        return self


class ServiceCatalog(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str = "1"
    services: list[ServiceDefinition] = Field(min_length=1)

    @model_validator(mode="after")
    def unique_names(self) -> "ServiceCatalog":
        names = [service.name for service in self.services]
        if len(names) != len(set(names)):
            raise ValueError("service names must be unique")
        return self


@lru_cache(maxsize=1)
def load_service_catalog(path: Path = CATALOG_PATH) -> ServiceCatalog:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    return ServiceCatalog.model_validate(payload)


def serialized_services() -> list[dict]:
    return [
        service.model_dump(mode="json")
        for service in load_service_catalog().services
    ]
