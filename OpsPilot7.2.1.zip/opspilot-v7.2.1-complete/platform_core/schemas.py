"""Validated API contracts."""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field


def utc_now() -> datetime:
    return datetime.now(UTC)


class IncidentCreate(BaseModel):
    tenant_id: str = Field(min_length=1, max_length=64, examples=["tenant-alpha"])
    domain: str = Field(min_length=1, max_length=64, examples=["logistics"])
    incident_type: str = Field(min_length=1, max_length=80)
    title: str = Field(min_length=1, max_length=240)
    severity: str = Field(pattern="^SEV-[1-4]$", examples=["SEV-2"])
    evidence: list[dict[str, Any]] = Field(default_factory=list)


class IncidentResponse(BaseModel):
    id: str
    status: str


class ApprovalRequest(BaseModel):
    tenant_id: str
    incident_id: str
    action: str
    action_arguments: dict[str, Any] = Field(default_factory=dict)
    approver_id: str
    ttl_seconds: int = Field(default=900, ge=60, le=3600)


class ActionExecute(BaseModel):
    tenant_id: str
    incident_id: str
    action: str
    action_arguments: dict[str, Any]
    approval_token: str
