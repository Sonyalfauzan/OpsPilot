"""Local API-key identity and production OIDC/JWKS validation."""

import hmac
from dataclasses import dataclass

import jwt
from fastapi import Header, HTTPException
from jwt import PyJWKClient

from platform_core.config import settings


@dataclass(frozen=True)
class Principal:
    subject: str
    tenant_id: str
    roles: tuple[str, ...]


class TokenValidator:
    def __init__(self) -> None:
        config = settings()
        self.config = config
        self.jwks = (
            PyJWKClient(config.oidc_jwks_url, cache_keys=True) if config.oidc_jwks_url else None
        )

    def validate(self, token: str) -> Principal:
        if not self.jwks:
            raise HTTPException(503, "OIDC validator is not configured")
        try:
            signing_key = self.jwks.get_signing_key_from_jwt(token)
            claims = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self.config.oidc_audience,
                issuer=self.config.oidc_issuer,
            )
        except jwt.PyJWTError as exc:
            raise HTTPException(401, "invalid bearer token") from exc
        roles = tuple(claims.get("realm_access", {}).get("roles", []))
        tenant_id = claims.get("tenant_id")
        if not tenant_id or not roles:
            raise HTTPException(403, "required tenant or role claim missing")
        return Principal(claims["sub"], tenant_id, roles)


async def authenticate(
    authorization: str = Header(default=""), x_api_key: str = Header(default="")
) -> Principal:
    config = settings()
    if config.auth_mode == "oidc":
        if not authorization.startswith("Bearer "):
            raise HTTPException(401, "bearer token required")
        return TokenValidator().validate(authorization.removeprefix("Bearer ").strip())
    if not hmac.compare_digest(x_api_key, config.api_key):
        raise HTTPException(401, "invalid API key")
    return Principal("portfolio-admin", "tenant-alpha", ("platform_admin", "approver"))


def require_tenant(principal: Principal, tenant_id: str) -> None:
    if principal.tenant_id != tenant_id and "platform_admin" not in principal.roles:
        raise HTTPException(403, "cross-tenant access denied")

async def authenticate_websocket(websocket, tenant_id: str) -> Principal:
    """Authenticate a WebSocket before accept, using the same API-key/OIDC policy."""
    config=settings();authorization=websocket.headers.get("authorization","");api_key=websocket.headers.get("x-api-key") or websocket.query_params.get("api_key","")
    if config.auth_mode=="oidc":
        token=authorization.removeprefix("Bearer ").strip() if authorization.startswith("Bearer ") else websocket.query_params.get("access_token","")
        if not token: raise HTTPException(401,"bearer token required")
        principal=TokenValidator().validate(token)
    else:
        if not hmac.compare_digest(api_key,config.api_key): raise HTTPException(401,"invalid API key")
        principal=Principal("portfolio-admin","tenant-alpha",("platform_admin","approver"))
    require_tenant(principal,tenant_id);return principal
