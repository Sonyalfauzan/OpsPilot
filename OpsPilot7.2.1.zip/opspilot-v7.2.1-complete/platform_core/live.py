"""Authenticated local WebSocket hub with optional Redis cross-process fan-out."""
from __future__ import annotations
import asyncio,json,os
from collections import defaultdict
REDIS_URL=os.getenv('REDIS_URL','redis://redis:6379/0')
class LiveHub:
    def __init__(self): self.clients=defaultdict(set)
    async def connect(self,tenant,ws): await ws.accept();self.clients[tenant].add(ws)
    def disconnect(self,tenant,ws): self.clients[tenant].discard(ws)
    async def publish_local(self,tenant,event):
        for ws in tuple(self.clients[tenant]):
            try: await ws.send_json(event)
            except Exception: self.disconnect(tenant,ws)
    async def publish(self,tenant,event):
        await self.publish_local(tenant,event)
        try:
            import redis.asyncio as redis
            client=redis.from_url(REDIS_URL);await client.publish(f'opspilot.live.{tenant}',json.dumps(event));await client.aclose()
        except Exception: pass
    async def bridge(self,tenant):
        try:
            import redis.asyncio as redis
            client=redis.from_url(REDIS_URL);pubsub=client.pubsub();await pubsub.subscribe(f'opspilot.live.{tenant}')
            async for message in pubsub.listen():
                if message['type']=='message': await self.publish_local(tenant,json.loads(message['data']))
        except asyncio.CancelledError: raise
        except Exception: return
hub=LiveHub()
def publish_shared_sync(tenant,event):
    try:
        import redis
        client=redis.from_url(REDIS_URL);client.publish(f'opspilot.live.{tenant}',json.dumps(event));client.close()
    except Exception: pass
