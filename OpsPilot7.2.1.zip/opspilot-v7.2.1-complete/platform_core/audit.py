"""Administrative audit support with secret-safe payloads."""
from uuid import uuid4
from platform_core.database import AuditEvent
def add_audit(session, *, tenant_id, actor, event_type, payload):
    session.add(AuditEvent(id=str(uuid4()),tenant_id=tenant_id,actor=actor,event_type=event_type,payload=payload))
