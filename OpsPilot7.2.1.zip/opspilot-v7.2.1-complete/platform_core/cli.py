import argparse

from platform_core.registry import registry

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["domains"])
    parser.parse_args()
    print("\n".join(registry().names()))
