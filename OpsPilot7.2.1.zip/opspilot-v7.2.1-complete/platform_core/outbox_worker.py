"""Bounded asynchronous outbox publisher with backoff and dead-letter state."""

import asyncio
from collections.abc import Callable
from datetime import UTC, datetime, timedelta

from sqlalchemy import select

from platform_core.database import OutboxEvent, get_session_factory

MAX_ATTEMPTS = 5
BATCH_SIZE = 100


def retry_delay(attempt: int) -> timedelta:
    """Return bounded exponential backoff for a failed publish attempt."""
    return timedelta(seconds=min(2 ** max(attempt, 1), 300))


async def publish_once(publisher: Callable[[dict], None] = print) -> int:
    now = datetime.now(UTC)
    async with get_session_factory()() as session:
        events = list(
            await session.scalars(
                select(OutboxEvent)
                .where(
                    OutboxEvent.published.is_(False),
                    OutboxEvent.status == "PENDING",
                    OutboxEvent.attempts < MAX_ATTEMPTS,
                    OutboxEvent.next_attempt_at <= now,
                )
                .order_by(OutboxEvent.created_at)
                .limit(BATCH_SIZE)
                .with_for_update(skip_locked=True)
            )
        )
        for event in events:
            try:
                publisher(
                    {"topic": event.topic, "tenant_id": event.tenant_id, "payload": event.payload}
                )
                event.published = True
                event.status = "PUBLISHED"
                event.last_error = None
            except Exception as exc:
                event.attempts += 1
                event.last_error = str(exc)[:500]
                if event.attempts >= MAX_ATTEMPTS:
                    event.status = "DEAD_LETTER"
                else:
                    event.next_attempt_at = now + retry_delay(event.attempts)
        await session.commit()
        return len(events)


async def main() -> None:
    while True:
        await publish_once()
        await asyncio.sleep(2)


if __name__ == "__main__":
    asyncio.run(main())
