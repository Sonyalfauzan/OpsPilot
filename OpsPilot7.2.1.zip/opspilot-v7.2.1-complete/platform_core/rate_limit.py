"""Bounded single-process rate limiter for local/reference deployments."""
from collections import defaultdict,deque
from threading import Lock
from time import monotonic
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from platform_core.config import settings
class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self,app): super().__init__(app); self.hits=defaultdict(deque); self.lock=Lock()
    async def dispatch(self,request,call_next):
        if request.url.path in {'/health','/v1/system/liveness','/v1/system/readiness'}: return await call_next(request)
        limit=settings().rate_limit_per_minute; key=request.headers.get('x-api-key') or (request.client.host if request.client else 'unknown'); now=monotonic()
        with self.lock:
            bucket=self.hits[key]
            while bucket and bucket[0] <= now-60: bucket.popleft()
            if len(bucket)>=limit: return JSONResponse({'detail':'rate limit exceeded'},429,headers={'Retry-After':'60'})
            bucket.append(now); remaining=limit-len(bucket)
        response=await call_next(request);response.headers['X-RateLimit-Limit']=str(limit);response.headers['X-RateLimit-Remaining']=str(remaining);return response
