"""Application services enforce tenancy, audit and transactional outbox."""

from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from platform_core.database import (
    AuditEvent,
    IdempotencyRecord,
    Incident,
    OutboxEvent,
    Tenant,
    UsedApproval,
)
from platform_core.live import hub
from platform_core.identity import Principal, require_tenant
from platform_core.schemas import IncidentCreate
from platform_core.security import verify_approval_token


class IncidentService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(
        self, request: IncidentCreate, principal: Principal, idempotency_key: str
    ) -> dict:
        require_tenant(principal, request.tenant_id)
        if not await self.session.get(Tenant, request.tenant_id):
            raise ValueError("unknown tenant")
        prior = await self.session.scalar(
            select(IdempotencyRecord).where(
                IdempotencyRecord.tenant_id == request.tenant_id,
                IdempotencyRecord.key == idempotency_key,
            )
        )
        if prior:
            return prior.response
        incident = Incident(id=str(uuid4()), **request.model_dump(mode="json"))
        response = {"id": incident.id, "status": "OPEN"}
        self.session.add(incident)
        await self.session.flush()
        self.session.add_all(
            [
                AuditEvent(
                    id=str(uuid4()),
                    tenant_id=request.tenant_id,
                    actor=principal.subject,
                    event_type="incident.created",
                    payload=response,
                ),
                OutboxEvent(
                    id=str(uuid4()),
                    tenant_id=request.tenant_id,
                    topic="incident.created",
                    payload=response,
                ),
                IdempotencyRecord(
                    id=str(uuid4()),
                    tenant_id=request.tenant_id,
                    key=idempotency_key,
                    response=response,
                ),
            ]
        )
        await self.session.commit()
        await hub.publish(request.tenant_id, {"type": "incident.created", **response})
        return response

    async def get(self, incident_id: str, tenant_id: str, principal: Principal) -> Incident | None:
        require_tenant(principal, tenant_id)
        return await self.session.scalar(
            select(Incident).where(Incident.id == incident_id, Incident.tenant_id == tenant_id)
        )


class ApprovalService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def consume_once(
        self, token: str, *, tenant_id: str, incident_id: str, action: str, action_arguments: dict
    ) -> dict:
        claims = verify_approval_token(
            token,
            tenant_id=tenant_id,
            incident_id=incident_id,
            action=action,
            action_arguments=action_arguments,
        )
        if await self.session.get(UsedApproval, claims["jti"]):
            raise ValueError("approval already consumed")
        self.session.add(UsedApproval(jti=claims["jti"], tenant_id=tenant_id))
        await self.session.commit()
        return claims
