"""Universal enforcement for domain-specific safety policy files."""

from pathlib import Path

import yaml

from platform_core.registry import registry


def load_domain_policy(domain: str) -> dict:
    plugin = registry().get(domain)
    path = Path(plugin.manifest_path).with_name("policies.yaml")
    if not path.exists():
        manifest = yaml.safe_load(Path(plugin.manifest_path).read_text(encoding="utf-8"))
        return {
            "human_approval_required": True,
            "prohibited_actions": manifest.get("prohibited_actions", []),
            "allowed_actions": [],
        }
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def authorize_domain_action(domain: str, action: str, approval_present: bool = False) -> None:
    policy = load_domain_policy(domain)
    if action in set(policy.get("prohibited_actions", [])):
        raise PermissionError(f"action prohibited for domain {domain}: {action}")
    allowed = set(policy.get("allowed_actions", []))
    if action not in allowed:
        raise PermissionError(f"action not allowlisted for domain {domain}: {action}")
    if policy.get("human_approval_required", True) and not approval_present:
        raise PermissionError("human approval required")
