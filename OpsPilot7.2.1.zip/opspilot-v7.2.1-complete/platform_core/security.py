"""Cryptographic approval tokens bound to exact action arguments."""

import hashlib
import json
from datetime import UTC, datetime, timedelta
from uuid import uuid4

import jwt

from platform_core.config import settings


def arguments_digest(arguments: dict) -> str:
    canonical = json.dumps(arguments, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(canonical).hexdigest()


def create_approval_token(
    *,
    tenant_id: str,
    incident_id: str,
    action: str,
    action_arguments: dict,
    approver_id: str,
    ttl_seconds: int,
) -> str:
    now = datetime.now(UTC)
    claims = {
        "sub": approver_id,
        "tenant_id": tenant_id,
        "incident_id": incident_id,
        "action": action,
        "arguments_digest": arguments_digest(action_arguments),
        "iat": now,
        "exp": now + timedelta(seconds=ttl_seconds),
        "jti": str(uuid4()),
    }
    return jwt.encode(claims, settings().approval_signing_key, algorithm="HS256")


def verify_approval_token(
    token: str, *, tenant_id: str, incident_id: str, action: str, action_arguments: dict
) -> dict:
    try:
        claims = jwt.decode(token, settings().approval_signing_key, algorithms=["HS256"])
    except jwt.PyJWTError as exc:
        raise ValueError("invalid or expired approval") from exc
    expected = (tenant_id, incident_id, action, arguments_digest(action_arguments))
    actual = (
        claims["tenant_id"],
        claims["incident_id"],
        claims["action"],
        claims["arguments_digest"],
    )
    if actual != expected:
        raise ValueError("approval scope or arguments mismatch")
    return claims
