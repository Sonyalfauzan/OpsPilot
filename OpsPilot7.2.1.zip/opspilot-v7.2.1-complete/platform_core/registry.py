"""Domain plugin discovery from installed entry points and local source metadata."""

import tomllib
from functools import lru_cache
from importlib import import_module
from importlib.metadata import entry_points
from pathlib import Path

from platform_core.domain import DomainPlugin


class DomainRegistry:
    def __init__(self, plugins: dict[str, DomainPlugin]):
        self._plugins = plugins
        if not plugins:
            raise RuntimeError("no domain plugins installed")

    @classmethod
    def discover(cls) -> "DomainRegistry":
        found = {entry.name: entry.load() for entry in entry_points(group="opspilot.domains")}
        project_file = Path(__file__).resolve().parents[1] / "pyproject.toml"
        if project_file.exists():
            metadata = tomllib.loads(project_file.read_text(encoding="utf-8"))
            local_entries = (
                metadata.get("project", {}).get("entry-points", {}).get("opspilot.domains", {})
            )
            for name, target in local_entries.items():
                module_name, attribute = target.split(":", 1)
                found[name] = getattr(import_module(module_name), attribute)
        return cls(found)

    def names(self) -> list[str]:
        return sorted(self._plugins)

    def get(self, name: str) -> DomainPlugin:
        try:
            return self._plugins[name]
        except KeyError as exc:
            raise ValueError(f"unknown domain: {name}; enabled={self.names()}") from exc


@lru_cache
def registry() -> DomainRegistry:
    return DomainRegistry.discover()
