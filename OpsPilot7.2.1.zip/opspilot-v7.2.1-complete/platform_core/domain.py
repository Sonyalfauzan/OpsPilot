"""Stable domain plugin protocol."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

import pandas as pd


@dataclass(frozen=True)
class TrainingSet:
    features: pd.DataFrame
    target: pd.Series
    task: str
    primary_metric: str


class DomainPlugin(Protocol):
    name: str
    version: str
    manifest_path: Path
    contract_path: Path

    def generate(self, rows: int, seed: int = 42) -> pd.DataFrame: ...

    def validate(self, frame: pd.DataFrame) -> dict[str, Any]: ...

    def transform_silver(self, frame: pd.DataFrame) -> pd.DataFrame: ...

    def build_marts(self, frame: pd.DataFrame) -> dict[str, pd.DataFrame]: ...

    def training_set(self, frame: pd.DataFrame) -> TrainingSet: ...

    def estimator(self): ...

    def evaluate(self, model, features: pd.DataFrame, target: pd.Series) -> dict[str, float]: ...

    def predict(
        self, model, features: dict[str, Any], metadata: dict[str, Any]
    ) -> dict[str, Any]: ...

    def query_metric(self, metric: str, marts: dict[str, pd.DataFrame]) -> float: ...
