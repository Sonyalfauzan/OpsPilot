from datetime import datetime

from airflow.sdk import dag, task


@dag(schedule="0 * * * *", start_date=datetime(2026, 1, 1), catchup=False, tags=["opspilot"])
def opspilot_pipeline():

    @task
    def enabled_domains():
        import sys

        sys.path.insert(0, "/opt/airflow/project")
        from platform_core.registry import registry

        return registry().names()

    @task
    def run_domain(domain):
        import sys

        sys.path.insert(0, "/opt/airflow/project")
        from data_platform.pipeline import run

        return run(domain)

    run_domain.expand(domain=enabled_domains())


opspilot_pipeline()
