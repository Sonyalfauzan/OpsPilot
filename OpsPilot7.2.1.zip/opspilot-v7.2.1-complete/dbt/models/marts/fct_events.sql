select event_id, tenant_id, domain, event_type, entity_id, event_timestamp from {{ ref('stg_events') }}
