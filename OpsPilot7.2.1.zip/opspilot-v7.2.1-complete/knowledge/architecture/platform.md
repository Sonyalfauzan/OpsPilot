# Platform architecture
OpsPilot separates deterministic policy and execution from probabilistic analysis. All mutations require audit and approval.