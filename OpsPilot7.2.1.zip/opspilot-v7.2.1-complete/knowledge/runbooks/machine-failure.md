# Machine failure runbook
Inspect temperature, vibration and pressure. Create a maintenance ticket; never control machinery directly.