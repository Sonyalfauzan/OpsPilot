# Logistics delay runbook
Compare traffic, weather and route distance. Dispatcher approval is required for hazardous-material rerouting.