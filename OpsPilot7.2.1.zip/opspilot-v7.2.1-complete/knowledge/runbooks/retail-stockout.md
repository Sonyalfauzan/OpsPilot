# Retail stockout runbook
Validate inventory freshness, promotion changes and demand forecast error. Pause challenger if feature freshness fails.