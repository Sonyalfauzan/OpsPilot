# OpsPilot v7.2 Platform Complete

OpsPilot is a synthetic-first reference platform for demonstrating data engineering, analytics, machine learning, MLOps, operational AI workflows, MCP tools, streaming, identity, administration and observability across 29 domain plugins. It is designed for portfolio review and controlled engineering validation. No partner telemetry, personal data, production credentials or claims of field deployment are bundled.

## Start

```bash
cp .env.example .env
make portfolio-mock-ai-up
make portfolio-demo
make administration-seed
make portfolio-verify
```

Open:

- Operations: `http://localhost:8000/dashboard`
- Administration: `http://localhost:8000/admin`
- API documentation: `http://localhost:8000/docs`
- Model API: `http://localhost:8001/docs`
- Grafana: `http://localhost:3000`
- Prometheus: `http://localhost:9090`
- Metabase: `http://localhost:3002`
- MLflow: `http://localhost:5000`
- Airflow: `http://localhost:8080`
- n8n: `http://localhost:5678`
- Keycloak, full profile: `http://localhost:8081`

## Administration

`/admin` provides tenant creation, user-profile metadata, approved role assignment, one-time API credential issuance, credential revocation API, tenant-aware feature flags, a service catalog and redacted configuration. Authentication passwords remain in the configured identity provider. OpsPilot does not create a parallel password store.

## Profiles

- `lite`: core APIs, PostgreSQL, MinIO, MLflow, Airflow, n8n, Metabase, Prometheus and Grafana.
- `full`: adds Keycloak, Redpanda, streaming consumer and OpenTelemetry Collector.
- `mock-ai`: deterministic local agents and local retrieval without paid APIs.
- `validation`: adds Toxiproxy and k6 soak tooling.

## Quality gates

```bash
pytest -q
ruff format --check .
ruff check .
python scripts/verify_definition_of_done.py
python validation/privacy/scan_repository.py
python validation/scan_incomplete.py
```

## Boundaries

Runtime components and test harnesses are implemented locally. Real Redis/PostgreSQL/Kafka/Kubernetes failover, a completed 24-hour soak run, identifiable-asset calibration, organizational privacy review and named-vendor MCP certification require authorized target environments. Infrastructure scaling, container restart, certificate rotation, backup orchestration and secret management remain responsibilities of the deployment platform rather than privileged browser endpoints.

See `docs/platform-administration.md`, `docs/completeness-matrix.yaml`, `docs/versioning-policy.md` and `validation/external-status.yaml`.


## v7.2 remediation

See `docs/v7.2-remediation.md` and `artifacts/release-audit-v7.2.json`.
