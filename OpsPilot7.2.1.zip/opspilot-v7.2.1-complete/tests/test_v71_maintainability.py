from pathlib import Path

import yaml

from platform_core.service_catalog import load_service_catalog, serialized_services


def test_release_versions_are_consistent():
    assert "7.1.0" in Path("pyproject.toml").read_text(encoding="utf-8")
    assert "7.1.0" in Path("docs/versioning-policy.md").read_text(encoding="utf-8")
    status = yaml.safe_load(Path("validation/external-status.yaml").read_text(encoding="utf-8"))
    assert status["release"] == "7.1.0"


def test_alembic_revisions_are_contiguous():
    paths = sorted(Path("alembic/versions").glob("*.py"))
    assert [path.name[:4] for path in paths] == ["0001", "0002"]
    migration = Path("alembic/versions/0002_administration.py").read_text(encoding="utf-8")
    assert 'revision = "0002_administration"' in migration
    assert 'down_revision = "0001"' in migration


def test_dashboard_sources_are_reviewable():
    dashboard = Path("apps/api/ui/dashboard.html")
    admin = Path("apps/api/ui/admin.html")
    assert len(dashboard.read_text(encoding="utf-8").splitlines()) >= 200
    assert len(admin.read_text(encoding="utf-8").splitlines()) >= 200
    assert dashboard.read_text(encoding="utf-8").startswith("<!doctype html>")
    assert admin.read_text(encoding="utf-8").startswith("<!doctype html>")


def test_service_catalog_is_yaml_backed_validated_and_unique():
    catalog = load_service_catalog()
    names = [service.name for service in catalog.services]
    assert len(names) == len(set(names))
    assert {"api", "postgres", "keycloak", "redpanda"} <= set(names)
    assert serialized_services()[0]["name"] == "api"
    system_source = Path("apps/api/system.py").read_text(encoding="utf-8")
    assert "SERVICES = [" not in system_source
    assert "serialized_services()" in system_source
