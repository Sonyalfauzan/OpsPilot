from pathlib import Path
import pytest
from platform_core.incidents import validate_transition
from data_platform.lineage import lineage_id
from ml.explainability import linear_contributions
from streaming.schema_registry import validate_event
def test_security_governance_changes():
    assert 'hmac.compare_digest' in Path('platform_core/identity.py').read_text()
    admin=Path('apps/api/admin.py').read_text();assert 'admin.credential.issued' in admin and 'offset:int=Query' in admin
    main=Path('apps/api/main.py').read_text();assert 'RateLimitMiddleware' in main and "script-src 'self';" in main and "script-src 'self' 'unsafe-inline'" not in main
def test_data_and_ml_changes():
    assert lineage_id(tenant_id='t',source_ids=['2','1'],transform='gold')==lineage_id(tenant_id='t',source_ids=['1','2'],transform='gold')
    assert linear_contributions(['x'],[2],[3])['prediction']==6
    event={'schema_version':'1','event_id':'e','tenant_id':'tenant-alpha','event_type':'x.y','occurred_at':'2026-01-01T00:00:00Z','payload':{}};assert validate_event(event)==event
def test_lifecycle_assets_and_supply_chain():
    assert validate_transition('OPEN','INVESTIGATING').value=='INVESTIGATING'
    with pytest.raises(ValueError):validate_transition('OPEN','CLOSED')
    for n in ['dashboard','admin']:
        assert f'/static/{n}.js' in Path(f'apps/api/ui/{n}.html').read_text()
    ci=Path('.github/workflows/ci.yml').read_text();assert 'windows-latest' in ci and '3.13' in ci and 'sbom.cdx.json' in ci
    assert Path('alembic/versions/0003_referential_integrity.py').exists()
