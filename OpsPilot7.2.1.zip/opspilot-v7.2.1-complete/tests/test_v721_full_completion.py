import json
from pathlib import Path
import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine
from streaming.producer import publish,serialized_events
from streaming.schema_registry import SchemaRegistryClient,validate_event
class FakeProducer:
    def __init__(self):self.messages=[]
    def produce(self,*a,**k):self.messages.append((a,k))
    def poll(self,*a):return None
    def flush(self,*a):return 0
class FakeRegistry:
    def __init__(self):self.called=0
    def register(self):self.called+=1;return 42
def test_registry_producer_and_consumer_are_integrated():
    event=json.loads(next(iter(serialized_events('logistics','tenant-alpha',1,42)))[1]);assert validate_event(event)==event
    producer=FakeProducer();registry=FakeRegistry();assert publish('logistics','tenant-alpha',1,42,producer,registry)==1
    assert registry.called==1 and dict(producer.messages[0][1]['headers'])['schema_id']=='42'
    consumer=Path('streaming/consumer.py').read_text(encoding="utf-8");assert 'validate_event(json.loads(payload))' in consumer and 'publish_shared_sync' in consumer
@pytest.mark.asyncio
async def test_sqlite_foreign_keys_are_enforced_on_connection():
    import platform_core.database
    engine=create_async_engine('sqlite+aiosqlite:///:memory:')
    async with engine.connect() as connection:
        assert (await connection.execute(text('PRAGMA foreign_keys'))).scalar_one()==1
    await engine.dispose()
def test_end_to_end_lineage_wiring():
    pipeline=Path('data_platform/pipeline.py').read_text(encoding="utf-8");assert 'bronze = attach_lineage' in pipeline and 'silver = attach_lineage' in pipeline and 'gold = attach_lineage' in pipeline
def test_authenticated_shared_live_updates_are_complete():
    identity=Path('platform_core/identity.py').read_text(encoding="utf-8");main=Path('apps/api/main.py').read_text(encoding="utf-8");services=Path('platform_core/services.py').read_text(encoding="utf-8");consumer=Path('streaming/consumer.py').read_text(encoding="utf-8");ui=Path('apps/api/ui/dashboard.js').read_text(encoding="utf-8")
    assert 'authenticate_websocket' in identity and 'authenticate_websocket(websocket, tenant_id)' in main
    assert 'incident.created' in services and 'dlq.changed' in consumer and 'hub.bridge' in main and 'api_key=' in ui
def test_prediction_response_always_includes_explanation():
    source=Path('apps/model_api/main.py').read_text(encoding="utf-8");assert '"explanation": explanation' in source and 'linear_contributions' in source and 'anomaly_explanation' in source
