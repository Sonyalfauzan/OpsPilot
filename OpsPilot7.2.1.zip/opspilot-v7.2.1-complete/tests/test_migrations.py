"""Migration round-trip tests execute the real Alembic environment."""

from alembic.config import Config
from sqlalchemy import create_engine, inspect

from alembic import command


def test_alembic_upgrade_downgrade_round_trip(tmp_path, monkeypatch):
    database = tmp_path / "migration.db"
    url = f"sqlite:///{database}"
    monkeypatch.setenv("SYNC_DATABASE_URL", url)
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{database}")
    from platform_core.config import settings

    settings.cache_clear()
    config = Config("alembic.ini")
    config.attributes["database_url"] = url
    command.upgrade(config, "head")
    engine = create_engine(url)
    tables = set(inspect(engine).get_table_names())
    assert {
        "incidents",
        "audit_events",
        "used_approvals",
        "idempotency_records",
        "outbox_events",
        "alembic_version",
        "tenants",
        "user_profiles",
        "api_credentials",
        "feature_flags",
    } <= tables
    revision = (
        engine.connect().exec_driver_sql("select version_num from alembic_version").scalar_one()
    )
    assert revision == "0002_administration"
    command.downgrade(config, "base")
    assert set(inspect(engine).get_table_names()) == {"alembic_version"}
    command.upgrade(config, "head")
    assert "incidents" in inspect(engine).get_table_names()
    settings.cache_clear()
