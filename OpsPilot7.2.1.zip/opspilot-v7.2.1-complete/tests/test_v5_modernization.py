from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from data_platform.simulation import SimulationConfig, simulate_series
from streaming.deduplication import SQLiteDeduplicationStore


def test_atomic_claim_allows_one_winner(tmp_path):
    store = SQLiteDeduplicationStore(tmp_path / "claims.db")
    with ThreadPoolExecutor(max_workers=10) as pool:
        results = list(pool.map(lambda _: store.claim("tenant", "event", 60), range(10)))
    assert sum(results) == 1


def test_claim_release_supports_crash_recovery(tmp_path):
    store = SQLiteDeduplicationStore(tmp_path / "claims.db")
    assert store.claim("t", "e", 60)
    store.release("t", "e")
    assert store.claim("t", "e", 60)


def test_simulation_modes_are_deterministic_and_nonlinear():
    config = SimulationConfig(mode="physics_informed", seed=17)
    one = simulate_series(500, config)
    two = simulate_series(500, config)
    assert all(np.array_equal(one[k], two[k]) for k in one)
    assert one["vibration"].max() > one["vibration"][:100].mean() * 2
    assert (
        max(
            abs(np.corrcoef(one["temperature"][lag:], one["load"][:-lag])[0, 1])
            for lag in range(1, 20)
        )
        > 0.2
    )


def test_mcp_servers_use_sdk_v2():
    assert "from mcp.server import FastMCP" in Path("mcp_servers/factory.py").read_text(
        encoding="utf-8"
    )
    for name in ["analytics_server.py", "data_server.py"]:
        assert "fastmcp" not in Path("mcp_servers", name).read_text(encoding="utf-8").lower()
