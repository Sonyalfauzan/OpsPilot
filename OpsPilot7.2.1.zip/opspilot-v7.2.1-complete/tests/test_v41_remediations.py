"""Regression coverage for all v4.1 review remediations."""

import json
from pathlib import Path

import pytest
import yaml
from pydantic import ValidationError

from analytics.dashboard_validation import validate_dashboard
from domain_packs.industrial_schema import IndustrialSpecification
from platform_core.domain_policy import authorize_domain_action, load_domain_policy
from platform_core.registry import registry
from rag.service import LocalRAG, jaccard
from streaming.consumer import EventProcessor
from streaming.producer import publish, serialized_events


def test_retail_seed_is_fully_reproducible():
    plugin = registry().get("retail")
    first = plugin.generate(100, 42)
    second = plugin.generate(100, 42)
    assert first.equals(second)
    assert not first.equals(plugin.generate(100, 43))


def test_industrial_schema_rejects_unknown_fields():
    plugin = registry().get("mining")
    payload = yaml.safe_load((plugin.directory / "industrial.yaml").read_text(encoding="utf-8"))
    IndustrialSpecification.model_validate(payload)
    payload["typo_field"] = True
    with pytest.raises(ValidationError):
        IndustrialSpecification.model_validate(payload)


def test_all_prohibited_actions_are_enforced():
    checked = 0
    for domain in registry().names():
        policy = load_domain_policy(domain)
        for action in policy.get("prohibited_actions", []):
            with pytest.raises(PermissionError):
                authorize_domain_action(domain, action, approval_present=True)
            checked += 1
    assert checked >= 45


def test_allowed_industrial_action_requires_approval():
    action = "create_simulated_ticket"
    with pytest.raises(PermissionError, match="approval"):
        authorize_domain_action("mining", action, approval_present=False)
    authorize_domain_action("mining", action, approval_present=True)


def test_rag_suppresses_duplicate_chunks(tmp_path):
    repeated = "mining vibration inspection maintenance " * 100
    (tmp_path / "a.md").write_text(repeated, encoding="utf-8")
    (tmp_path / "b.md").write_text(repeated, encoding="utf-8")
    rag = LocalRAG(chunk_size=300, overlap=100)
    rag.index(tmp_path)
    hits = rag.search("mining vibration inspection", k=10)
    hashes = {" ".join(hit["text"].split()) for hit in hits}
    assert len(hashes) == len(hits)
    assert all(
        jaccard(left["text"], right["text"]) <= 0.92
        for index, left in enumerate(hits)
        for right in hits[index + 1 :]
    )
    assert all(sum(hit["source"] == other["source"] for other in hits) <= 2 for hit in hits)


class FakeProducer:
    def __init__(self):
        self.messages = []

    def produce(self, topic, **kwargs):
        self.messages.append((topic, kwargs))

    def poll(self, timeout):
        return 0

    def flush(self, timeout):
        return 0


def test_streaming_producer_is_idempotent_and_tenant_scoped():
    producer = FakeProducer()
    assert publish("retail", "tenant-alpha", 10, 42, producer) == 10
    assert len({message[1]["key"] for message in producer.messages}) == 10
    payload = json.loads(producer.messages[0][1]["value"])
    assert payload["tenant_id"] == "tenant-alpha"
    assert payload["domain"] == "retail"
    assert dict(producer.messages[0][1]["headers"])["schema_version"] == "1"


def test_stream_processor_accepts_deduplicates_and_dead_letters(tmp_path):
    processor = EventProcessor(tmp_path)
    _, payload = next(iter(serialized_events("retail", "tenant-alpha", 1, 42)))
    assert processor.process(payload) == "accepted"
    assert processor.process(payload) == "duplicate"
    assert processor.process(b"{}") == "dead_letter"
    assert (tmp_path / "dead-letter/events.jsonl").exists()
    assert (tmp_path / "tenant-alpha/bronze/retail/stream-events.parquet").exists() or (
        tmp_path / "tenant-alpha/bronze/retail/stream-events.jsonl"
    ).exists()


def test_all_dashboard_contracts_validate():
    dashboards = list(Path("analytics/dashboards").glob("*.json")) + list(
        Path("domain_packs").glob("*/dashboards/*.json")
    )
    assert len(dashboards) >= 29
    for dashboard in dashboards:
        validate_dashboard(dashboard)


def test_compose_contracts_are_consistent():
    base = Path("docker-compose.yml").read_text(encoding="utf-8")
    development = Path("compose.dev.yml").read_text(encoding="utf-8")
    mock = yaml.safe_load(Path("compose.mock-ai.yml").read_text(encoding="utf-8"))
    assert ".:/opt/airflow/project" not in base
    assert ".:/opt/airflow/project" in development
    assert mock["services"]["api"]["environment"]["EXTERNAL_LLM_ENABLED"] == "false"


def test_all_domains_are_fully_reproducible():
    for domain in registry().names():
        plugin = registry().get(domain)
        assert plugin.generate(20, 17).equals(plugin.generate(20, 17)), domain
