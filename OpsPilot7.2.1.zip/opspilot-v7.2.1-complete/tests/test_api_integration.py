import os

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")
os.environ.setdefault("SYNC_DATABASE_URL", "sqlite:///:memory:")

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from apps.api.main import app
from platform_core.database import Base, get_engine
from platform_core.identity import Principal, authenticate


@pytest_asyncio.fixture(autouse=True)
async def database_schema():
    engine = get_engine()
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.drop_all)


@pytest.fixture
def client():
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://test")


@pytest.mark.asyncio
async def test_incident_idempotency_and_retrieval(client):
    payload = {
        "tenant_id": "tenant-alpha",
        "domain": "logistics",
        "incident_type": "model_drift",
        "title": "Synthetic drift",
        "severity": "SEV-2",
        "evidence": [{"kind": "drift", "metric": "drift_share", "value": 0.8}],
    }
    headers = {
        "X-API-Key": "local-development-key-change-me",
        "Idempotency-Key": "incident-key-001",
    }
    first = await client.post("/v1/incidents", json=payload, headers=headers)
    second = await client.post("/v1/incidents", json=payload, headers=headers)
    assert first.status_code == 201
    assert second.json() == first.json()
    fetched = await client.get(
        f"/v1/incidents/{first.json()['id']}?tenant_id=tenant-alpha",
        headers={"X-API-Key": "local-development-key-change-me"},
    )
    assert fetched.status_code == 200
    assert fetched.json()["tenant_id"] == "tenant-alpha"


@pytest.mark.asyncio
async def test_missing_api_key_is_rejected(client):
    assert (await client.get("/v1/incidents/none?tenant_id=tenant-alpha")).status_code == 401


@pytest.mark.asyncio
async def test_cross_tenant_access_is_rejected(client):
    async def tenant_user():
        return Principal("user", "tenant-alpha", ("viewer",))

    app.dependency_overrides[authenticate] = tenant_user
    try:
        response = await client.get("/v1/incidents/none?tenant_id=tenant-beta")
        assert response.status_code == 403
    finally:
        app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_approval_exact_binding_and_replay_rejection(client):
    headers = {"X-API-Key": "local-development-key-change-me"}
    approval = {
        "tenant_id": "tenant-alpha",
        "incident_id": "incident-1",
        "action": "rollback_model",
        "action_arguments": {"domain": "logistics", "to_version": "1"},
        "approver_id": "portfolio-admin",
        "ttl_seconds": 300,
    }
    issued = await client.post("/v1/approvals", json=approval, headers=headers)
    assert issued.status_code == 200
    execute = {**approval, "approval_token": issued.json()["token"]}
    execute.pop("approver_id")
    execute.pop("ttl_seconds")
    first = await client.post("/v1/actions/execute", json=execute, headers=headers)
    replay = await client.post("/v1/actions/execute", json=execute, headers=headers)
    assert first.status_code == 200
    assert replay.status_code == 409
    tampered = {**execute, "action_arguments": {"domain": "retail", "to_version": "1"}}
    assert (
        await client.post("/v1/actions/execute", json=tampered, headers=headers)
    ).status_code == 409
