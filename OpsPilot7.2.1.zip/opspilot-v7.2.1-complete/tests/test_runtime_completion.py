from pathlib import Path

from streaming.rebalance import RebalanceCoordinator
from validation.privacy.scan_repository import main as privacy_scan


def test_rebalance_coordinator_stops_new_work_and_drains():
    coordinator = RebalanceCoordinator(0.2)
    assert coordinator.enter()
    coordinator.leave()
    coordinator.on_revoke(None, [1, 2])
    assert coordinator.enter() is False
    coordinator.on_assign(None, [1])
    assert coordinator.enter()
    coordinator.leave()


def test_repository_privacy_scanner():
    privacy_scan()


def test_validation_assets_are_executable_not_placeholders():
    assert Path("compose.validation.yml").exists()
    assert Path("validation/calibration/generate_report.py").exists()
    assert Path("validation/interop/mcp_smoke.py").exists()
    source = Path("streaming/deduplication.py").read_text(encoding="utf-8")
    assert "RedisClusterDeduplicationStore" in source
    assert "PostgresDeduplicationStore" in source
