from pathlib import Path

import yaml

from validation.scan_incomplete import main as scan_incomplete


def test_no_incomplete_implementation_markers():
    scan_incomplete()


def test_external_status_is_explicit_and_not_overclaimed():
    status = yaml.safe_load(Path("validation/external-status.yaml").read_text(encoding="utf-8"))
    assert status["release"] == "6.1.0"
    assert all(item["status"] in status["status_model"] for item in status["validations"].values())
    assert status["validations"]["named_vendor_mcp"]["status"] == "external_validation_required"


def test_mcp_matrix_contains_no_fake_vendor_placeholder():
    matrix = yaml.safe_load(Path("validation/interop/mcp-matrix.yaml").read_text(encoding="utf-8"))
    assert matrix["external_clients"] == []
    assert matrix["external_vendor_validation"]["status"] == "not_executed"


def test_versioning_policy_distinguishes_release_and_contract_versions():
    text = Path("docs/versioning-policy.md").read_text(encoding="utf-8")
    assert (
        "Platform release" in text
        and "Industrial domain specification" in text
        and "Streaming event schema" in text
    )


def test_generated_calibration_report_is_packaged():
    report = Path("artifacts/synthetic-calibration-report.json")
    assert report.exists()
    assert "not evidence of field accuracy" in report.read_text(encoding="utf-8")
