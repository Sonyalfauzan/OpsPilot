from pathlib import Path

from platform_core.registry import registry

CORE = ["platform_core", "apps", "agents", "data_platform", "ml", "mcp_servers"]


def test_core_has_no_concrete_domain_imports():
    forbidden = [f"domain_packs.{name}.plugin" for name in registry().names()]
    violations = []
    for base in CORE:
        for path in Path(base).rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if any(name in text for name in forbidden):
                violations.append(str(path))
    assert not violations, violations


def test_core_has_no_domain_name_branches():
    violations = []
    for base in CORE:
        for path in Path(base).rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if any(f'== "{name}"' in text or f"== '{name}'" in text for name in registry().names()):
                violations.append(str(path))
    assert not violations, violations
