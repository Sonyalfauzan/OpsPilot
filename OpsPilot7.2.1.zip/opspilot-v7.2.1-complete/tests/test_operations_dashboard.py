from pathlib import Path

import pytest


@pytest.mark.asyncio
async def test_dashboard_and_alias(client):
    dashboard = await client.get("/dashboard")
    assert dashboard.status_code == 200
    assert "OpsPilot Operations" in dashboard.text
    assert "Trigger synthetic incident" in dashboard.text
    alias = await client.get("/queue", follow_redirects=False)
    assert alias.status_code == 307 and alias.headers["location"] == "/dashboard"


@pytest.mark.asyncio
async def test_operations_are_authenticated_and_tenant_scoped(client):
    assert (await client.get("/v1/operations/summary?tenant_id=tenant-alpha")).status_code == 401
    headers = {"X-API-Key": "local-development-key-change-me"}
    summary = await client.get("/v1/operations/summary?tenant_id=tenant-alpha", headers=headers)
    assert summary.status_code == 200
    assert summary.json()["tenant_id"] == "tenant-alpha"


@pytest.mark.asyncio
async def test_dashboard_creates_only_marked_synthetic_incident(client):
    headers = {"X-API-Key": "local-development-key-change-me"}
    created = await client.post(
        "/v1/operations/synthetic-incidents",
        headers=headers,
        json={"tenant_id": "tenant-alpha", "domain": "mining", "severity": "SEV-3"},
    )
    assert created.status_code == 201 and created.json()["synthetic"] is True
    incidents = await client.get("/v1/operations/incidents?tenant_id=tenant-alpha", headers=headers)
    assert any(item["domain"] == "mining" for item in incidents.json())


def test_all_python_path_text_io_is_explicit_utf8():
    import ast

    offenders = []
    for path in Path(".").rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                continue
            if node.func.attr not in {"read_text", "write_text"}:
                continue
            if not any(keyword.arg == "encoding" for keyword in node.keywords):
                offenders.append(f"{path}:{node.lineno}:{node.func.attr}")
    assert offenders == []
