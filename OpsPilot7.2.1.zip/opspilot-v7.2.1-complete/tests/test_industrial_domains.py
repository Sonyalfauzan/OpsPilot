"""Behavioral tests for configuration-driven industrial plugins."""

import yaml

from platform_core.registry import registry

INDUSTRIAL = {
    "mining",
    "oil_and_gas",
    "water_utilities",
    "construction",
    "automotive",
    "aerospace",
    "chemicals",
    "pharmaceutical_manufacturing",
    "food_and_beverage",
    "forestry_and_pulp",
    "maritime_and_ports",
    "rail_transport",
    "waste_and_recycling",
    "semiconductors",
    "data_centers",
    "renewable_energy",
}


def test_industrial_specs_are_distinct_and_complete():
    targets = set()
    feature_sets = set()
    for name in INDUSTRIAL:
        plugin = registry().get(name)
        spec = yaml.safe_load((plugin.directory / "industrial.yaml").read_text(encoding="utf-8"))
        policy = yaml.safe_load((plugin.directory / "policies.yaml").read_text(encoding="utf-8"))
        assert len(spec["features"]) >= 4
        assert len(spec["metrics"]) >= 3
        assert spec["signal"]["weights"]
        assert policy["human_approval_required"] is True
        assert policy["prohibited_actions"]
        assert (plugin.directory / "model_card.md").stat().st_size > 100
        assert (plugin.directory / "runbooks/incident.md").stat().st_size > 200
        targets.add(spec["target"])
        feature_sets.add(tuple(sorted(feature["name"] for feature in spec["features"])))
    assert len(targets) >= 12
    assert len(feature_sets) == len(INDUSTRIAL)


def test_industrial_plugins_execute_full_behavior():
    for name in INDUSTRIAL:
        plugin = registry().get(name)
        frame = plugin.generate(240, 42)
        assert plugin.validate(frame)["passed"]
        silver = plugin.transform_silver(frame)
        marts = plugin.build_marts(silver)
        dataset = plugin.training_set(silver)
        model = plugin.estimator()
        model.fit(dataset.features, dataset.target)
        metrics = plugin.evaluate(model, dataset.features, dataset.target)
        assert dataset.primary_metric in metrics
        prediction = plugin.predict(
            model, dataset.features.iloc[0].to_dict(), {"features": list(dataset.features.columns)}
        )
        assert prediction["unit"] != ""
        manifest = yaml.safe_load(plugin.manifest_path.read_text(encoding="utf-8"))
        assert isinstance(plugin.query_metric(manifest["metrics"][0], marts), float)
