import os

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")
os.environ.setdefault("SYNC_DATABASE_URL", "sqlite:///:memory:")
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from apps.api.main import app
from platform_core.database import Base, Tenant, get_engine, get_session_factory


@pytest_asyncio.fixture(autouse=True)
async def database_schema():
    engine = get_engine()
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    async with get_session_factory()() as session:
        session.add_all([Tenant(id="tenant-alpha", name="Synthetic Alpha"), Tenant(id="tenant-beta", name="Synthetic Beta")])
        await session.commit()
    yield
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.drop_all)


@pytest.fixture
def client():
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://test")
