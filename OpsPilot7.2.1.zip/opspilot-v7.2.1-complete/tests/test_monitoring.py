import json

from ml.evidently_monitor import run_monitor
from platform_core.registry import registry


def test_monitoring_generates_runtime_artifact(tmp_path):
    plugin = registry().get("retail")
    reference = plugin.generate(100, 42)
    current = reference.copy()
    current["price"] *= 3
    result = run_monitor(reference, current, str(tmp_path))
    assert (tmp_path / "report.json").exists()
    assert result["engine"] in {"evidently", "deterministic-fallback"}
    assert (
        json.loads((tmp_path / "report.json").read_text(encoding="utf-8"))["engine"]
        == result["engine"]
    )
