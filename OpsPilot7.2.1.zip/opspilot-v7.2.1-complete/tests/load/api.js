import http from 'k6/http';
import { check, sleep } from 'k6';
import { randomUUID } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

export const options = {
  vus: 5,
  duration: '30s',
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500'],
  },
};

const baseUrl = __ENV.BASE_URL || 'http://localhost:8000';
const apiKey = __ENV.API_KEY || 'local-development-key-change-me';
const authHeaders = { 'X-API-Key': apiKey, 'Content-Type': 'application/json' };

export default function () {
  const health = http.get(`${baseUrl}/health`);
  check(health, { 'health is 200': (response) => response.status === 200 });

  const idempotencyKey = `load-${__VU}-${__ITER}-${randomUUID()}`;
  const incidentBody = JSON.stringify({
    tenant_id: 'tenant-alpha',
    domain: 'telecommunications',
    incident_type: 'service_degradation',
    title: 'Synthetic load-test incident',
    severity: 'SEV-3',
    evidence: [{ kind: 'metric', metric: 'latency_ms', value: 250 }],
  });
  const created = http.post(`${baseUrl}/v1/incidents`, incidentBody, {
    headers: { ...authHeaders, 'Idempotency-Key': idempotencyKey },
  });
  check(created, { 'incident created': (response) => response.status === 201 });
  if (created.status === 201) {
    const incidentId = created.json('id');
    const fetched = http.get(`${baseUrl}/v1/incidents/${incidentId}?tenant_id=tenant-alpha`, {
      headers: authHeaders,
    });
    check(fetched, { 'incident retrieved': (response) => response.status === 200 });
  }
  sleep(1);
}
