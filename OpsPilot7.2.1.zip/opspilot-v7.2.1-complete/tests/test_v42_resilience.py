import json
from pathlib import Path

from streaming.consumer import EventProcessor, domain_contract_index
from streaming.producer import serialized_events


def test_contract_index_is_cached():
    domain_contract_index.cache_clear()
    assert domain_contract_index() is domain_contract_index()


def test_domain_is_required_by_default(tmp_path):
    processor = EventProcessor(tmp_path)
    _, payload = next(iter(serialized_events("retail", "tenant-alpha", 1, 42)))
    event = json.loads(payload)
    event.pop("domain")
    assert processor.process(json.dumps(event).encode()) == "dead_letter"


def test_deduplication_survives_processor_restart(tmp_path):
    _, payload = next(iter(serialized_events("retail", "tenant-alpha", 1, 42)))
    assert EventProcessor(tmp_path).process(payload) == "accepted"
    assert EventProcessor(tmp_path).process(payload) == "duplicate"


def test_spark_job_has_graceful_failure_lifecycle():
    source = Path("streaming/spark_job.py").read_text(encoding="utf-8")
    assert "logger.exception" in source
    assert "query.stop()" in source
    assert "spark.stop()" in source
    assert "raise" in source


def test_industrial_engine_has_single_schema_validation_source():
    source = Path("domain_packs/industrial_engine.py").read_text(encoding="utf-8")
    assert "_validate_specification" not in source
