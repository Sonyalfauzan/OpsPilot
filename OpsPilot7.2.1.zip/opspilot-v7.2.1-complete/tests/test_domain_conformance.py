import pandas as pd

from platform_core.registry import registry

EXPECTED_DOMAINS = {
    "retail",
    "manufacturing",
    "logistics",
    "finance",
    "energy",
    "agriculture",
    "telecommunications",
    "hospitality",
    "education",
    "insurance",
    "real_estate",
    "healthcare_operations",
    "public_services",
    "mining",
    "oil_and_gas",
    "water_utilities",
    "construction",
    "automotive",
    "aerospace",
    "chemicals",
    "pharmaceutical_manufacturing",
    "food_and_beverage",
    "forestry_and_pulp",
    "maritime_and_ports",
    "rail_transport",
    "waste_and_recycling",
    "semiconductors",
    "data_centers",
    "renewable_energy",
}


def test_all_industry_domains_discovered():
    assert set(registry().names()) == EXPECTED_DOMAINS


def test_all_plugins_conform_end_to_end():
    for name in registry().names():
        plugin = registry().get(name)
        frame = plugin.generate(300, 42)
        assert plugin.validate(frame)["passed"]
        silver = plugin.transform_silver(frame)
        marts = plugin.build_marts(silver)
        assert marts and all(
            isinstance(value, pd.DataFrame) and not value.empty for value in marts.values()
        )
        dataset = plugin.training_set(silver)
        assert dataset.target.name not in dataset.features.columns
        model = plugin.estimator()
        model.fit(dataset.features, dataset.target)
        scores = plugin.evaluate(model, dataset.features, dataset.target)
        assert dataset.primary_metric in scores
        prediction = plugin.predict(
            model, dataset.features.iloc[0].to_dict(), {"features": list(dataset.features.columns)}
        )
        assert isinstance(prediction["value"], float)
        first_metric = __import__("yaml").safe_load(
            plugin.manifest_path.read_text(encoding="utf-8")
        )["metrics"][0]
        assert isinstance(plugin.query_metric(first_metric, marts), float)
