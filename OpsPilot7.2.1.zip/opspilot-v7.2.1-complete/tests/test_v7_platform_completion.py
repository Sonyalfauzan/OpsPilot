from pathlib import Path

import pytest

from platform_core.identity import Principal, authenticate

HEADERS = {"X-API-Key": "local-development-key-change-me"}


@pytest.mark.asyncio
async def test_admin_page_and_security_headers(client):
    response = await client.get("/admin")
    assert response.status_code == 200 and "Platform administration" in response.text
    for header in [
        "x-content-type-options",
        "x-frame-options",
        "content-security-policy",
        "referrer-policy",
    ]:
        assert header in response.headers


@pytest.mark.asyncio
async def test_tenant_user_flag_and_safe_configuration(client):
    tenant = await client.post(
        "/v1/admin/tenants", headers=HEADERS, json={"id": "tenant-gamma", "name": "Synthetic Gamma"}
    )
    assert tenant.status_code == 201
    user = await client.post(
        "/v1/admin/users",
        headers=HEADERS,
        json={
            "username": "gamma.viewer",
            "display_name": "Gamma Viewer",
            "email": "gamma@example.invalid",
            "tenant_id": "tenant-gamma",
            "roles": ["viewer"],
        },
    )
    assert user.status_code == 201
    flag = await client.put(
        "/v1/admin/feature-flags/demo.enabled",
        headers=HEADERS,
        json={
            "key": "demo.enabled",
            "enabled": True,
            "tenant_id": "tenant-gamma",
            "description": "Synthetic demo control",
        },
    )
    assert flag.status_code == 200
    config = await client.get("/v1/system/configuration", headers=HEADERS)
    assert config.status_code == 200 and config.json()["secrets_redacted"] is True
    assert "local-development-key-change-me" not in config.text
    assert "local-approval-signing-key" not in config.text


@pytest.mark.asyncio
async def test_non_admin_cannot_manage_users(client):
    async def viewer():
        return Principal("viewer", "tenant-alpha", ("viewer",))

    app = __import__("apps.api.main", fromlist=["app"]).app
    app.dependency_overrides[authenticate] = viewer
    try:
        assert (await client.get("/v1/admin/users")).status_code == 403
    finally:
        app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_api_credential_is_returned_once_and_hash_stored(client):
    await client.post(
        "/v1/admin/tenants", headers=HEADERS, json={"id": "tenant-delta", "name": "Synthetic Delta"}
    )
    created = await client.post(
        "/v1/admin/credentials",
        headers=HEADERS,
        json={"name": "automation", "tenant_id": "tenant-delta", "scopes": ["read"], "ttl_days": 7},
    )
    assert created.status_code == 201 and created.json()["api_key"].startswith("op_")


@pytest.mark.asyncio
async def test_health_surfaces(client):
    assert (await client.get("/v1/system/liveness")).json() == {"status": "alive"}
    assert (await client.get("/v1/system/readiness")).json()["database"] == "reachable"


def test_admin_assets_migration_and_service_healthchecks_exist():
    assert Path("apps/api/ui/admin.html").exists()
    assert Path("alembic/versions/0002_administration.py").exists()
    compose = Path("compose.portfolio.yml").read_text(encoding="utf-8")
    assert "service_healthy" in compose and "healthcheck" in compose
