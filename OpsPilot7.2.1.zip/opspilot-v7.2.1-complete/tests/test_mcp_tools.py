from pathlib import Path

import pytest

from data_platform.storage import write_frame
from mcp_servers.tools import analytics_metric, pipeline_status, quality_report
from platform_core.registry import registry


def test_pipeline_status_validates_domain(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert pipeline_status("tenant-alpha", "retail")["ready"] is False
    with pytest.raises(ValueError):
        pipeline_status("tenant-alpha", "unknown")


def test_metric_allowlist_and_tenant_path(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    plugin = registry().get("logistics")
    frame = plugin.generate(100, 42)
    marts = plugin.build_marts(frame)
    root = Path("data/tenant-alpha/gold/logistics")
    for name, mart in marts.items():
        write_frame(mart, root / f"{name}.parquet")
    result = analytics_metric("tenant-alpha", "logistics", "on_time_rate")
    assert 0 <= result["value"] <= 1
    with pytest.raises(ValueError):
        analytics_metric("tenant-alpha", "logistics", "arbitrary_sql")
    with pytest.raises(FileNotFoundError):
        analytics_metric("tenant-beta", "logistics", "on_time_rate")


def test_missing_quality_report_is_explicit(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert quality_report("tenant-alpha", "retail") == {"status": "not_available"}
