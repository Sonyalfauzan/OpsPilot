import json
from pathlib import Path

import pytest

from agents.workflow import IncidentWorkflow, State
from data_platform.scenarios import inject
from ml.deployment import DeploymentState, evaluate_guardrails, start_canary
from platform_core.policy import authorize
from rag.service import LocalRAG


def test_rag_citations():
    r = LocalRAG()
    assert r.index("knowledge") >= 4
    ans = r.answer("logistics delay traffic")
    assert ans["citations"]


def test_canary_rollback():
    s = DeploymentState("1")
    start_canary(s, "2", 10)
    assert not evaluate_guardrails(s, 300, 0.05, -0.1)["passed"]
    assert s.status == "ROLLED_BACK"


def test_scenarios_and_leakage_boundary():
    from platform_core.registry import registry

    p = registry().get("logistics")
    f = p.generate(100, 42)
    assert "delayed" not in list(p.training_set(f).features.columns)
    assert len(inject(f, "duplicates")) > len(f)


def test_deny_by_default():
    with pytest.raises(PermissionError):
        authorize("delete_database", ["platform_admin"], True)


def test_agent_state_machine():
    f = IncidentWorkflow("retail", [{"kind": "quality", "metric": "missing_rate", "value": 0.4}])
    f.step()
    f.step()
    assert f.state == State.APPROVAL_PENDING


def test_n8n_workflows_parse():
    files = list(Path("automation/n8n").glob("*.json"))
    assert len(files) >= 13
    for p in files:
        assert json.loads(p.read_text(encoding="utf-8"))["nodes"]


def test_tenant_scoping_contract():
    from fastapi import HTTPException

    from platform_core.identity import Principal, require_tenant

    require_tenant(Principal("u", "tenant-alpha", ("viewer",)), "tenant-alpha")
    with pytest.raises(HTTPException):
        require_tenant(Principal("u", "tenant-alpha", ("viewer",)), "tenant-beta")
