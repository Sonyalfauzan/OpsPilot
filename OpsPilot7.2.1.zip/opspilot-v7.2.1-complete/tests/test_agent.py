from agents.incident import investigate


def test_agent_separates_evidence_and_hypothesis():
    r = investigate(
        "retail", "model_degradation", [{"kind": "drift", "metric": "drift_share", "value": 0.8}]
    )
    assert r["status"] == "ANALYZED"
    assert r["approval_required"]
    assert "does not prove" in r["hypotheses"][0]["contradicting_evidence"][0]


def test_insufficient_evidence():
    assert investigate("retail", "unknown", [])["status"] == "INSUFFICIENT_EVIDENCE"
