from pathlib import Path

import yaml

from validation.run_validation import main


def test_public_spec_synthetic_only_provenance():
    p = yaml.safe_load(Path("validation/provenance.yaml").read_text(encoding="utf-8"))
    assert p["policy"] == "public-specifications-and-synthetic-output-only"
    assert not any(
        [
            p["contains_original_operational_records"],
            p["contains_pii"],
            p["contains_credentials"],
            p["contains_partner_data"],
        ]
    )


def test_failure_matrix_and_acceptance_are_complete():
    scenarios = yaml.safe_load(
        Path("validation/scenarios/failure-matrix.yaml").read_text(encoding="utf-8")
    )["scenarios"]
    assert {
        "redis_primary_failover",
        "postgres_primary_failover",
        "pod_eviction",
        "network_partition",
        "broker_rebalance",
    } <= scenarios.keys()
    criteria = yaml.safe_load(
        Path("validation/profiles/acceptance.yaml").read_text(encoding="utf-8")
    )
    assert criteria["max_duplicate_completions"] == 0 and criteria["rpo_completed_events"] == 0


def test_validation_runner():
    main()
