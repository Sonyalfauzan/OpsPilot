"""Regression tests ensure FastMCP adapters never use legacy non-tenant paths."""

from pathlib import Path

from mcp_servers import analytics_server, data_server


def test_transport_adapters_delegate_to_tenant_scoped_tools():
    analytics = Path(analytics_server.__file__).read_text(encoding="utf-8")
    data = Path(data_server.__file__).read_text(encoding="utf-8")
    assert 'Path("data/gold")' not in analytics
    assert "analytics_server()" in analytics
    assert "analytics_metric" in Path("mcp_servers/factory.py").read_text(encoding="utf-8")
    assert 'Path("data/gold")' not in data
    assert "data_server()" in data
    assert "pipeline_status" in Path("mcp_servers/factory.py").read_text(encoding="utf-8")
    assert "quality_report" in Path("mcp_servers/factory.py").read_text(encoding="utf-8")
