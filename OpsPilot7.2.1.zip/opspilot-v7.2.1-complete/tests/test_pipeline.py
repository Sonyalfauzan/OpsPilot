from platform_core.registry import registry


def test_contracts_accept_generated_data():
    for name in registry().names():
        p = registry().get(name)
        assert p.validate(p.generate(30, 42))["passed"]


def test_duplicate_rejected():
    p = registry().get("logistics")
    df = p.generate(20, 42)
    df.loc[1, "event_id"] = df.loc[0, "event_id"]
    assert not p.validate(df)["passed"]
