"""OIDC claim, issuer, audience and signature validation tests."""

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import HTTPException

from platform_core.config import settings
from platform_core.identity import TokenValidator


def configured_validator(monkeypatch):
    monkeypatch.setenv("AUTH_MODE", "oidc")
    monkeypatch.setenv("OIDC_ISSUER", "https://identity.local/realms/opspilot")
    monkeypatch.setenv("OIDC_AUDIENCE", "opspilot-api")
    monkeypatch.setenv("OIDC_JWKS_URL", "https://identity.local/jwks")
    settings.cache_clear()
    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    validator = TokenValidator()
    validator.config = SimpleNamespace(
        oidc_issuer="https://identity.local/realms/opspilot",
        oidc_audience="opspilot-api",
    )
    validator.jwks = SimpleNamespace(
        get_signing_key_from_jwt=lambda token: SimpleNamespace(key=private.public_key())
    )
    return validator, private


def token(private, **overrides):
    now = datetime.now(UTC)
    claims = {
        "sub": "portfolio-user",
        "tenant_id": "tenant-alpha",
        "realm_access": {"roles": ["viewer"]},
        "iss": "https://identity.local/realms/opspilot",
        "aud": "opspilot-api",
        "iat": now,
        "exp": now + timedelta(minutes=5),
        **overrides,
    }
    return jwt.encode(claims, private, algorithm="RS256")


def test_oidc_validates_signature_issuer_audience_and_claims(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    principal = validator.validate(token(private))
    assert principal.subject == "portfolio-user"
    assert principal.tenant_id == "tenant-alpha"
    assert principal.roles == ("viewer",)
    settings.cache_clear()


def test_oidc_rejects_wrong_audience(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    with pytest.raises(HTTPException) as error:
        validator.validate(token(private, aud="other-api"))
    assert error.value.status_code == 401
    settings.cache_clear()


def test_oidc_rejects_expired_token(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    with pytest.raises(HTTPException) as error:
        validator.validate(token(private, exp=datetime.now(UTC) - timedelta(seconds=1)))
    assert error.value.status_code == 401


def test_oidc_rejects_tampered_signature(monkeypatch):
    validator, _ = configured_validator(monkeypatch)
    attacker = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    with pytest.raises(HTTPException) as error:
        validator.validate(token(attacker))
    assert error.value.status_code == 401


def test_oidc_rejects_missing_tenant(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    value = token(private)
    claims = jwt.decode(value, options={"verify_signature": False})
    claims.pop("tenant_id")
    value = jwt.encode(claims, private, algorithm="RS256")
    with pytest.raises(HTTPException) as error:
        validator.validate(value)
    assert error.value.status_code == 403


def test_oidc_rejects_missing_roles(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    with pytest.raises(HTTPException) as error:
        validator.validate(token(private, realm_access={"roles": []}))
    assert error.value.status_code == 403


def test_oidc_rejects_wrong_issuer(monkeypatch):
    validator, private = configured_validator(monkeypatch)
    with pytest.raises(HTTPException) as error:
        validator.validate(token(private, iss="https://attacker.invalid"))
    assert error.value.status_code == 401
