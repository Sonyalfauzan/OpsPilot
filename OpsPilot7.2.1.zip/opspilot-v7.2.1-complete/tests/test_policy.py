import pytest

from platform_core.policy import authorize


def test_read_permitted():
    authorize("query_metric", ["analyst"])


def test_write_requires_approval():
    with pytest.raises(PermissionError):
        authorize("rollback_model", ["mlops"])
    authorize("rollback_model", ["mlops"], True)


def test_unknown_denied():
    with pytest.raises(PermissionError):
        authorize("delete_database", ["mlops"], True)
