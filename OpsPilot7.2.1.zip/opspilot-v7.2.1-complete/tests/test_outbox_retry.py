from datetime import UTC, datetime

from platform_core.database import OutboxEvent
from platform_core.outbox_worker import MAX_ATTEMPTS, retry_delay


def test_retry_delay_is_bounded_and_increasing():
    assert retry_delay(2) > retry_delay(1)
    assert retry_delay(20).total_seconds() == 300


def test_dead_letter_threshold_is_finite():
    assert MAX_ATTEMPTS == 5
    event = OutboxEvent(
        id="e",
        tenant_id="t",
        topic="x",
        payload={},
        attempts=MAX_ATTEMPTS,
        status="DEAD_LETTER",
        next_attempt_at=datetime.now(UTC),
    )
    assert event.status == "DEAD_LETTER"
