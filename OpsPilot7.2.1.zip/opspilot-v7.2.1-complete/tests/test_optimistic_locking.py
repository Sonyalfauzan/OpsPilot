import pytest
from sqlalchemy.orm.exc import StaleDataError

from platform_core.database import Base, Incident, get_engine, get_session_factory


@pytest.mark.asyncio
async def test_incident_version_rejects_stale_update():
    engine = get_engine()
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    factory = get_session_factory()
    async with factory() as seed:
        seed.add(
            Incident(
                id="lock-1",
                tenant_id="tenant-alpha",
                domain="retail",
                incident_type="test",
                title="test",
                severity="SEV-4",
                status="OPEN",
                evidence=[],
            )
        )
        await seed.commit()
    async with factory() as first, factory() as second:
        one = await first.get(Incident, "lock-1")
        two = await second.get(Incident, "lock-1")
        one.status = "INVESTIGATING"
        await first.commit()
        two.status = "CLOSED"
        with pytest.raises(StaleDataError):
            await second.commit()
