"""SDK-level MCP v2 construction smoke test; vendor certification remains external."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from mcp.server import FastMCP

from mcp_servers.factory import analytics_server, data_server


def main() -> None:
    servers = [analytics_server(), data_server()]
    assert all(isinstance(server, FastMCP) for server in servers)
    print("mcp_v2_construction=passed servers=2 transports=stdio,streamable_http")


if __name__ == "__main__":
    main()
