"""AST-aware incomplete-implementation and documentation consistency gate."""

from __future__ import annotations

import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_PASS = {("platform_core/database.py", "Base")}
TEXT_MARKERS = re.compile(r"\b(TODO|FIXME|TBD|XXX|coming soon|under construction)\b", re.I)


def main() -> None:
    findings = []
    for path in ROOT.rglob("*.py"):
        if any(part in {".git", ".venv", "__pycache__"} for part in path.parts):
            continue
        rel = str(path.relative_to(ROOT))
        text = path.read_text(encoding="utf-8")
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and len(node.body) == 1
                and isinstance(node.body[0], ast.Pass)
            ):
                findings.append(f"{rel}:{node.lineno}: empty function")
            if (
                isinstance(node, ast.Raise)
                and isinstance(node.exc, ast.Call)
                and getattr(node.exc.func, "id", None) == "NotImplementedError"
            ):
                findings.append(f"{rel}:{node.lineno}: NotImplementedError")
            if (
                isinstance(node, ast.ClassDef)
                and len(node.body) == 1
                and isinstance(node.body[0], ast.Pass)
                and (rel, node.name) not in ALLOWED_PASS
            ):
                findings.append(f"{rel}:{node.lineno}: empty class")
        for line_no, line in enumerate(text.splitlines(), 1):
            if TEXT_MARKERS.search(line) and "scan_incomplete.py" not in rel:
                findings.append(f"{rel}:{line_no}: marker")
    if findings:
        raise SystemExit("incomplete implementation scan failed:\n" + "\n".join(findings))
    print("incomplete_scan=passed findings=0")


if __name__ == "__main__":
    main()
