"""Validate synthetic-only production-validation assets without external clusters."""

import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def main():
    provenance = yaml.safe_load((ROOT / "validation/provenance.yaml").read_text(encoding="utf-8"))
    assert provenance["contains_original_operational_records"] is False
    assert provenance["contains_pii"] is False
    assert provenance["contains_credentials"] is False
    scenarios = yaml.safe_load(
        (ROOT / "validation/scenarios/failure-matrix.yaml").read_text(encoding="utf-8")
    )["scenarios"]
    assert len(scenarios) >= 5 and all(v["assertions"] for v in scenarios.values())
    privacy = yaml.safe_load(
        (ROOT / "validation/privacy/privacy-policy.yaml").read_text(encoding="utf-8")
    )
    assert "raw_partner_telemetry" in privacy["prohibited_repository_content"]
    interop = yaml.safe_load(
        (ROOT / "validation/interop/mcp-matrix.yaml").read_text(encoding="utf-8")
    )
    assert {"stdio", "streamable_http"} <= set(interop["transports"])
    print(
        json.dumps(
            {"validation_assets": "passed", "scenarios": len(scenarios), "original_rows": 0},
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
