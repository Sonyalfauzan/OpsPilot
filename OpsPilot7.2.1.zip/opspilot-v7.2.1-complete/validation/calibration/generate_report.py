"""Generate a synthetic calibration report without ingesting operational records."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import json
from pathlib import Path

import numpy as np

from data_platform.simulation import SimulationConfig, simulate_series

OUT = Path("artifacts/synthetic-calibration-report.json")


def main() -> None:
    series = simulate_series(5000, SimulationConfig(mode="physics_informed", seed=2026))
    report = {
        "provenance": "synthetic-only",
        "rows": len(series["time"]),
        "seed": 2026,
        "temperature": {
            "mean": float(np.mean(series["temperature"])),
            "p95": float(np.quantile(series["temperature"], 0.95)),
        },
        "vibration": {
            "mean": float(np.mean(series["vibration"])),
            "p95": float(np.quantile(series["vibration"], 0.95)),
        },
        "degradation_peak": float(np.max(series["degradation"])),
        "limitations": [
            "not fitted to an identified physical asset",
            "not evidence of field accuracy",
        ],
    }
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(OUT)


if __name__ == "__main__":
    main()
