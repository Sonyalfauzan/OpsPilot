"""Fail closed on likely secrets, private keys and prohibited raw-data markers."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXCLUDED = {".git", ".venv", "__pycache__", "data", "artifacts"}
RULES = {
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "aws_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "bearer_token": re.compile(r"Bearer\s+[A-Za-z0-9._-]{30,}"),
    "raw_partner_marker": re.compile(r"raw[_ -]?partner[_ -]?telemetry", re.I),
}
ALLOWLIST = {"validation/privacy/privacy-policy.yaml", "validation/privacy/scan_repository.py"}


def main() -> None:
    findings = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in EXCLUDED for part in path.parts):
            continue
        relative = str(path.relative_to(ROOT))
        if relative in ALLOWLIST or path.suffix.lower() in {
            ".png",
            ".jpg",
            ".zip",
            ".parquet",
            ".db",
        }:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for name, rule in RULES.items():
            if rule.search(text):
                findings.append(f"{relative}: {name}")
    if findings:
        raise SystemExit("privacy scan failed:\n" + "\n".join(findings))
    print("privacy_scan=passed findings=0")


if __name__ == "__main__":
    main()
