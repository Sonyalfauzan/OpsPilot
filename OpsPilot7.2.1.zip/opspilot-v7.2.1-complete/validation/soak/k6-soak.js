import http from 'k6/http';
import { check, sleep } from 'k6';
export const options = { stages: [{ duration: '10m', target: 20 }, { duration: '23h40m', target: 20 }, { duration: '10m', target: 0 }], thresholds: { http_req_failed: ['rate<0.01'], http_req_duration: ['p(99)<2000'] } };
export default function () { const response = http.get(`${__ENV.BASE_URL || 'http://api:8000'}/health`); check(response, { healthy: r => r.status === 200 }); sleep(1); }
