import argparse
from pathlib import Path

from data_platform.scenarios import SCENARIOS, inject
from platform_core.registry import registry

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--domain", required=True)
    p.add_argument("--tenant", default="tenant-alpha")
    p.add_argument("--rows", type=int, default=5000)
    p.add_argument("--scenario", choices=sorted(SCENARIOS), default="normal")
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    frame = inject(registry().get(a.domain).generate(a.rows, a.seed), a.scenario, a.seed)
    frame["tenant_id"] = a.tenant
    out = Path("data") / a.tenant / "bronze" / a.domain
    out.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(out / "events.parquet", index=False)
    print(out)
