import hashlib,json
def lineage_id(*,tenant_id,source_ids,transform,version='1'):
    value=json.dumps({'tenant_id':tenant_id,'source_ids':sorted(source_ids),'transform':transform,'version':version},sort_keys=True,separators=(',',':'))
    return hashlib.sha256(value.encode()).hexdigest()[:32]
def attach_lineage(frame,*,tenant_id,source_column,transform):
    result=frame.copy();result['lineage_id']=[lineage_id(tenant_id=tenant_id,source_ids=[str(v)],transform=transform) for v in result[source_column]];return result
