"""Tenant-scoped generic medallion pipeline."""

import json
from pathlib import Path

from data_platform.lineage import attach_lineage
from data_platform.storage import read_frame, write_frame
from platform_core.registry import registry


def validate(frame, domain: str) -> dict:
    return registry().get(domain).validate(frame)


def run(domain: str, tenant_id: str = "tenant-alpha") -> dict:
    plugin = registry().get(domain)
    tenant_root = Path("data") / tenant_id
    bronze_path = tenant_root / "bronze" / domain / "events.parquet"
    frame = read_frame(bronze_path)
    bronze = attach_lineage(frame, tenant_id=tenant_id, source_column="event_id", transform=f"{domain}.bronze.v1")
    write_frame(bronze, bronze_path)
    report = plugin.validate(frame)
    quality_dir = tenant_root / "quality" / domain
    quality_dir.mkdir(parents=True, exist_ok=True)
    (quality_dir / "latest.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    if not report["passed"]:
        raise ValueError(report)
    silver = plugin.transform_silver(bronze)
    silver = attach_lineage(silver, tenant_id=tenant_id, source_column="event_id", transform=f"{domain}.silver.v1")
    write_frame(silver, tenant_root / "silver" / domain / "events.parquet")
    for name, mart in plugin.build_marts(silver).items():
        source = "event_id" if "event_id" in mart.columns else "lineage_id"
        gold = attach_lineage(mart, tenant_id=tenant_id, source_column=source, transform=f"{domain}.gold.{name}.v1")
        write_frame(gold, tenant_root / "gold" / domain / f"{name}.parquet")
    return report
