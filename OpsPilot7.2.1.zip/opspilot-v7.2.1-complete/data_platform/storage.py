from pathlib import Path

import pandas as pd


def write_frame(frame: pd.DataFrame, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        frame.to_parquet(path, index=False)
        return path
    except ImportError:
        fallback = path.with_suffix(".jsonl")
        frame.to_json(fallback, orient="records", lines=True, date_format="iso")
        return fallback


def read_frame(path: Path) -> pd.DataFrame:
    if path.exists():
        try:
            return pd.read_parquet(path)
        except ImportError:
            pass
    fallback = path.with_suffix(".jsonl")
    if fallback.exists():
        return pd.read_json(fallback, orient="records", lines=True)
    raise FileNotFoundError(path)
