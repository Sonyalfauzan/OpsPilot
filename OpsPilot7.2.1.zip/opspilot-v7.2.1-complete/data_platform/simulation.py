"""Deterministic temporal, non-linear and fault-injection simulation primitives."""

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SimulationConfig:
    mode: str = "parametric"
    seed: int = 42
    noise: float = 0.05
    fault_start: float = 0.65
    recovery_start: float = 0.85


def simulate_series(rows: int, config: SimulationConfig) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(config.seed)
    t = np.linspace(0, 1, rows)
    ambient = 25 + 8 * np.sin(2 * np.pi * t)
    if config.mode == "parametric":
        load = rng.uniform(0.2, 1, rows)
        degradation = np.zeros(rows)
    elif config.mode in {"scenario", "physics_informed", "hybrid"}:
        load = 0.55 + 0.25 * np.sin(6 * np.pi * t) + rng.normal(0, 0.03, rows)
        degradation = np.clip((t - config.fault_start) * 5, 0, 1)
        degradation = np.where(
            t >= config.recovery_start,
            degradation * np.exp(-20 * (t - config.recovery_start)),
            degradation,
        )
    else:
        raise ValueError(f"unsupported simulation mode: {config.mode}")
    temperature = np.empty(rows)
    temperature[0] = ambient[0]
    for i in range(1, rows):
        temperature[i] = (
            temperature[i - 1]
            + 0.12 * (ambient[i] + 55 * load[i] - temperature[i])
            + 0.8 * degradation[i]
            + rng.normal(0, config.noise)
        )
    vibration = 1.5 + 2 * load + 7 * degradation**2 + rng.normal(0, config.noise, rows)
    return {
        "time": t,
        "load": load,
        "ambient": ambient,
        "temperature": temperature,
        "vibration": vibration,
        "degradation": degradation,
    }
