import argparse
from pathlib import Path

from platform_core.registry import registry


def generate(domain, rows, seed=42):
    return registry().get(domain).generate(rows, seed)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--domain", required=True)
    p.add_argument("--rows", type=int, default=1000)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    plugin = registry().get(a.domain)
    frame = plugin.generate(a.rows, a.seed)
    out = Path("data/bronze") / a.domain
    out.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(out / "events.parquet", index=False)
    print(out / "events.parquet")


if __name__ == "__main__":
    main()
