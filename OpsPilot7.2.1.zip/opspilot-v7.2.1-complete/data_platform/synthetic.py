"""Deterministic synthetic-data primitives shared by all domain plugins."""

from datetime import UTC, datetime, timedelta
from uuid import NAMESPACE_URL, uuid5

import numpy as np

DEFAULT_ANCHOR = datetime(2026, 1, 1, tzinfo=UTC)


def generator(seed: int) -> np.random.Generator:
    return np.random.default_rng(seed)


def event_id(domain: str, seed: int, index: int) -> str:
    return str(uuid5(NAMESPACE_URL, f"opspilot:{domain}:{seed}:{index}"))


def timestamp(index: int, rows: int, anchor: datetime = DEFAULT_ANCHOR) -> datetime:
    if anchor.tzinfo is None:
        raise ValueError("anchor timestamp must be timezone aware")
    return anchor - timedelta(minutes=rows - index)


def entity_id(domain: str, seed: int, index: int) -> str:
    return f"{domain}-{seed:08d}-{index:08d}"
