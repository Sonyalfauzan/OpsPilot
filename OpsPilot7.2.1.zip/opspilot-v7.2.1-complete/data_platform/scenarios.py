import pandas as pd

SCENARIOS = {
    "normal",
    "seasonality",
    "data-drift",
    "concept-drift",
    "schema-drift",
    "missing-values",
    "duplicates",
    "late-events",
    "outliers",
    "latency-regression",
}


def inject(frame, scenario, seed=42):
    f = frame.copy()
    if scenario == "normal":
        return f
    if scenario == "missing-values":
        f.loc[f.index[::10], f.select_dtypes("number").columns[0]] = None
    elif scenario == "duplicates":
        f = pd.concat([f, f.iloc[:5]], ignore_index=True)
    elif scenario == "outliers":
        f.loc[f.index[:5], f.select_dtypes("number").columns[0]] *= 100
    elif scenario == "schema-drift":
        f["unexpected_v2_field"] = "new"
    elif scenario in {"data-drift", "concept-drift", "seasonality"}:
        for column in f.select_dtypes("number").columns:
            f[column] = f[column].astype(float) * 1.35
    elif scenario == "late-events":
        f = f.sort_values("event_timestamp", ascending=False)
    return f
