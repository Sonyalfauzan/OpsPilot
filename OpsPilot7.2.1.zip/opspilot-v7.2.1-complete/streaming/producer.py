"""Schema-validated Redpanda/Kafka producer for tenant-scoped events."""
import argparse,json,os
from collections.abc import Iterable
from datetime import UTC,datetime
from uuid import uuid4
from platform_core.registry import registry
from streaming.schema_registry import SchemaRegistryClient,validate_event

def serialized_events(domain:str,tenant_id:str,count:int,seed:int)->Iterable[tuple[str,bytes]]:
    frame=registry().get(domain).generate(count,seed)
    for record in frame.to_dict("records"):
        event_id=str(record.get("event_id") or uuid4())
        envelope=validate_event({"schema_version":"1","event_id":event_id,"tenant_id":tenant_id,"event_type":f"{domain}.telemetry","occurred_at":datetime.now(UTC).isoformat(),"lineage_id":record.get("lineage_id",event_id),"payload":{"domain":domain,**record}})
        yield event_id,json.dumps(envelope,default=str,sort_keys=True).encode()

def publish(domain:str,tenant_id:str,count:int,seed:int,producer=None,registry_client=None)->int:
    if producer is None:
        from confluent_kafka import Producer
        producer=Producer({"bootstrap.servers":os.getenv("KAFKA_BOOTSTRAP_SERVERS","redpanda:9092"),"enable.idempotence":True,"acks":"all","retries":5})
    registry_client=registry_client or SchemaRegistryClient()
    schema_id=registry_client.register()
    topic=os.getenv("KAFKA_TOPIC","opspilot.events.v1");published=0
    for key,value in serialized_events(domain,tenant_id,count,seed):
        producer.produce(topic,key=key,value=value,headers={"tenant_id":tenant_id,"domain":domain,"schema_version":"1","schema_id":str(schema_id)})
        producer.poll(0);published+=1
    producer.flush(30);return published
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--domain",default="logistics");parser.add_argument("--tenant",default="tenant-alpha");parser.add_argument("--count",type=int,default=100);parser.add_argument("--seed",type=int,default=42);a=parser.parse_args();print({"published":publish(a.domain,a.tenant,a.count,a.seed)})
