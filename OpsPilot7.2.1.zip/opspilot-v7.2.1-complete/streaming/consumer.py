"""Resilient Kafka consumer with persistent deduplication, metrics and DLQ."""

import json
import os
import time
from functools import lru_cache
from pathlib import Path

import pandas as pd
import yaml
from prometheus_client import Counter, Histogram

from data_platform.storage import write_frame
from platform_core.registry import registry
from streaming.deduplication import build_store
from streaming.rebalance import RebalanceCoordinator
from streaming.schema_registry import validate_event
from platform_core.live import publish_shared_sync

PROCESSED = Counter(
    "opspilot_stream_events_total", "Streaming event outcomes", ["outcome", "domain"]
)
LATENCY = Histogram(
    "opspilot_stream_processing_seconds", "Streaming event processing latency", ["domain"]
)


@lru_cache(maxsize=1)
def domain_contract_index() -> dict[str, frozenset[str]]:
    return {
        name: frozenset(
            yaml.safe_load(registry().get(name).contract_path.read_text(encoding="utf-8"))[
                "required"
            ]
        )
        for name in registry().names()
    }


class EventProcessor:
    def __init__(self, root: str | Path = "data", allow_legacy_inference: bool = False) -> None:
        self.root = Path(root)
        self.allow_legacy_inference = allow_legacy_inference
        self.dedup = build_store(self.root)

    def process(self, payload: bytes) -> str:
        started = time.perf_counter()
        domain = "unknown"
        try:
            event = validate_event(json.loads(payload))
            domain = event["payload"].get("domain")
            record = {**event["payload"], "event_id": event["event_id"], "tenant_id": event["tenant_id"], "schema_version": event["schema_version"], "lineage_id": event.get("lineage_id"), "event_timestamp": event["occurred_at"]}
            if not self.dedup.claim(event["tenant_id"], event["event_id"], 86400):
                PROCESSED.labels("duplicate", domain).inc()
                return "duplicate"
            plugin = registry().get(domain)
            frame = pd.DataFrame([record])
            if not plugin.validate(frame)["passed"]:
                raise ValueError("domain contract rejected event")
            target = self.root / event["tenant_id"] / "bronze" / domain / "stream-events.parquet"
            try:
                from data_platform.storage import read_frame

                existing = read_frame(target)
            except FileNotFoundError:
                existing = pd.DataFrame()
            write_frame(pd.concat([existing, frame], ignore_index=True), target)
            self.dedup.complete(event["tenant_id"], event["event_id"])
            PROCESSED.labels("accepted", domain).inc()
            return "accepted"
        except Exception as exc:
            if "event" in locals() and {"tenant_id", "event_id"} <= event.keys():
                self.dedup.release(event["tenant_id"], event["event_id"])
            self._dead_letter(payload, str(exc))
            tenant = event.get("tenant_id", "unknown") if "event" in locals() else "unknown"
            publish_shared_sync(tenant, {"type": "dlq.changed", "domain": domain})
            PROCESSED.labels("dead_letter", domain).inc()
            return "dead_letter"
        finally:
            LATENCY.labels(domain).observe(time.perf_counter() - started)

    def _legacy_domain(self, event: dict) -> str:
        if not self.allow_legacy_inference:
            raise ValueError("domain is required in the event envelope")
        candidates = [
            name for name, required in domain_contract_index().items() if required <= event.keys()
        ]
        if len(candidates) != 1:
            raise ValueError("domain cannot be inferred unambiguously")
        return candidates[0]

    def _dead_letter(self, payload: bytes, error: str) -> None:
        path = self.root / "dead-letter/events.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a") as handle:
            handle.write(
                json.dumps({"payload": payload.decode(errors="replace"), "error": error}) + "\n"
            )


def consume_forever(processor: EventProcessor | None = None) -> None:
    from confluent_kafka import Consumer, Producer

    processor = processor or EventProcessor()
    coordinator = RebalanceCoordinator(float(os.getenv("REBALANCE_DRAIN_TIMEOUT_SECONDS", "30")))
    consumer = Consumer(
        {
            "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "redpanda:9092"),
            "group.id": os.getenv("KAFKA_GROUP_ID", "opspilot-bronze-v2"),
            "auto.offset.reset": "earliest",
            "enable.auto.commit": False,
            "group.protocol": os.getenv("KAFKA_GROUP_PROTOCOL", "consumer"),
        }
    )
    consumer.subscribe(
        [os.getenv("KAFKA_TOPIC", "opspilot.events.v1")],
        on_assign=coordinator.on_assign,
        on_revoke=coordinator.on_revoke,
        on_lost=coordinator.on_lost,
    )
    try:
        while True:
            message = consumer.poll(1)
            if message is None:
                continue
            if message.error():
                raise RuntimeError(message.error())
            if not coordinator.enter():
                continue
            try:
                result = processor.process(message.value())
            finally:
                coordinator.leave()
            if result == "dead_letter":
                Producer(
                    {"bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "redpanda:9092")}
                ).produce(
                    os.getenv("KAFKA_DLQ_TOPIC", "opspilot.events.dlq.v1"), value=message.value()
                )
            consumer.commit(message, asynchronous=False)
    finally:
        consumer.close()


if __name__ == "__main__":
    consume_forever()
