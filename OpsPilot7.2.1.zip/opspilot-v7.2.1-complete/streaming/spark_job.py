"""Checkpointed, watermark-bounded Kafka-to-bronze Structured Streaming job."""

import logging
import os
import signal

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StringType, StructField, StructType, TimestampType

logger = logging.getLogger(__name__)
schema = StructType(
    [
        StructField("event_id", StringType(), False),
        StructField("event_timestamp", TimestampType(), False),
        StructField("tenant_id", StringType(), False),
        StructField("domain", StringType(), False),
        StructField("schema_version", StringType(), False),
    ]
)
spark = SparkSession.builder.appName("opspilot-streaming").getOrCreate()
query = None


def shutdown(*_):
    if query and query.isActive:
        query.stop()
    spark.stop()


signal.signal(signal.SIGTERM, shutdown)
signal.signal(signal.SIGINT, shutdown)
try:
    source = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", os.getenv("KAFKA_BOOTSTRAP_SERVERS", "redpanda:9092"))
        .option("subscribe", os.getenv("KAFKA_TOPIC", "opspilot.events.v1"))
        .option("startingOffsets", "earliest")
        .load()
    )
    events = source.select(from_json(col("value").cast("string"), schema).alias("event")).select(
        "event.*"
    )
    valid = events.filter(
        col("event_id").isNotNull() & col("tenant_id").isNotNull() & col("domain").isNotNull()
    )
    deduplicated = valid.withWatermark("event_timestamp", "15 minutes").dropDuplicates(
        ["tenant_id", "event_id"]
    )
    query = (
        deduplicated.writeStream.format("parquet")
        .option("path", os.getenv("BRONZE_PATH", "/data/streaming/bronze"))
        .option(
            "checkpointLocation", os.getenv("CHECKPOINT_PATH", "/data/streaming/checkpoints/bronze")
        )
        .partitionBy("tenant_id", "domain")
        .outputMode("append")
        .start()
    )
    query.awaitTermination()
except Exception:
    logger.exception("streaming query failed")
    if query and query.isActive:
        query.stop()
    raise
finally:
    spark.stop()
