"""JSON Schema validation and Redpanda/Confluent Schema Registry integration."""
from __future__ import annotations
import json, os
from functools import lru_cache
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from jsonschema import Draft202012Validator
SCHEMA_PATH = Path(__file__).with_name("schemas") / "event-envelope-v1.json"
SUBJECT = os.getenv("SCHEMA_REGISTRY_SUBJECT", "opspilot.events-value")
REGISTRY_URL = os.getenv("SCHEMA_REGISTRY_URL", "http://redpanda:8081").rstrip("/")
@lru_cache
def schema() -> dict: return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
@lru_cache
def validator() -> Draft202012Validator: return Draft202012Validator(schema())
def validate_event(event: dict) -> dict: validator().validate(event); return event
class SchemaRegistryError(RuntimeError):
    """Schema Registry transport or compatibility failure."""
class SchemaRegistryClient:
    def __init__(self, base_url: str = REGISTRY_URL, subject: str = SUBJECT, timeout: float = 5.0): self.base_url=base_url.rstrip('/');self.subject=subject;self.timeout=timeout
    def _request(self, method: str, path: str, payload: dict | None = None) -> dict:
        body=None if payload is None else json.dumps(payload).encode()
        request=Request(self.base_url+path,data=body,method=method,headers={"Content-Type":"application/vnd.schemaregistry.v1+json"})
        try:
            with urlopen(request,timeout=self.timeout) as response: return json.loads(response.read().decode())
        except (HTTPError,URLError,TimeoutError) as exc: raise SchemaRegistryError(f"schema registry request failed: {method} {path}: {exc}") from exc
    def check_compatibility(self) -> bool:
        payload={"schemaType":"JSON","schema":json.dumps(schema(),sort_keys=True)}
        try:return bool(self._request("POST",f"/compatibility/subjects/{self.subject}/versions/latest",payload).get("is_compatible"))
        except SchemaRegistryError as exc:
            if "404" in str(exc): return True
            raise
    def register(self) -> int:
        if not self.check_compatibility(): raise SchemaRegistryError(f"incompatible schema for {self.subject}")
        payload={"schemaType":"JSON","schema":json.dumps(schema(),sort_keys=True)}
        return int(self._request("POST",f"/subjects/{self.subject}/versions",payload)["id"])
    def latest(self) -> dict: return self._request("GET",f"/subjects/{self.subject}/versions/latest")
