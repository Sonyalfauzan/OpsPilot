# ruff: noqa: E501
"""Atomic deduplication backends for local and distributed consumers."""

import os
import sqlite3
from abc import ABC, abstractmethod
from datetime import UTC, datetime, timedelta
from pathlib import Path


class DeduplicationStore(ABC):
    @abstractmethod
    def claim(self, tenant_id: str, event_id: str, retention_seconds: int) -> bool: ...
    @abstractmethod
    def complete(self, tenant_id: str, event_id: str) -> None: ...
    @abstractmethod
    def release(self, tenant_id: str, event_id: str) -> None: ...


class SQLiteDeduplicationStore(DeduplicationStore):
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self._connect() as c:
            c.execute(
                "CREATE TABLE IF NOT EXISTS event_claims(tenant_id TEXT,event_id TEXT,status TEXT,expires_at REAL,PRIMARY KEY(tenant_id,event_id))"
            )

    def _connect(self):
        return sqlite3.connect(self.path, timeout=30, isolation_level="IMMEDIATE")

    def claim(self, t, e, ttl):
        now = datetime.now(UTC).timestamp()
        with self._connect() as c:
            c.execute("DELETE FROM event_claims WHERE expires_at<? AND status='CLAIMED'", (now,))
            return (
                c.execute(
                    "INSERT OR IGNORE INTO event_claims VALUES(?,?,?,?)",
                    (t, e, "CLAIMED", now + ttl),
                ).rowcount
                == 1
            )

    def complete(self, t, e):
        with self._connect() as c:
            c.execute(
                "UPDATE event_claims SET status='COMPLETED' WHERE tenant_id=? AND event_id=?",
                (t, e),
            )

    def release(self, t, e):
        with self._connect() as c:
            c.execute(
                "DELETE FROM event_claims WHERE tenant_id=? AND event_id=? AND status='CLAIMED'",
                (t, e),
            )


class RedisDeduplicationStore(DeduplicationStore):
    def __init__(self, url):
        from redis import Redis

        self.client = Redis.from_url(url, decode_responses=True)

    def key(self, t, e):
        return f"opspilot:dedup:{t}:{e}"

    def claim(self, t, e, ttl):
        return bool(self.client.set(self.key(t, e), "CLAIMED", nx=True, ex=ttl))

    def complete(self, t, e):
        self.client.set(self.key(t, e), "COMPLETED", xx=True, keepttl=True)

    def release(self, t, e):
        if self.client.get(self.key(t, e)) == "CLAIMED":
            self.client.delete(self.key(t, e))


class PostgresDeduplicationStore(DeduplicationStore):
    def __init__(self, dsn):
        import psycopg

        self.driver = psycopg
        self.dsn = dsn
        with psycopg.connect(dsn) as c:
            c.execute(
                "CREATE TABLE IF NOT EXISTS stream_event_claims(tenant_id text,event_id text,status text,expires_at timestamptz,PRIMARY KEY(tenant_id,event_id))"
            )

    def claim(self, t, e, ttl):
        expiry = datetime.now(UTC) + timedelta(seconds=ttl)
        with self.driver.connect(self.dsn) as c:
            return (
                c.execute(
                    "INSERT INTO stream_event_claims VALUES(%s,%s,'CLAIMED',%s) ON CONFLICT DO NOTHING RETURNING event_id",
                    (t, e, expiry),
                ).fetchone()
                is not None
            )

    def complete(self, t, e):
        with self.driver.connect(self.dsn) as c:
            c.execute(
                "UPDATE stream_event_claims SET status='COMPLETED' WHERE tenant_id=%s AND event_id=%s",
                (t, e),
            )

    def release(self, t, e):
        with self.driver.connect(self.dsn) as c:
            c.execute(
                "DELETE FROM stream_event_claims WHERE tenant_id=%s AND event_id=%s AND status='CLAIMED'",
                (t, e),
            )


def build_store(root: Path):
    backend = os.getenv("DEDUP_BACKEND", "sqlite")
    if backend == "redis":
        return RedisDeduplicationStore(os.environ["DEDUP_REDIS_URL"])
    if backend == "redis_cluster":
        return RedisClusterDeduplicationStore(os.environ["DEDUP_REDIS_CLUSTER_NODES"])
    if backend == "postgres":
        return PostgresDeduplicationStore(os.environ["DEDUP_POSTGRES_DSN"])
    if backend == "sqlite":
        return SQLiteDeduplicationStore(root / ".state/dedup.sqlite3")
    raise ValueError(f"unknown dedup backend: {backend}")


class RedisClusterDeduplicationStore(RedisDeduplicationStore):
    """Redis Cluster backend using a hash-tagged, single-key atomic claim."""

    def __init__(self, urls: str) -> None:
        from redis.cluster import RedisCluster

        nodes = []
        for endpoint in urls.split(","):
            host, port = endpoint.strip().rsplit(":", 1)
            nodes.append({"host": host, "port": int(port)})
        self.client = RedisCluster(
            startup_nodes=nodes, decode_responses=True, skip_full_coverage_check=False
        )

    def key(self, tenant_id: str, event_id: str) -> str:
        return f"opspilot:dedup:{{{tenant_id}:{event_id}}}:state"
