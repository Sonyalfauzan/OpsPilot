"""Consumer-group rebalance callbacks with explicit in-flight drainage."""

from __future__ import annotations

import logging
from threading import Event, Lock
from time import monotonic, sleep

LOGGER = logging.getLogger(__name__)


class RebalanceCoordinator:
    def __init__(self, drain_timeout_seconds: float = 30) -> None:
        self.timeout = drain_timeout_seconds
        self.accepting = Event()
        self.accepting.set()
        self._lock = Lock()
        self._inflight = 0

    def enter(self) -> bool:
        if not self.accepting.is_set():
            return False
        with self._lock:
            self._inflight += 1
        return True

    def leave(self) -> None:
        with self._lock:
            self._inflight = max(0, self._inflight - 1)

    def on_assign(self, consumer, partitions) -> None:
        LOGGER.info("partitions_assigned", extra={"partitions": len(partitions)})
        self.accepting.set()

    def on_revoke(self, consumer, partitions) -> None:
        self.accepting.clear()
        deadline = monotonic() + self.timeout
        while self._inflight and monotonic() < deadline:
            sleep(0.05)
        LOGGER.info(
            "partitions_revoked",
            extra={"partitions": len(partitions), "remaining_inflight": self._inflight},
        )

    def on_lost(self, consumer, partitions) -> None:
        self.accepting.clear()
        LOGGER.error("partitions_lost", extra={"partitions": len(partitions)})
