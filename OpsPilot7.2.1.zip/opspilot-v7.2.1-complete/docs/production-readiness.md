# Production Readiness and Limits

## Implemented application controls

- domain plugin isolation by interface and architecture tests
- tenant-scoped incident reads and audit records
- deny-by-default tool policy
- signed, scoped, expiring approval tokens
- used-token persistence model for replay prevention
- idempotency and transactional outbox persistence models
- structured API and MCP inputs
- no arbitrary SQL MCP interface
- secure-production configuration validation
- immutable model metadata and reproducible seeds
- health and Prometheus endpoints
- CI lint, tests, dependency audit and image build

## Deployment-specific gates still required

No source archive can supply organization-specific OIDC tenants, certificates, encryption keys, network routes, data-classification rules, backup destinations, SLOs, pager routing, legal basis, regulatory approvals or capacity evidence. Before production, complete:

1. OIDC integration and authorization mapping with the real identity provider.
2. PostgreSQL row-level security and isolated service identities.
3. Secret-manager, TLS/mTLS and certificate rotation.
4. Kubernetes network policy, pod security, resource quotas and admission policy.
5. Database migrations reviewed and rehearsed against a production clone.
6. Backup, point-in-time recovery and restore drills.
7. Load, soak, chaos and failover tests against measured SLOs.
8. Privacy impact, retention, lineage, bias and regulatory reviews.
9. Penetration testing, threat-model review and incident exercises.
10. Model validation using representative, legally usable data.

Production-grade is therefore a verified deployment state, not a property that can be guaranteed by a ZIP alone.
