# ADR-006: sqlite-local-postgresql-production
## Status
Accepted
## Context
The platform needs an explicit and reviewable decision for sqlite-local-postgresql-production.
## Decision
Use the implemented sqlite-local-postgresql-production design with bounded interfaces, validation, and observable failure behavior.
## Consequences
The decision improves consistency and reviewability while adding operational responsibilities documented in the implementation.
## Alternatives
A simpler implicit implementation was rejected because it hides trade-offs and weakens governance.
## Review triggers
Revisit when scale, threat model, or deployment topology materially changes.
