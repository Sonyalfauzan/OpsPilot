# ADR-007: ast-aware-incomplete-scan
## Status
Accepted
## Context
The platform needs an explicit and reviewable decision for ast-aware-incomplete-scan.
## Decision
Use the implemented ast-aware-incomplete-scan design with bounded interfaces, validation, and observable failure behavior.
## Consequences
The decision improves consistency and reviewability while adding operational responsibilities documented in the implementation.
## Alternatives
A simpler implicit implementation was rejected because it hides trade-offs and weakens governance.
## Review triggers
Revisit when scale, threat model, or deployment topology materially changes.
