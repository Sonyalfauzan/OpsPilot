# ADR-004: domain-plugin-entry-points
## Status
Accepted
## Context
The platform needs an explicit and reviewable decision for domain-plugin-entry-points.
## Decision
Use the implemented domain-plugin-entry-points design with bounded interfaces, validation, and observable failure behavior.
## Consequences
The decision improves consistency and reviewability while adding operational responsibilities documented in the implementation.
## Alternatives
A simpler implicit implementation was rejected because it hides trade-offs and weakens governance.
## Review triggers
Revisit when scale, threat model, or deployment topology materially changes.
