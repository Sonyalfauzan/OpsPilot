# ADR-005: identity-provider-password-boundary
## Status
Accepted
## Context
The platform needs an explicit and reviewable decision for identity-provider-password-boundary.
## Decision
Use the implemented identity-provider-password-boundary design with bounded interfaces, validation, and observable failure behavior.
## Consequences
The decision improves consistency and reviewability while adding operational responsibilities documented in the implementation.
## Alternatives
A simpler implicit implementation was rejected because it hides trade-offs and weakens governance.
## Review triggers
Revisit when scale, threat model, or deployment topology materially changes.
