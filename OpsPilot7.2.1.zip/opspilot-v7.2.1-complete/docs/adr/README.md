# Architecture Decision Records
Accepted decisions record context, choice, consequences, alternatives, and review triggers.
