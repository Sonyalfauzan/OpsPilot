# ADR-002: optimistic-concurrency
## Status
Accepted
## Context
The platform needs an explicit and reviewable decision for optimistic-concurrency.
## Decision
Use the implemented optimistic-concurrency design with bounded interfaces, validation, and observable failure behavior.
## Consequences
The decision improves consistency and reviewability while adding operational responsibilities documented in the implementation.
## Alternatives
A simpler implicit implementation was rejected because it hides trade-offs and weakens governance.
## Review triggers
Revisit when scale, threat model, or deployment topology materially changes.
