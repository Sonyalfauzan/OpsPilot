# Industrial Sector Catalog

OpsPilot v4 separates industrial sectors by operational semantics, data contracts, model targets, metrics, safety boundaries and runbooks. The taxonomy is intentionally broad while remaining maintainable. It does not claim that every company-specific subsector is identical.

## Natural resources and extraction

- Mining: mobile and fixed equipment health, payload, vibration, thermal risk and maintenance age.
- Oil and Gas: production-rate forecasting, pressure, choke position, water cut and pump efficiency.
- Forestry and Pulp: wood moisture, chip variability, digester conditions and mill availability.

## Energy and utilities

- Energy: demand/load forecasting.
- Renewable Energy: wind, solar irradiance, asset availability and curtailment.
- Water Utilities: pressure, night flow, meter variance, pipe aging and leak-risk signals.

## Discrete manufacturing

- Manufacturing: general machine health and predictive maintenance.
- Automotive: torque, paint thickness, vision quality and line-speed signals.
- Aerospace: dimensional deviation, traceability, non-destructive-test anomalies and process variance.
- Semiconductors: particles, critical dimensions, etch variation, tool health and wafer yield.

## Process manufacturing

- Chemicals: reactor conditions, feed purity, residence time and process yield.
- Pharmaceutical Manufacturing: excursion, environmental monitoring, capability, documentation and deviation risk.
- Food and Beverage: cold chain, moisture, microbial risk and processing-line quality.

## Infrastructure and built environment

- Construction: schedule risk, progress variance, crew availability, materials and weather.
- Real Estate: occupancy and maintenance demand.
- Data Centers: compute utilization, cooling efficiency, power draw, error rate and capacity incidents.

## Transport and industrial logistics

- Logistics: shipment delay and on-time delivery.
- Maritime and Ports: berth queues, cargo, cranes, weather and port-call turnaround.
- Rail Transport: congestion, rolling-stock health, weather, crews and service delay.

## Environmental operations

- Waste and Recycling: contamination, sorting, equipment availability, input volume and material recovery.

Every industrial plugin includes:

- validated `industrial.yaml` behavior specification;
- deterministic seeded data generation;
- data contract and quality rules;
- silver transformation and gold operational mart;
- regression or classification model;
- evaluation and prediction adapter;
- allowlisted metrics;
- prohibited physical/safety actions;
- model card, dashboard specification and incident runbook.

Physical control, safety overrides, regulatory certification, batch release, dispatch, grid switching and other consequential actions remain prohibited. The portfolio produces analysis, simulation, reports and human-review requests only.
