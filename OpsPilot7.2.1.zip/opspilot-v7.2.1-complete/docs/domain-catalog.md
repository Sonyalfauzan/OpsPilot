# Domain Catalog

OpsPilot v3 contains 13 active plugins, all executed by the same discovery, pipeline, training, serving, monitoring, MCP and incident lifecycle.

## Original domains

- Retail: demand and stockout operations.
- Manufacturing: predictive maintenance and machine health.
- Logistics: delivery delay and on-time performance.

## Added industries

- Finance: transaction-risk triage. Final account, credit and payment decisions are prohibited.
- Energy: load forecasting and meter operations. Grid and safety controls remain outside the platform.
- Agriculture: crop-yield forecasting and field monitoring. Automated pesticide or unsafe irrigation control is prohibited.
- Telecommunications: service-degradation detection and network operations.
- Hospitality: booking cancellation and occupancy-related operations.
- Education: learning-support demand. Automated grading and admission decisions are prohibited.
- Insurance: claim operations triage. Automatic denial or payout decisions are prohibited.
- Real Estate: maintenance-demand forecasting. Eviction and automatic rent changes are prohibited.
- Healthcare Operations: appointment no-show and administrative operations only. Diagnosis, treatment and medication recommendations are prohibited.
- Public Services: request-resolution forecasting. Eligibility and rights determinations are prohibited.

Every added plugin contains a manifest, data contract, metrics, policies, scenarios, model card, dashboard specification and incident runbook.
