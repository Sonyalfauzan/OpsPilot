# Domain Plugin Guide

A domain plugin is an independently installable Python package exposing one object through the `opspilot.domains` entry-point group. The core discovers plugins at runtime.

Required contract:

- deterministic synthetic-data generation
- contract validation
- silver transformation
- one or more named marts
- training set declaration
- estimator factory
- deterministic evaluation
- inference adapter
- allowlisted metric query

Run `pytest tests/test_domain_conformance.py tests/test_architecture.py` before installation. A plugin must never receive unrestricted database credentials and must not execute arbitrary code from its manifest.
