# Model Incident Runbook

1. Confirm tenant, domain, model version and affected window.
2. Check service health and feature availability before interpreting drift.
3. Compare reference/current data and delayed ground truth.
4. Separate observed facts, correlations and causal hypotheses.
5. Pause candidate rollout if a critical gate fails.
6. Require authorization before canary changes or rollback.
7. Verify technical and business recovery; do not close on tool success alone.
8. Document timeline, evidence, decisions, limitations and corrective actions.
