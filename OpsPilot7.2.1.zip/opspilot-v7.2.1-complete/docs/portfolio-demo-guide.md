# Portfolio demo guide

1. Start the lite profile. 2. Run the seeded demo. 3. Show Airflow and data layers. 4. Show dbt models and dashboards. 5. Compare model metadata. 6. Trigger synthetic drift. 7. Show agent evidence and RAG citations. 8. Approve the simulated action. 9. Show canary rollback, verification and postmortem. 10. Run the Definition of Done verifier and tests.
