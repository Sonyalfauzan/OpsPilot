# Threat Model

## Assets

Production credentials, tenant data, model artifacts, approval authority, audit records and deployment state.

## Trust boundaries

User/API, tenant/domain, agent/tool, MCP server, n8n, data store, model registry and deployment environment.

## Major threats and controls

- Prompt injection through logs or documents: treat tool output as data, structured output, restricted tools.
- Cross-tenant access: tenant predicates server-side, scoped credentials, deny by default.
- Excessive agency: read-only default, action allowlist, approval, bounded parameters and kill switch.
- Replay: short-lived signed approvals, idempotency keys and used-token storage in production.
- Injection: no arbitrary SQL MCP tool; parameter validation and prepared queries.
- Secret leakage: secret manager, redaction and no prompt-body logging by default.
- Resource exhaustion: rate, token, timeout and tool-call budgets.

## Residual risks

The local demo uses shared infrastructure and API keys. Production requires OIDC, tenant-isolated storage, TLS/mTLS, network policy, a durable nonce store, external secret manager and independent security review.
