# Platform Administration

The administration surface at `/admin` manages synthetic portfolio metadata for tenants, user profiles, role assignments, API credentials, feature flags, the service catalog and a redacted configuration view. Authentication credentials remain owned by the configured identity provider. OpsPilot does not store passwords.

## Identity boundary

In OIDC mode, Keycloak or another compatible identity provider authenticates users and issues signed tokens. OpsPilot validates issuer, audience, signature, expiry, tenant and roles. The local user profile records application metadata and access intent; it is not a second password database. Keycloak exposes an Admin REST API for externally managed user, group, realm, role and client administration, but production synchronization requires a dedicated service account with restricted permissions and is intentionally not enabled with bootstrap administrator credentials. 

## Administrative controls

- Tenants: create and list synthetic tenants.
- Users: create metadata records, assign approved roles, activate or deactivate access intent.
- API credentials: issue a random value once, store only SHA-256 material, assign scopes and expiry, and revoke credentials.
- Feature flags: tenant-aware flags with descriptions.
- Services: read-only catalog of local, full and validation profiles.
- Configuration: redacted, read-only runtime settings.

Infrastructure restarts, scaling, secrets, backups and certificate rotation remain responsibilities of Docker, Kubernetes, CI/CD and the selected secret manager. The application deliberately does not expose privileged container-control endpoints.
