# Failure scenarios
The seeder supports seasonality, data drift, concept drift, schema drift, missing values, duplicates, late events, outliers and latency regression. Each is deterministic by seed.