# Versioning Policy

OpsPilot separates platform, domain specification and event schema versions.

- Platform release: `7.2.1`. This identifies the repository and application release.
- Industrial domain specification: `4.0`. This is the stable schema generation used by the sixteen industrial domain packs. It is intentionally independent of the platform release and changes only when the domain contract itself changes.
- Streaming event schema: `1`. This identifies the event-envelope contract.
- Dashboard contract: validated independently through the dashboard schema.

A lower domain or event schema version is therefore not stale platform code. Compatibility is explicit and tested. A future incompatible domain contract will increment the domain specification version rather than inheriting the current platform number.
