# Architecture

```mermaid
flowchart LR
  Seeder --> Bronze --> Validate --> Silver --> Gold
  Gold --> dbt --> BI
  Silver --> Train --> Registry --> Serving
  Serving --> Monitor --> Incident
  Incident --> Agent --> MCP --> Approval --> Execute --> Verify --> Postmortem
```

The platform kernel owns identity, tenant scope, policy, audit, incidents and observability. Domain plugins own schemas, metrics, features and model adapters. Architecture tests prevent core modules from importing concrete domains.
