# Production Hardening Checklist

- Replace API keys with OIDC and workload identities.
- Enforce tenant filters in the database using row-level security.
- Put all services behind TLS and apply Kubernetes network policies.
- Pin container digests and generate SBOMs; scan images and dependencies.
- Use managed PostgreSQL/object storage with backups, PITR and restore drills.
- Store approval JTIs in a transactional used-token table.
- Add an outbox for side effects and idempotency records for every mutation.
- Deploy Airflow, n8n and MLflow separately with least-privilege service accounts.
- Add OpenTelemetry traces with sensitive payload capture disabled.
- Perform load, chaos, privacy, bias, disaster-recovery and penetration tests.
- Define SLOs, paging rules, on-call ownership and incident runbooks.
