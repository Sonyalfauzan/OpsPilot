"""Tenant foreign keys and lineage. Revision ID: 0003_referential_integrity; Revises: 0002_administration."""
from alembic import op
import sqlalchemy as sa
revision='0003_referential_integrity';down_revision='0002_administration';branch_labels=None;depends_on=None
TABLES=('incidents','audit_events','used_approvals','idempotency_records','outbox_events','user_profiles','api_credentials')
def upgrade():
    with op.batch_alter_table('incidents') as b:b.add_column(sa.Column('lineage_id',sa.String(64),nullable=True));b.create_index('ix_incidents_lineage_id',['lineage_id'])
    for table in TABLES:
        with op.batch_alter_table(table) as b:b.create_foreign_key(f'fk_{table}_tenant','tenants',['tenant_id'],['id'],ondelete='RESTRICT')
    with op.batch_alter_table('feature_flags') as b:b.create_foreign_key('fk_feature_flags_tenant','tenants',['tenant_id'],['id'],ondelete='CASCADE')
def downgrade():
    with op.batch_alter_table('feature_flags') as b:b.drop_constraint('fk_feature_flags_tenant',type_='foreignkey')
    for table in reversed(TABLES):
        with op.batch_alter_table(table) as b:b.drop_constraint(f'fk_{table}_tenant',type_='foreignkey')
    with op.batch_alter_table('incidents') as b:b.drop_index('ix_incidents_lineage_id');b.drop_column('lineage_id')
