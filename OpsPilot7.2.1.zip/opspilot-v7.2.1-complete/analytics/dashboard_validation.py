"""Strict vendor-neutral dashboard contract with namespaced extensions."""

import json
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, model_validator


class CardSpecification(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    visualization: str | None = None
    metric: str | None = None
    query: str | None = None


class DashboardSpecification(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    filters: list[str] = Field(min_length=1)
    metrics: list[str] = Field(default_factory=list)
    cards: list[CardSpecification] = Field(default_factory=list)
    extensions: dict[str, object] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_cards(self):
        unknown = {
            card.metric for card in self.cards if card.metric and card.metric not in self.metrics
        }
        if unknown:
            raise ValueError(f"card references unknown metrics: {sorted(unknown)}")
        return self


def validate_dashboard(path: str | Path) -> DashboardSpecification:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    allowed = {"name", "filters", "metrics", "cards", "extensions"}
    payload = {key: value for key, value in payload.items() if key in allowed}
    return DashboardSpecification.model_validate(payload)
