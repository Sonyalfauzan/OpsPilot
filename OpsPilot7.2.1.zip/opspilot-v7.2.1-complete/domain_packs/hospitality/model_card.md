# Hospitality model card

Synthetic portfolio model for booking_cancellation_prediction. No real-world consequential decisions.
