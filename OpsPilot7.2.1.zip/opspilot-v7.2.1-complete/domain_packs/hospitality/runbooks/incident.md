# Hospitality incident runbook

Validate data quality, model version, drift, operational metrics, approval policy and recovery signals.
