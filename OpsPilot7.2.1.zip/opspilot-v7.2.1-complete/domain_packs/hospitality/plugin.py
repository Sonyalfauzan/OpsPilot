from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="hospitality",
    entity="booking",
    features=[
        FeatureSpec("lead_time_days", 0, 365),
        FeatureSpec("price_index", 0.5, 3),
        FeatureSpec("seasonality_index", 0, 1),
    ],
    task="binary_classification",
    target="cancelled",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "lead_time_days"),
    directory=Path(__file__).parent,
)
