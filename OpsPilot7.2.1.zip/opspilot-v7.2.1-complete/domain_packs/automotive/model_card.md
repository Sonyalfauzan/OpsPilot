# Automotive model card

Objective: vehicle_manufacturing_quality. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
