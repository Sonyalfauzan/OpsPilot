# Healthcare Operations model card

Synthetic portfolio model for appointment_operations. No real-world consequential decisions.
