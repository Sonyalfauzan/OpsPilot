from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="healthcare_operations",
    entity="appointment",
    features=[
        FeatureSpec("lead_time_days", 0, 120),
        FeatureSpec("prior_no_show_rate", 0, 1),
        FeatureSpec("reminder_engagement", 0, 1),
    ],
    task="binary_classification",
    target="no_show",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "lead_time_days"),
    directory=Path(__file__).parent,
)
