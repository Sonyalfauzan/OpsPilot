# Water Utilities model card

Objective: water_distribution_monitoring. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
