from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="real_estate",
    entity="property",
    features=[
        FeatureSpec("building_age", 0, 80),
        FeatureSpec("occupancy_rate", 0, 1),
        FeatureSpec("open_requests", 0, 30),
    ],
    task="regression",
    target="maintenance_demand",
    primary_metric="mae",
    metrics=("records", "target_average", "building_age"),
    directory=Path(__file__).parent,
)
