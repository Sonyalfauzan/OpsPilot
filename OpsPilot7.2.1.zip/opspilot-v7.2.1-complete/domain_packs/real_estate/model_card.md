# Real Estate model card

Synthetic portfolio model for maintenance_demand_forecasting. No real-world consequential decisions.
