# Maritime And Ports model card

Objective: port_turnaround_forecasting. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
