# Pharmaceutical Manufacturing model card

Objective: gmp_batch_deviation_monitoring. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
