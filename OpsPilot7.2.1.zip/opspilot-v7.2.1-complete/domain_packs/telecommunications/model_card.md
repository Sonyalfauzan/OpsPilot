# Telecommunications model card

Synthetic portfolio model for network_degradation_detection. No real-world consequential decisions.
