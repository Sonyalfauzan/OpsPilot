from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="telecommunications",
    entity="network_session",
    features=[
        FeatureSpec("latency_ms", 5, 500),
        FeatureSpec("packet_loss", 0, 0.2),
        FeatureSpec("tower_load", 0, 1),
    ],
    task="binary_classification",
    target="service_degraded",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "latency_ms"),
    directory=Path(__file__).parent,
)
