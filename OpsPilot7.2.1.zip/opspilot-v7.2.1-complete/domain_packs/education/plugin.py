from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="education",
    entity="enrollment",
    features=[
        FeatureSpec("attendance_rate", 0, 1),
        FeatureSpec("engagement_score", 0, 1),
        FeatureSpec("assignment_completion", 0, 1),
    ],
    task="binary_classification",
    target="support_needed",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "attendance_rate"),
    directory=Path(__file__).parent,
)
