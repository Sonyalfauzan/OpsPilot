# Education model card

Synthetic portfolio model for learning_support_demand. No real-world consequential decisions.
