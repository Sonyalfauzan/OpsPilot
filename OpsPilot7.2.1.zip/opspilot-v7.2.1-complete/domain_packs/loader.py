from pathlib import Path

import yaml

BASE = Path(__file__).parent


def load_domain(name: str) -> dict:
    p = BASE / name / "domain.yaml"
    if not p.exists():
        raise ValueError(f"unsupported domain: {name}")
    return yaml.safe_load(p.read_text(encoding="utf-8"))
