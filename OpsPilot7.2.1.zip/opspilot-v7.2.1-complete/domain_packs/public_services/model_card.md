# Public Services model card

Synthetic portfolio model for service_request_forecasting. No real-world consequential decisions.
