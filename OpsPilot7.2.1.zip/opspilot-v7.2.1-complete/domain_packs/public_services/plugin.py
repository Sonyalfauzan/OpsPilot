from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="public_services",
    entity="service_request",
    features=[
        FeatureSpec("queue_depth", 0, 500),
        FeatureSpec("priority_score", 0, 1),
        FeatureSpec("crew_availability", 0, 1),
    ],
    task="regression",
    target="resolution_hours",
    primary_metric="mae",
    metrics=("records", "target_average", "queue_depth"),
    directory=Path(__file__).parent,
)
