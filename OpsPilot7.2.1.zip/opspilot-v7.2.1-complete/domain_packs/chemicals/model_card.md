# Chemicals model card

Objective: chemical_process_yield. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
