"""Configuration-driven industrial domain engine.

Domain behavior is declared in ``industrial.yaml``. The engine validates the
configuration, produces reproducible telemetry, builds operational marts,
trains task-appropriate estimators, evaluates them, and enforces metric
allowlists. No concrete industry names or branches live in this module.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestRegressor
from sklearn.metrics import average_precision_score, mean_absolute_error, recall_score

from data_platform.synthetic import entity_id, event_id, timestamp
from domain_packs.base import ContractMixin
from domain_packs.industrial_schema import IndustrialSpecification
from platform_core.domain import TrainingSet


class IndustrialDomainPlugin(ContractMixin):
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.manifest_path = directory / "domain.yaml"
        self.contract_path = directory / "data_contract.yaml"
        self.configuration = IndustrialSpecification.model_validate(
            yaml.safe_load((directory / "industrial.yaml").read_text(encoding="utf-8"))
        )
        self.spec = self.configuration.model_dump()
        self.name = self.spec["name"]
        self.version = str(self.spec["version"])

    def _feature_values(
        self, feature: dict[str, Any], rows: int, rng: np.random.Generator
    ) -> np.ndarray:
        distribution = feature.get("distribution", "uniform")
        if distribution == "uniform":
            values = rng.uniform(feature["min"], feature["max"], rows)
        elif distribution == "normal":
            values = rng.normal(feature["mean"], feature["std"], rows).clip(
                feature["min"], feature["max"]
            )
        elif distribution == "integer":
            values = rng.integers(feature["min"], feature["max"] + 1, rows).astype(float)
        else:
            raise ValueError(f"unsupported distribution: {distribution}")
        return values.astype(float)

    def generate(self, rows: int, seed: int = 42) -> pd.DataFrame:
        rng = np.random.default_rng(seed)
        entity = self.spec["entity"]
        frame = pd.DataFrame(
            {
                "event_id": [event_id(self.name, seed, index) for index in range(rows)],
                "event_timestamp": [timestamp(index, rows) for index in range(rows)],
                f"{entity}_id": [entity_id(entity, seed, index) for index in range(rows)],
            }
        )
        normalized = {}
        for feature in self.spec["features"]:
            values = self._feature_values(feature, rows, rng)
            frame[feature["name"]] = values
            normalized[feature["name"]] = (values - feature["min"]) / max(
                feature["max"] - feature["min"], 1e-9
            )
        signal = np.full(rows, float(self.spec["signal"].get("intercept", 0.0)))
        for name, weight in self.spec["signal"]["weights"].items():
            signal += float(weight) * normalized[name]
        signal += rng.normal(0, float(self.spec["signal"].get("noise", 0.08)), rows)
        target = self.spec["target"]
        if self.spec["task"] == "binary_classification":
            target_rate = float(self.spec["signal"].get("target_rate", 0.25))
            threshold = float(np.quantile(signal, 1 - target_rate))
            frame[target] = (signal > threshold).astype(int)
        else:
            frame[target] = (float(self.spec["signal"].get("scale", 100)) * signal).clip(
                float(self.spec["signal"].get("floor", 0))
            )
        return frame

    def transform_silver(self, frame: pd.DataFrame) -> pd.DataFrame:
        return (
            frame.drop_duplicates("event_id").sort_values("event_timestamp").reset_index(drop=True)
        )

    def build_marts(self, frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
        target = self.spec["target"]
        aggregate = {
            "records": int(len(frame)),
            "target_average": float(frame[target].mean()),
            "target_p95": float(frame[target].quantile(0.95)),
        }
        for metric in self.spec["metrics"]:
            source = metric.get("source")
            operation = metric.get("operation", "mean")
            if source not in frame:
                continue
            if operation == "mean":
                aggregate[metric["name"]] = float(frame[source].mean())
            elif operation == "sum":
                aggregate[metric["name"]] = float(frame[source].sum())
            elif operation == "p95":
                aggregate[metric["name"]] = float(frame[source].quantile(0.95))
            elif operation == "rate":
                aggregate[metric["name"]] = float(
                    (frame[source] > metric.get("threshold", 0)).mean()
                )
            else:
                raise ValueError(f"unsupported metric operation: {operation}")
        return {self.spec["mart_name"]: pd.DataFrame([aggregate])}

    def training_set(self, frame: pd.DataFrame) -> TrainingSet:
        feature_names = [feature["name"] for feature in self.spec["features"]]
        return TrainingSet(
            frame[feature_names],
            frame[self.spec["target"]],
            self.spec["task"],
            self.spec["primary_metric"],
        )

    def estimator(self):
        if self.spec["task"] == "binary_classification":
            return HistGradientBoostingClassifier(max_iter=120, max_depth=7, random_state=42)
        return RandomForestRegressor(n_estimators=120, max_depth=10, random_state=42, n_jobs=-1)

    def evaluate(self, model, features: pd.DataFrame, target: pd.Series) -> dict[str, float]:
        if self.spec["task"] == "binary_classification":
            probabilities = model.predict_proba(features)[:, 1]
            return {
                "pr_auc": float(average_precision_score(target, probabilities)),
                "recall": float(recall_score(target, probabilities >= 0.5)),
            }
        return {"mae": float(mean_absolute_error(target, model.predict(features)))}

    def predict(self, model, features: dict[str, Any], metadata: dict[str, Any]) -> dict[str, Any]:
        sample = pd.DataFrame([{name: features[name] for name in metadata["features"]}])
        value = (
            float(model.predict_proba(sample)[0, 1])
            if self.spec["task"] == "binary_classification"
            else float(model.predict(sample)[0])
        )
        return {
            "value": value,
            "type": self.spec["target"],
            "unit": self.spec.get("target_unit", "score"),
        }

    def query_metric(self, metric: str, marts: dict[str, pd.DataFrame]) -> float:
        allowed = {
            "records",
            "target_average",
            "target_p95",
            *[item["name"] for item in self.spec["metrics"]],
        }
        if metric not in allowed:
            raise ValueError(f"metric not allowed: {metric}")
        return float(marts[self.spec["mart_name"]].iloc[0][metric])
