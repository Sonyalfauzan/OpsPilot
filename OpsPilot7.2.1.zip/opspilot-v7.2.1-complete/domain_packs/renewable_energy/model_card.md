# Renewable Energy model card

Objective: renewable_generation_forecasting. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
