import random
from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import average_precision_score, recall_score

from data_platform.synthetic import entity_id, event_id, timestamp
from domain_packs.base import ContractMixin
from platform_core.domain import TrainingSet


class ManufacturingPlugin(ContractMixin):
    name = "manufacturing"
    version = "1.0"
    manifest_path = Path(__file__).with_name("domain.yaml")
    contract_path = Path(__file__).with_name("data_contract.yaml")

    def generate(self, rows, seed=42):
        r = random.Random(seed)
        out = []
        for i in range(rows):
            t = r.gauss(72, 8)
            v = max(0, r.gauss(3, 1.1))
            out.append(
                {
                    "event_id": event_id(self.name, seed, i),
                    "event_timestamp": timestamp(i, rows),
                    "machine_id": entity_id("machine", seed, r.randrange(20)),
                    "temperature": t,
                    "vibration": v,
                    "pressure": r.gauss(50, 5),
                    "failure": int(t > 88 or v > 5.3),
                }
            )
        return pd.DataFrame(out)

    def transform_silver(self, f):
        return f.drop_duplicates("event_id").sort_values("event_timestamp")

    def build_marts(self, f):
        return {
            "machine_health": f.groupby("machine_id", as_index=False).agg(
                avg_temperature=("temperature", "mean"),
                avg_vibration=("vibration", "mean"),
                failures=("failure", "sum"),
            )
        }

    def training_set(self, f):
        return TrainingSet(
            f[["temperature", "vibration", "pressure"]],
            f["failure"],
            "binary_classification",
            "pr_auc",
        )

    def estimator(self):
        return RandomForestClassifier(
            n_estimators=120, max_depth=10, random_state=42, class_weight="balanced", n_jobs=-1
        )

    def evaluate(self, m, X, y):
        p = m.predict_proba(X)[:, 1]
        return {
            "pr_auc": float(average_precision_score(y, p)),
            "recall": float(recall_score(y, p >= 0.5)),
        }

    def predict(self, m, features, metadata):
        X = pd.DataFrame([{k: features[k] for k in metadata["features"]}])
        return {"value": float(m.predict_proba(X)[0, 1]), "type": "failure_probability"}

    def query_metric(self, metric, marts):
        d = marts["machine_health"]
        allowed = {
            "failures": lambda: float(d.failures.sum()),
            "avg_temperature": lambda: float(d.avg_temperature.mean()),
        }
        if metric not in allowed:
            raise ValueError("metric not allowed")
        return allowed[metric]()


plugin = ManufacturingPlugin()
