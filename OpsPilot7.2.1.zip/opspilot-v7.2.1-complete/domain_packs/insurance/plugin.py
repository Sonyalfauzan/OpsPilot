from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="insurance",
    entity="claim",
    features=[
        FeatureSpec("claim_amount", 10, 50000),
        FeatureSpec("document_completeness", 0, 1),
        FeatureSpec("claim_frequency", 0, 20),
    ],
    task="binary_classification",
    target="manual_review",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "claim_amount"),
    directory=Path(__file__).parent,
)
