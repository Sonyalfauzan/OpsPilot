# Insurance model card

Synthetic portfolio model for claims_operations_triage. No real-world consequential decisions.
