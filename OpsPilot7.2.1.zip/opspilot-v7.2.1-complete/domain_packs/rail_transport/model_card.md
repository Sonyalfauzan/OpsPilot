# Rail Transport model card

Objective: rail_service_reliability. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
