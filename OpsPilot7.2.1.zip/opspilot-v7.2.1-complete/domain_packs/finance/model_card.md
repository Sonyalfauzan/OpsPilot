# Finance model card

Synthetic portfolio model for transaction_risk_triage. No real-world consequential decisions.
