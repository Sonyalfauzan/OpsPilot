from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="finance",
    entity="transaction",
    features=[
        FeatureSpec("amount", 1, 10000),
        FeatureSpec("velocity_24h", 0, 50),
        FeatureSpec("device_risk", 0, 1),
    ],
    task="binary_classification",
    target="review_required",
    primary_metric="pr_auc",
    metrics=("records", "target_average", "amount"),
    directory=Path(__file__).parent,
)
