# Forestry And Pulp model card

Objective: pulp_mill_throughput. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
