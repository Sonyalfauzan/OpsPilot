from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="energy",
    entity="meter",
    features=[
        FeatureSpec("temperature_c", 10, 42),
        FeatureSpec("hour_index", 0, 23),
        FeatureSpec("industrial_demand", 0, 1),
    ],
    task="regression",
    target="load_mwh",
    primary_metric="mae",
    metrics=("records", "target_average", "temperature_c"),
    directory=Path(__file__).parent,
)
