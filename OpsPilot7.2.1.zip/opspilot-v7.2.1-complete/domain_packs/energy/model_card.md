# Energy model card

Synthetic portfolio model for load_forecasting. No real-world consequential decisions.
