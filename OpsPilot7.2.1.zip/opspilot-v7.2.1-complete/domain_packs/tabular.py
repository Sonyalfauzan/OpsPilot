"""Reusable implementation for synthetic tabular domain plugins."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestRegressor
from sklearn.metrics import average_precision_score, mean_absolute_error, recall_score

from data_platform.synthetic import entity_id, event_id, timestamp
from domain_packs.base import ContractMixin
from platform_core.domain import TrainingSet


@dataclass(frozen=True)
class FeatureSpec:
    name: str
    low: float
    high: float


class SyntheticTabularPlugin(ContractMixin):
    """Configurable plugin with deterministic generation and task-specific ML."""

    def __init__(
        self,
        *,
        name: str,
        entity: str,
        features: list[FeatureSpec],
        task: str,
        target: str,
        primary_metric: str,
        metrics: tuple[str, ...],
        directory: Path,
    ) -> None:
        self.name = name
        self.version = "3.0"
        self.entity = entity
        self.features = features
        self.task = task
        self.target = target
        self.primary_metric = primary_metric
        self.metrics = metrics
        self.manifest_path = directory / "domain.yaml"
        self.contract_path = directory / "data_contract.yaml"

    def generate(self, rows: int, seed: int = 42) -> pd.DataFrame:
        rng = np.random.default_rng(seed)
        frame = pd.DataFrame(
            {
                "event_id": [event_id(self.name, seed, index) for index in range(rows)],
                "event_timestamp": [timestamp(index, rows) for index in range(rows)],
                f"{self.entity}_id": [entity_id(self.entity, seed, index) for index in range(rows)],
            }
        )
        normalized = []
        for spec in self.features:
            frame[spec.name] = rng.uniform(spec.low, spec.high, rows)
            normalized.append((frame[spec.name] - spec.low) / max(spec.high - spec.low, 1e-9))
        signal = sum((index + 1) * values for index, values in enumerate(normalized)) / sum(
            range(1, len(normalized) + 1)
        )
        noise = rng.normal(0, 0.12, rows)
        if self.task == "binary_classification":
            frame[self.target] = ((signal + noise) > 0.58).astype(int)
        else:
            frame[self.target] = (20 + 80 * signal + 10 * noise).clip(0)
        return frame

    def transform_silver(self, frame: pd.DataFrame) -> pd.DataFrame:
        return frame.drop_duplicates("event_id").sort_values("event_timestamp")

    def build_marts(self, frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
        summary = {
            "records": len(frame),
            "target_average": float(frame[self.target].mean()),
            **{f"avg_{spec.name}": float(frame[spec.name].mean()) for spec in self.features},
        }
        return {f"{self.name}_operations": pd.DataFrame([summary])}

    def training_set(self, frame: pd.DataFrame) -> TrainingSet:
        return TrainingSet(
            frame[[spec.name for spec in self.features]],
            frame[self.target],
            self.task,
            self.primary_metric,
        )

    def estimator(self):
        if self.task == "binary_classification":
            return HistGradientBoostingClassifier(max_iter=100, max_depth=6, random_state=42)
        return RandomForestRegressor(n_estimators=100, max_depth=8, random_state=42, n_jobs=-1)

    def evaluate(self, model, features: pd.DataFrame, target: pd.Series) -> dict[str, float]:
        if self.task == "binary_classification":
            probability = model.predict_proba(features)[:, 1]
            return {
                "pr_auc": float(average_precision_score(target, probability)),
                "recall": float(recall_score(target, probability >= 0.5)),
            }
        return {"mae": float(mean_absolute_error(target, model.predict(features)))}

    def predict(self, model, features: dict[str, Any], metadata: dict[str, Any]) -> dict[str, Any]:
        sample = pd.DataFrame([{name: features[name] for name in metadata["features"]}])
        value = (
            float(model.predict_proba(sample)[0, 1])
            if self.task == "binary_classification"
            else float(model.predict(sample)[0])
        )
        return {"value": value, "type": self.target}

    def query_metric(self, metric: str, marts: dict[str, pd.DataFrame]) -> float:
        if metric not in self.metrics:
            raise ValueError(f"metric not allowed: {metric}")
        row = marts[f"{self.name}_operations"].iloc[0]
        if metric == "records":
            return float(row["records"])
        if metric == "target_average":
            return float(row["target_average"])
        column = f"avg_{metric}"
        if column not in row:
            raise ValueError(f"metric has no aggregate: {metric}")
        return float(row[column])
