# Oil And Gas model card

Objective: well_and_pipeline_operations. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
