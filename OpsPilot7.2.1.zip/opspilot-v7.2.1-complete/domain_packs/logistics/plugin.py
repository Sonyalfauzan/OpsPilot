import random
from pathlib import Path

import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score, recall_score

from data_platform.synthetic import entity_id, event_id, timestamp
from domain_packs.base import ContractMixin
from platform_core.domain import TrainingSet


class LogisticsPlugin(ContractMixin):
    name = "logistics"
    version = "1.0"
    manifest_path = Path(__file__).with_name("domain.yaml")
    contract_path = Path(__file__).with_name("data_contract.yaml")

    def generate(self, rows, seed=42):
        r = random.Random(seed)
        out = []
        for i in range(rows):
            distance = r.uniform(1, 1200)
            traffic = r.random()
            weather = r.random()
            delay = max(0, traffic * 90 + weather * 45 + distance / 80 + r.gauss(0, 12) - 45)
            out.append(
                {
                    "event_id": event_id(self.name, seed, i),
                    "event_timestamp": timestamp(i, rows),
                    "shipment_id": entity_id("shipment", seed, i),
                    "distance_km": distance,
                    "traffic_index": traffic,
                    "weather_index": weather,
                    "delay_minutes": delay,
                    "delayed": int(delay > 30),
                }
            )
        return pd.DataFrame(out)

    def transform_silver(self, f):
        return f.drop_duplicates("event_id").sort_values("event_timestamp")

    def build_marts(self, f):
        return {
            "delivery_performance": pd.DataFrame(
                [
                    {
                        "shipments": len(f),
                        "delayed_shipments": int(f.delayed.sum()),
                        "average_delay_minutes": float(f.delay_minutes.mean()),
                        "on_time_rate": float(1 - f.delayed.mean()),
                    }
                ]
            )
        }

    def training_set(self, f):
        return TrainingSet(
            f[["distance_km", "traffic_index", "weather_index"]],
            f["delayed"],
            "binary_classification",
            "pr_auc",
        )

    def estimator(self):
        return HistGradientBoostingClassifier(max_iter=120, max_depth=7, random_state=42)

    def evaluate(self, m, X, y):
        p = m.predict_proba(X)[:, 1]
        return {
            "pr_auc": float(average_precision_score(y, p)),
            "recall": float(recall_score(y, p >= 0.5)),
        }

    def predict(self, m, features, metadata):
        X = pd.DataFrame([{k: features[k] for k in metadata["features"]}])
        return {"value": float(m.predict_proba(X)[0, 1]), "type": "delay_probability"}

    def query_metric(self, metric, marts):
        d = marts["delivery_performance"].iloc[0]
        if metric not in {"delayed_shipments", "average_delay_minutes", "on_time_rate"}:
            raise ValueError("metric not allowed")
        return float(d[metric])


plugin = LogisticsPlugin()
