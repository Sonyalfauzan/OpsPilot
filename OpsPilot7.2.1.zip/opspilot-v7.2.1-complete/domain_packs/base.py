from pathlib import Path
from typing import Any

import pandas as pd
import yaml


class ContractMixin:
    contract_path: Path

    def validate(self, frame: pd.DataFrame) -> dict[str, Any]:
        c = yaml.safe_load(self.contract_path.read_text(encoding="utf-8"))
        failures = []
        missing = sorted(set(c.get("required", [])) - set(frame.columns))
        if missing:
            failures.append({"rule": "required_columns", "columns": missing})
        for col, bounds in c.get("ranges", {}).items():
            if col in frame and (not frame[col].dropna().between(*bounds).all()):
                failures.append({"rule": "range", "column": col})
        for col in c.get("unique", []):
            if col in frame and frame[col].duplicated().any():
                failures.append({"rule": "unique", "column": col})
        for col, max_rate in c.get("max_null_rate", {}).items():
            if col in frame and float(frame[col].isna().mean()) > float(max_rate):
                failures.append({"rule": "null_rate", "column": col})
        return {"passed": not failures, "failures": failures, "rows": len(frame)}
