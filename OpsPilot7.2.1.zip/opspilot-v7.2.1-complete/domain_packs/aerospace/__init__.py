"""Public domain plugin export."""

from .plugin import plugin

__all__ = ["plugin"]
