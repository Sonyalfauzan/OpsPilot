from pathlib import Path

from domain_packs.industrial_engine import IndustrialDomainPlugin

plugin = IndustrialDomainPlugin(Path(__file__).parent)
