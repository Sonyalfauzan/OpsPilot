# Aerospace model card

Objective: aerospace_component_quality. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
