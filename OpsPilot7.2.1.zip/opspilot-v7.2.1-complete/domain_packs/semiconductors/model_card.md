# Semiconductors model card

Objective: wafer_fabrication_yield. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
