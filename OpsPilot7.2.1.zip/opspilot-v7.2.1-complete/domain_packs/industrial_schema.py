"""Strict Pydantic schema for configuration-driven industrial domains."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FeatureSpecification(StrictModel):
    name: str = Field(min_length=1)
    min: float
    max: float
    distribution: Literal["uniform", "normal", "integer"] = "uniform"
    mean: float | None = None
    std: float | None = None

    @model_validator(mode="after")
    def validate_bounds(self):
        if self.min >= self.max:
            raise ValueError("feature min must be less than max")
        if self.distribution == "normal" and (self.mean is None or not self.std or self.std <= 0):
            raise ValueError("normal distribution requires positive std and mean")
        return self


class SignalSpecification(StrictModel):
    weights: dict[str, float]
    noise: float = Field(ge=0)
    intercept: float = 0
    threshold: float | None = None
    target_rate: float = Field(default=0.25, gt=0, lt=1)
    scale: float = Field(default=100, gt=0)
    floor: float = 0


class MetricSpecification(StrictModel):
    name: str
    source: str
    operation: Literal["mean", "sum", "p95", "rate"]
    threshold: float | None = None


class IndustrialSpecification(StrictModel):
    name: str
    version: str
    entity: str
    task: Literal["regression", "binary_classification"]
    target: str
    target_unit: str
    primary_metric: str
    mart_name: str
    features: list[FeatureSpecification] = Field(min_length=1)
    signal: SignalSpecification
    metrics: list[MetricSpecification] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_references(self):
        features = {item.name for item in self.features}
        unknown = set(self.signal.weights) - features
        metric_unknown = {item.source for item in self.metrics} - features
        if unknown or metric_unknown:
            raise ValueError(f"unknown features: {sorted(unknown | metric_unknown)}")
        if self.task == "binary_classification" and self.primary_metric != "pr_auc":
            raise ValueError("classification primary metric must be pr_auc")
        if self.task == "regression" and self.primary_metric != "mae":
            raise ValueError("regression primary metric must be mae")
        return self
