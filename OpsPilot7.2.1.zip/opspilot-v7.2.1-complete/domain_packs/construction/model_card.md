# Construction model card

Objective: project_schedule_risk. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
