# Waste And Recycling model card

Objective: material_recovery_optimization. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
