# Mining model card

Objective: mobile_and_fixed_equipment_health. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
