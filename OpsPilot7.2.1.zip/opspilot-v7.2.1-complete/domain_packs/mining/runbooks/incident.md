# Mining incident runbook

1. Validate telemetry freshness and contract.
2. Compare current and reference distributions.
3. Inspect operational and maintenance context.
4. Separate evidence from causal hypotheses.
5. Request human review for any operational action.
6. Verify recovery and produce a postmortem.
