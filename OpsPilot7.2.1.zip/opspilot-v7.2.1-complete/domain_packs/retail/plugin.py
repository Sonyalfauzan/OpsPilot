"""Retail demand and inventory domain plugin."""

from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error

from data_platform.synthetic import entity_id, event_id, generator, timestamp
from domain_packs.base import ContractMixin
from platform_core.domain import TrainingSet


class RetailPlugin(ContractMixin):
    name = "retail"
    version = "4.1"
    manifest_path = Path(__file__).with_name("domain.yaml")
    contract_path = Path(__file__).with_name("data_contract.yaml")

    def generate(self, rows: int, seed: int = 42) -> pd.DataFrame:
        rng = generator(seed)
        return pd.DataFrame(
            {
                "event_id": [event_id(self.name, seed, i) for i in range(rows)],
                "event_timestamp": [timestamp(i, rows) for i in range(rows)],
                "product_id": [
                    entity_id("product", seed, int(i)) for i in rng.integers(0, 50, rows)
                ],
                "quantity": rng.integers(0, 13, rows),
                "price": rng.uniform(5, 500, rows).round(2),
                "inventory": rng.integers(0, 101, rows),
                "promotion": rng.integers(0, 2, rows),
            }
        )

    def transform_silver(self, frame: pd.DataFrame) -> pd.DataFrame:
        return frame.drop_duplicates("event_id").sort_values("event_timestamp")

    def build_marts(self, frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
        enriched = frame.assign(revenue=frame.quantity * frame.price)
        mart = enriched.groupby("product_id", as_index=False).agg(
            quantity=("quantity", "sum"),
            revenue=("revenue", "sum"),
            inventory=("inventory", "last"),
        )
        return {"product_daily": mart}

    def training_set(self, frame: pd.DataFrame) -> TrainingSet:
        return TrainingSet(
            frame[["price", "inventory", "promotion"]], frame["quantity"], "regression", "mae"
        )

    def estimator(self):
        return RandomForestRegressor(n_estimators=120, max_depth=10, random_state=42, n_jobs=-1)

    def evaluate(self, model, features, target) -> dict[str, float]:
        return {"mae": float(mean_absolute_error(target, model.predict(features)))}

    def predict(self, model, features: dict, metadata: dict) -> dict:
        sample = pd.DataFrame([{name: features[name] for name in metadata["features"]}])
        return {"value": float(model.predict(sample)[0]), "type": "demand"}

    def query_metric(self, metric: str, marts: dict[str, pd.DataFrame]) -> float:
        mart = marts["product_daily"]
        allowed = {
            "revenue": lambda: float(mart.revenue.sum()),
            "quantity": lambda: float(mart.quantity.sum()),
            "stockout_rate": lambda: float((mart.inventory == 0).mean()),
        }
        if metric not in allowed:
            raise ValueError("metric not allowed")
        return allowed[metric]()


plugin = RetailPlugin()
