# Data Centers model card

Objective: data_center_capacity_and_cooling. Synthetic portfolio data only. Outputs support human review and cannot directly control physical assets or safety systems.
