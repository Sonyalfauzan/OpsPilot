# Agriculture model card

Synthetic portfolio model for crop_yield_forecasting. No real-world consequential decisions.
