from pathlib import Path

from domain_packs.tabular import FeatureSpec, SyntheticTabularPlugin

plugin = SyntheticTabularPlugin(
    name="agriculture",
    entity="field",
    features=[
        FeatureSpec("soil_moisture", 0, 1),
        FeatureSpec("rainfall_mm", 0, 250),
        FeatureSpec("temperature_c", 10, 42),
    ],
    task="regression",
    target="yield_tons",
    primary_metric="mae",
    metrics=("records", "target_average", "soil_moisture"),
    directory=Path(__file__).parent,
)
