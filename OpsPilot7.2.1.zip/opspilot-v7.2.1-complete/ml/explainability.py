import numpy as np
def linear_contributions(feature_names,values,coefficients,intercept=0.0):
    values=np.asarray(values,dtype=float);coefficients=np.asarray(coefficients,dtype=float)
    if len(feature_names)!=len(values) or values.shape!=coefficients.shape:raise ValueError('feature dimensions differ')
    parts=values*coefficients
    return {'baseline':float(intercept),'prediction':float(intercept+parts.sum()),'features':[{'name':n,'value':float(v),'contribution':float(c)} for n,v,c in zip(feature_names,values,parts,strict=True)]}
def anomaly_explanation(feature_names,values,reference_mean,reference_scale):
    values=np.asarray(values,float);mean=np.asarray(reference_mean,float);scale=np.maximum(np.asarray(reference_scale,float),1e-12);scores=np.abs((values-mean)/scale);order=np.argsort(scores)[::-1]
    return {'method':'standardized-deviation','features':[{'name':feature_names[i],'value':float(values[i]),'score':float(scores[i])} for i in order]}
