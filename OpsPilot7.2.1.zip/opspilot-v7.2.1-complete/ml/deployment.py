from dataclasses import dataclass


@dataclass
class DeploymentState:
    champion: str
    challenger: str | None = None
    challenger_traffic: int = 0
    status: str = "STABLE"


def start_canary(state, candidate, traffic=10):
    if not 0 < traffic <= 25:
        raise ValueError("portfolio canary limited to 25%")
    state.challenger = candidate
    state.challenger_traffic = traffic
    state.status = "CANARY"
    return state


def evaluate_guardrails(state, latency_ms, error_rate, quality_delta):
    passed = latency_ms <= 150 and error_rate <= 0.01 and (quality_delta >= -0.02)
    if not passed:
        state.challenger = None
        state.challenger_traffic = 0
        state.status = "ROLLED_BACK"
    return {"passed": passed, "state": state.status}
