"""Generate real Evidently reports when installed, with deterministic fallback."""

import json
from pathlib import Path

import pandas as pd


def run_monitor(reference: pd.DataFrame, current: pd.DataFrame, output_directory: str) -> dict:
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    try:
        from evidently import Report
        from evidently.presets import DataDriftPreset, DataSummaryPreset

        report = Report([DataSummaryPreset(), DataDriftPreset()])
        snapshot = report.run(current_data=current, reference_data=reference)
        snapshot.save_html(str(directory / "report.html"))
        result = {"engine": "evidently", "report_html": str(directory / "report.html")}
    except (ImportError, TypeError, AttributeError) as exc:
        numeric = reference.select_dtypes("number").columns.intersection(
            current.select_dtypes("number").columns
        )
        shifts = {
            column: float(
                abs(current[column].mean() - reference[column].mean())
                / max(reference[column].std(), 1e-09)
            )
            for column in numeric
        }
        result = {
            "engine": "deterministic-fallback",
            "reason": str(exc),
            "feature_shift": shifts,
            "drift_share": sum(value > 0.5 for value in shifts.values()) / max(len(shifts), 1),
        }
    (directory / "report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result
