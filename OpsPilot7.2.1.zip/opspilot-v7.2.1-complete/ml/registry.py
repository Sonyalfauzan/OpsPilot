import hashlib
import json
import shutil
from pathlib import Path


class LocalRegistry:
    def __init__(self, root="data/registry"):
        self.root = Path(root)

    def register(self, tenant, domain, artifact, metadata):
        target = self.root / tenant / domain / metadata["model_version"]
        target.mkdir(parents=True, exist_ok=True)
        shutil.copy2(artifact, target / "model.joblib")
        digest = hashlib.sha256((target / "model.joblib").read_bytes()).hexdigest()
        metadata = {**metadata, "sha256": digest}
        (target / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        return metadata

    def set_alias(self, tenant, domain, alias, version):
        p = self.root / tenant / domain / "aliases.json"
        aliases = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        aliases[alias] = version
        p.write_text(json.dumps(aliases, indent=2), encoding="utf-8")

    def aliases(self, tenant, domain):
        p = self.root / tenant / domain / "aliases.json"
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
