import pandas as pd


def drift_report(reference: pd.DataFrame, current: pd.DataFrame, columns: list[str]) -> dict:
    results = []
    for c in columns:
        a, b = (reference[c].dropna(), current[c].dropna())
        denom = max(float(a.std()), 1e-09)
        standardized_mean_shift = abs(float(b.mean() - a.mean())) / denom
        results.append(
            {
                "column": c,
                "score": standardized_mean_shift,
                "drifted": standardized_mean_shift > 0.5,
            }
        )
    return {
        "columns": results,
        "drift_share": sum(x["drifted"] for x in results) / max(len(results), 1),
        "note": "mean-shift heuristic; use validated statistical tests for production",
    }
