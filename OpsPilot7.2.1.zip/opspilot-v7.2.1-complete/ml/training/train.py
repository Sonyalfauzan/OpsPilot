"""Generic, tenant-scoped, reproducible model training."""

import argparse
import json
from pathlib import Path

import joblib
from sklearn.model_selection import train_test_split

from data_platform.storage import read_frame
from platform_core.config import settings
from platform_core.registry import registry


def train(domain: str, tenant_id: str = "tenant-alpha") -> dict:
    plugin = registry().get(domain)
    frame = read_frame(Path("data") / tenant_id / "silver" / domain / "events.parquet")
    dataset = plugin.training_set(frame)
    stratify = dataset.target if dataset.task == "binary_classification" else None
    train_x, test_x, train_y, test_y = train_test_split(
        dataset.features,
        dataset.target,
        test_size=0.25,
        random_state=42,
        stratify=stratify,
    )
    model = plugin.estimator()
    model.fit(train_x, train_y)
    metrics = plugin.evaluate(model, test_x, test_y)
    output = Path("data") / tenant_id / "models" / domain
    output.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, output / "model.joblib")
    metadata = {
        "tenant_id": tenant_id,
        "domain": domain,
        "plugin_version": plugin.version,
        "model_version": "1",
        "task": dataset.task,
        "primary_metric": dataset.primary_metric,
        "metrics": metrics,
        "features": list(dataset.features.columns),
        "seed": 42,
    }
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    try:
        import mlflow

        mlflow.set_tracking_uri(settings().mlflow_tracking_uri)
        mlflow.set_experiment(f"opspilot-{tenant_id}-{domain}")
        with mlflow.start_run():
            mlflow.log_params(
                {
                    "plugin_version": plugin.version,
                    "estimator": model.__class__.__name__,
                    "seed": 42,
                }
            )
            mlflow.log_metrics(metrics)
            mlflow.log_artifacts(str(output))
    except (ImportError, OSError, RuntimeError) as exc:
        print(f"MLflow unavailable; durable local artifacts retained: {exc}")
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--domain", required=True)
    parser.add_argument("--tenant", default="tenant-alpha")
    print(train(parser.parse_args().domain, parser.parse_args().tenant))
