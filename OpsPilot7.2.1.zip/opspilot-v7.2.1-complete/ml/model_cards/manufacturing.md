# Manufacturing model card

Synthetic-data portfolio model. Intended for demonstration only. Includes reproducible seed, plugin version, task-specific metrics, segment/error-analysis hooks and explicit prohibition on real-world automated decisions.
