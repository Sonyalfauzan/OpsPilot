"""FastMCP transport for tenant-scoped model metadata and drift reports."""

import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from platform_core.registry import registry

mcp = FastMCP("opspilot-mlops")


@mcp.tool()
def get_model_versions(tenant_id: str, domain: str) -> dict:
    registry().get(domain)
    path = Path("data") / tenant_id / "models" / domain / "metadata.json"
    return (
        json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"status": "not_trained"}
    )


@mcp.tool()
def get_drift_report(tenant_id: str, domain: str) -> dict:
    registry().get(domain)
    path = Path("data") / tenant_id / "drift" / domain / "report.json"
    return (
        json.loads(path.read_text(encoding="utf-8"))
        if path.exists()
        else {"status": "not_available"}
    )


if __name__ == "__main__":
    mcp.run()
