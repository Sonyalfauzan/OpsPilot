from mcp.server.fastmcp import FastMCP

mcp = FastMCP("opspilot-workflow")


@mcp.tool()
def request_approval(tenant_id: str, incident_id: str, action: str) -> dict:
    """Create an approval request; this never executes the action."""
    return {
        "tenant_id": tenant_id,
        "incident_id": incident_id,
        "action": action,
        "status": "PENDING_APPROVAL",
    }


if __name__ == "__main__":
    mcp.run()
