from mcp_servers.factory import analytics_server

mcp = analytics_server()
if __name__ == "__main__":
    mcp.run()
