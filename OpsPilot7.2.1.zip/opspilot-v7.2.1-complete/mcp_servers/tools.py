"""Pure MCP tool implementations for direct contract testing."""

import json
from pathlib import Path

from data_platform.storage import read_frame
from platform_core.registry import registry


def pipeline_status(tenant_id: str, domain: str) -> dict:
    registry().get(domain)
    root = Path("data") / tenant_id / "gold" / domain
    return {"tenant_id": tenant_id, "domain": domain, "ready": root.exists()}


def quality_report(tenant_id: str, domain: str) -> dict:
    registry().get(domain)
    path = Path("data") / tenant_id / "quality" / domain / "latest.json"
    return (
        json.loads(path.read_text(encoding="utf-8"))
        if path.exists()
        else {"status": "not_available"}
    )


def analytics_metric(tenant_id: str, domain: str, metric: str) -> dict:
    plugin = registry().get(domain)
    root = Path("data") / tenant_id / "gold" / domain
    marts = {path.stem: read_frame(path) for path in root.glob("*.parquet")}
    marts.update(
        {path.stem: read_frame(path.with_suffix(".parquet")) for path in root.glob("*.jsonl")}
    )
    if not marts:
        raise FileNotFoundError(f"no marts for tenant={tenant_id}, domain={domain}")
    return {
        "tenant_id": tenant_id,
        "domain": domain,
        "metric": metric,
        "value": plugin.query_metric(metric, marts),
    }
