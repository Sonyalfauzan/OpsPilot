from mcp_servers.factory import data_server

mcp = data_server()
if __name__ == "__main__":
    mcp.run()
