"""MCP Python SDK v2 server factories; business tools remain transport-independent."""

from mcp.server import FastMCP

from mcp_servers.tools import analytics_metric, pipeline_status, quality_report


def analytics_server() -> FastMCP:
    server = FastMCP("opspilot-analytics")
    server.tool()(analytics_metric)
    return server


def data_server() -> FastMCP:
    server = FastMCP("opspilot-data")
    server.tool()(pipeline_status)
    server.tool()(quality_report)
    return server
