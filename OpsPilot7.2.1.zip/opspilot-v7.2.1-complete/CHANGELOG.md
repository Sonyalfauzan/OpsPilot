# Changelog

## 7.2.1 Full Remediation Completion

- Completed SQLite FK enforcement, authenticated shared live events, registry-backed producer/consumer validation, Bronze-Silver-Gold lineage, and served prediction explanations.

## 7.2.0 Security, Governance, and Operability

- Closed fifteen reviewed gaps across auditability, rate limiting, authentication comparison, referential integrity, pagination, architecture evidence, CI coverage, SBOM, CSP, live updates, event schemas, lineage, explainability, incident lifecycle, and credential expiry.

## 7.1.0 Maintainability Remediation

- Synchronized platform versions across package metadata, APIs, versioning policy and external-validation status.
- Renumbered the administration migration to produce a contiguous 0001 to 0002 chain.
- Reformatted operations and administration HTML, CSS and JavaScript into reviewable source.
- Moved the service catalog to validated YAML with cached loading and uniqueness checks.

## 6.1.0 Audited Complete Edition

- Packaged generated calibration evidence.
- Replaced the MCP vendor placeholder with an explicit empty external-client matrix.
- Added platform/domain/event versioning policy.
- Added machine-readable external-validation status and AST-aware incomplete-code scanning.
- Added a consolidated release audit and regression guards.

## 6.0.0 Complete Portfolio Edition

- Added authenticated operations and DLQ dashboard.
- Added tenant-scoped operational read models and synthetic incident control.
- Added Redis Cluster backend, rebalance lifecycle, executable privacy/calibration/MCP checks, validation Compose profile and Windows UTF-8 hardening.

## 5.1.0 Synthetic Production Validation

- Added synthetic-only provenance, HA failure matrix, Kubernetes eviction assets, soak profile, privacy policy, calibration profiles, and MCP interoperability matrix.

## 5.0.0 Distributed and Protocol Modernization

- Atomic SQLite, Redis and PostgreSQL deduplication backends.
- MCP Python SDK v2 MCPServer adapters.
- Temporal nonlinear physics-informed synthetic simulation.
- Twelve independent release gates.

## 4.2.0 Runtime Resilience

- Expanded negative OIDC security tests.
- Added explicit streaming envelope, cached legacy inference, persistent deduplication, metrics and DLQ.
- Removed duplicate industrial validation.
- Added graceful Spark lifecycle and precise delivery-semantics documentation.
- Added strict dashboard core schema with extensions.

## 4.2.0 Review Remediation

- Full deterministic seeding across all domains.
- Strict industrial configuration schemas and runtime domain-policy enforcement.
- Deduplicated local RAG retrieval.
- Functional Redpanda producer, validated consumer, DLQ and Spark streaming job.
- Explicit mock-AI overlay and Airflow dev-only source mount.
- OIDC validation and dashboard contract tests.
- Public plugin exports and zero-finding Ruff format/lint.
- 45 automated tests and 78 behavioral Definition of Done capabilities.

## 4.0.0 Industrial Coverage Edition

- Added Mining, Oil and Gas, Water Utilities, Construction, Automotive, Aerospace, Chemicals, Pharmaceutical Manufacturing, Food and Beverage, Forestry and Pulp, Maritime and Ports, Rail Transport, Waste and Recycling, Semiconductors, Data Centers and Renewable Energy.
- Expanded active plugin count from 13 to 29.
- Added configuration-driven `IndustrialDomainPlugin`; concrete sectors declare distributions, features, target signal, metrics and units in validated YAML rather than core branches.
- Added distinct safety policies, model cards, dashboards and runbooks for every industrial sector.
- Added behavioral tests proving unique feature sets, non-empty policies and full model lifecycle for all industrial plugins.
- Expanded Definition of Done from 52 to 68 capabilities.

## 3.0.0 Multi-Industry Edition

- Added Finance, Energy, Agriculture, Telecommunications, Hospitality, Education, Insurance, Real Estate, Healthcare Operations and Public Services.
- Added tenant-scoped FastMCP adapters, migration round-trip tests, optimistic locking, bounded outbox retry and authenticated load testing.
