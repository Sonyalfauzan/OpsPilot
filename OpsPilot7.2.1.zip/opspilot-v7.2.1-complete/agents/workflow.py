from enum import StrEnum

from agents.incident import investigate
from rag.service import LocalRAG


class State(StrEnum):
    OPEN = "OPEN"
    TRIAGED = "TRIAGED"
    INVESTIGATED = "INVESTIGATED"
    APPROVAL_PENDING = "APPROVAL_PENDING"
    EXECUTED = "EXECUTED"
    VERIFIED = "VERIFIED"
    CLOSED = "CLOSED"


class IncidentWorkflow:
    def __init__(self, domain, evidence):
        self.domain = domain
        self.evidence = evidence
        self.state = State.OPEN
        self.timeline = []

    def step(self):
        if self.state == State.OPEN:
            self.state = State.TRIAGED
            result = {"severity": "SEV-2"}
        elif self.state == State.TRIAGED:
            result = investigate(self.domain, "model_degradation", self.evidence)
            self.state = (
                State.APPROVAL_PENDING if result["approval_required"] else State.INVESTIGATED
            )
        elif self.state == State.EXECUTED:
            self.state = State.VERIFIED
            result = {"recovered": True}
        elif self.state == State.VERIFIED:
            self.state = State.CLOSED
            result = {"postmortem_ready": True}
        else:
            result = {"waiting": self.state}
        self.timeline.append({"state": self.state, "result": result})
        return result

    def knowledge(self, question):
        rag = LocalRAG()
        rag.index("knowledge")
        return rag.answer(question)
