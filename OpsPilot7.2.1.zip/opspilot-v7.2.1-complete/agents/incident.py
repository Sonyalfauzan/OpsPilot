import yaml

from platform_core.registry import registry


def investigate(domain, incident_type, evidence):
    plugin = registry().get(domain)
    cfg = yaml.safe_load(plugin.manifest_path.read_text(encoding="utf-8"))
    thresholds = cfg.get("thresholds", {})
    facts = [e for e in evidence if e.get("kind") in {"metric", "quality", "deployment", "drift"}]
    if not facts:
        return {
            "status": "INSUFFICIENT_EVIDENCE",
            "confidence": 0.1,
            "hypotheses": [],
            "recommended_action": "collect_more_evidence",
            "approval_required": False,
        }
    missing = max(
        (float(e.get("value", 0)) for e in facts if e.get("metric") == "missing_rate"), default=0
    )
    drift = max(
        (float(e.get("value", 0)) for e in facts if e.get("metric") == "drift_share"), default=0
    )
    hypotheses = []
    if missing > thresholds.get("max_missing_rate", 0.02):
        hypotheses.append(
            {
                "name": "feature_pipeline_failure",
                "confidence": min(0.95, 0.5 + missing),
                "supporting_evidence": [f"missing_rate={missing:.3f}"],
                "contradicting_evidence": [],
            }
        )
    if drift > thresholds.get("max_drift_share", 0.3):
        hypotheses.append(
            {
                "name": "distribution_shift",
                "confidence": min(0.9, 0.45 + drift / 2),
                "supporting_evidence": [f"drift_share={drift:.3f}"],
                "contradicting_evidence": ["drift alone does not prove performance degradation"],
            }
        )
    hypotheses.sort(key=lambda x: x["confidence"], reverse=True)
    return {
        "status": "ANALYZED",
        "confidence": hypotheses[0]["confidence"] if hypotheses else 0.3,
        "hypotheses": hypotheses,
        "recommended_action": "pause_candidate_and_validate_pipeline"
        if hypotheses
        else "continue_monitoring",
        "approval_required": bool(hypotheses),
        "limitations": ["causal attribution requires controlled validation and labels"],
    }
